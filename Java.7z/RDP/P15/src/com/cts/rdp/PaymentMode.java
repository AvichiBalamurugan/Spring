package com.cts.rdp;

public abstract class PaymentMode {
	String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public PaymentMode(String type) {
		super();
		this.type = type;
	}

	public PaymentMode() {
		super();
	}

	abstract Double makePayment(Booking booking);
}
