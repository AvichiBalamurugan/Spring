package com.cts.rdp;

class HatchBack extends Car {
	Boolean powerWindowsEnabled, automaticGear;

	public Boolean getPowerWindowsEnabled() {
		return powerWindowsEnabled;
	}

	public void setPowerWindowsEnabled(Boolean powerWindowsEnabled) {
		this.powerWindowsEnabled = powerWindowsEnabled;
	}

	public Boolean getAutomaticGear() {
		return automaticGear;
	}

	public void setAutomaticGear(Boolean automaticGear) {
		this.automaticGear = automaticGear;
	}

	public HatchBack(Long id, String name, Boolean powerWindowsEnabled, Boolean automaticGear) {
		super(id, name);
		this.powerWindowsEnabled = powerWindowsEnabled;
		this.automaticGear = automaticGear;
	}

	@Override
	Double calculateDriveCost(Double dist) {
		if (automaticGear) {
			return (double) dist * 12.0;
		} else {
			return (double) dist * 10.0;
		}

	}

}
