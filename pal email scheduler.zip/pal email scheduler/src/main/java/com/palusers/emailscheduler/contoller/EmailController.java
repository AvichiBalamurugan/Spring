package com.palusers.emailscheduler.contoller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.palusers.emailscheduler.domain.EmailEntity;
import com.palusers.emailscheduler.services.EmailCreationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value = "Email scheduler")
public class EmailController {

	@Autowired
	private EmailCreationService emailCreationService;
	
	@RequestMapping("/GetEmails")
	@ApiOperation(value ="Get all emails",response = EmailEntity.class)
	public List<EmailEntity> get()
	{
		return emailCreationService.listAll();		
	}
	
	@ApiOperation(value ="Delete a particular email")	
	@RequestMapping("/DeleteEmail/{id}")
	public void deleteEmail(Long id)
	{
		emailCreationService.deleteEmail(id);		
	}
}
