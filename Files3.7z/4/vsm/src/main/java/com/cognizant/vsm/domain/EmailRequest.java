package com.cognizant.vsm.domain;

public class EmailRequest {

		public String Recipient;
		public String Message;
		public String Subject;
		
		@Override
		public String toString() {
			return "EmailRequest [Recipient=" + Recipient + ", Message="
					+ Message + ", Subject=" + Subject + "]";
		}

	
}
