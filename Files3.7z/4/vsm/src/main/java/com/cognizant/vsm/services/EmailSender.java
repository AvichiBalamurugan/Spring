package com.cognizant.vsm.services;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.TemplateEngine;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClient;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;
import com.amazonaws.services.simpleemail.model.SendEmailResult;
import com.cognizant.vsm.domain.EmailRequest;
import com.cognizant.vsm.domain.User;

@Service
public class EmailSender implements IEmailService {

	@Autowired
	private TemplateEngine templateEngine;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private String awsSource = "Cumulus Labs <info@cumuluslabs.io>";

	private String accessKey = "AKIAJTHJ2FPS6RETKXLQ";

	private String secretKey = "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";

	private void sendMail(String to, String subject, String htmlbody) {

		Content subjectContent = new Content(subject);
		String newhtml = htmlbody.replace(
				"<html lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\">",
				"<html>");
		System.out.println("newhtml: " + newhtml);
		Content bodyContent = new Content().withData(newhtml);
		Body msgBody = new Body().withHtml(bodyContent);
		Message msg = new Message(subjectContent, msgBody);
		List<String> toAddresses = Arrays.asList(to);
		Destination destination = null;
		destination = new Destination().withToAddresses(toAddresses);
		// destination= new
		// Destination().withToAddresses(toAddresses).withCcAddresses("").withBccAddresses("");
		SendEmailRequest request = new SendEmailRequest(awsSource, destination,
				msg);
		AWSCredentials credentials = new BasicAWSCredentials(accessKey,
				secretKey);
		AmazonSimpleEmailServiceClient sesClient = new AmazonSimpleEmailServiceClient(credentials);
		SendEmailResult result = sesClient.sendEmail(request);
	}

	public void validateMail(User created_user) {

		if (created_user.getEmail().toLowerCase().endsWith("@cognizant.com")) {
			Date date = new Date();
			final DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			EmailRequest emailData = new EmailRequest();
			emailData.Recipient = created_user.getEmail();
			emailData.Subject = "VSM Java";
			emailData.Message = "You download link for VSM Java from Cognizant. Sent at "
					+ sdf.format(date);
			System.out.println("Message sent to" + emailData.Recipient
					+ " with subject " + emailData.Subject + " with message "
					+ emailData.Message);

			sendVSMMail(emailData);
		}
	}

	@Override
	public void sendVSMMail(EmailRequest emailData) {
		Context context = new Context();
		context.setVariable("message", emailData.Message);
		String htmlBody = templateEngine.process("VSMEMailTemplate", context);
		sendMail(emailData.Recipient, emailData.Subject, htmlBody);
		logger.info("Message Sent to " + emailData.Recipient + " with Subject "
				+ emailData.Subject + " and Message " + emailData.Message);
	}

}
