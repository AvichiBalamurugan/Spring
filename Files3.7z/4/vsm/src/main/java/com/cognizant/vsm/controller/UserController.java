package com.cognizant.vsm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.vsm.domain.User;
import com.cognizant.vsm.services.EmailSender;
import com.cognizant.vsm.services.UserService;

@RestController
@RequestMapping({"/api"})
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private EmailSender emailService;

    private User created_user;
        
    @PostMapping
    public User create(@RequestBody User user){
    	 
    	 created_user = userService.create(user);
    	 emailService.validateMail(created_user);
	     return created_user;
    }

    @GetMapping(path = {"/{id}"})
    public User findOne(@PathVariable("id") int id){
        return userService.findById(id);
    }
    
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateTopic(@RequestBody User user, @PathVariable("id") int id) {
    	userService.update(user,id);
		return new ResponseEntity<Object>(user, HttpStatus.OK);
	}
    
    @DeleteMapping(path ={"/{id}"})
    public User delete(@PathVariable("id") int id) {
        return userService.delete(id);
    }

    @GetMapping
    public List<User> findAll(){
        return userService.findAll();
    }
    

    @GetMapping(path ={"/hello"})
    public String hello(){
        return "From Spring Boot App";
    }
    
    @RequestMapping("/hi")
	public String hi() {
		return "Hello World from Restful API";
	}
}
