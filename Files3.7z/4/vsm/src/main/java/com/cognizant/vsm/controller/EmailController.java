package com.cognizant.vsm.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.vsm.domain.EmailRequest;
import com.cognizant.vsm.services.EmailSender;

@RestController
public class EmailController {

	
	@Autowired
	private EmailSender emailSender;
	
	@RequestMapping("/SendEmail")
	public String sendMail()
	{		
		 EmailRequest emailData = new EmailRequest();
		 emailData.Recipient = "JeyaGandhiRajan.MUTHU@cognizant.com";
		 emailData.Subject = "VSM Java";
		 Date date = new Date();
		 final DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		 emailData.Message = "You download link for VSM Java from Cognizant. Sent at " + sdf.format(date);
		 if(emailData.Recipient.toLowerCase().endsWith("@cognizant.com"))
		 {
			 return "Yes Valid Email";
		 }
		 return "Invalid Email";
	}
	
}
