package com.cognizant.vsm.services;

import com.cognizant.vsm.domain.EmailRequest;

public interface IEmailService {

	void sendVSMMail(EmailRequest emailData);

}