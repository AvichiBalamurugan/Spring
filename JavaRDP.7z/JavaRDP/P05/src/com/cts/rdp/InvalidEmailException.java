package com.cts.rdp;

public class InvalidEmailException extends Exception {

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;

	public InvalidEmailException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
