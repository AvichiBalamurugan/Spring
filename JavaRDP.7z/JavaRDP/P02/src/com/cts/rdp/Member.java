package com.cts.rdp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Member {
	private Long id;
	private String firstName;
	private String lastName;
	private String email;
	private String contactNumber;
	private String licenseNumber;
	private Date licenseStartDate;
	private Date licenseExpiryDate;
	private ArrayList<MemberCar> carList = new ArrayList<MemberCar>();

	public List<MemberCar> getCarList() {
		return carList;
	}

	public void setCarList(ArrayList<MemberCar> carList) {
		this.carList = carList;
	}

	public static Member findMember(Long id, List<Member> mlist) {
		for (Member m : mlist) {
			if (m.getId() == id) {
				return m;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return "Name: " + getFirstName() + " , " + getLastName() + "\nMember contact details: " + getContactNumber()
				+ " , " + getEmail();
	}

	public Member() {
	}

	public Member(Long id, String firstName, String lastName, String email, String contactNumber, String licenseNumber,
			Date licenseStartDate, Date licenseExpiryDate) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.contactNumber = contactNumber;
		this.licenseNumber = licenseNumber;
		this.licenseStartDate = licenseStartDate;
		this.licenseExpiryDate = licenseExpiryDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public Date getLicenseStartDate() {
		return licenseStartDate;
	}

	public void setLicenseStartDate(Date licenseStartDate) {
		this.licenseStartDate = licenseStartDate;
	}

	public Date getLicenseExpiryDate() {
		return licenseExpiryDate;
	}

	public void setLicenseExpiryDate(Date licenseExpiryDate) {
		this.licenseExpiryDate = licenseExpiryDate;
	}
}
