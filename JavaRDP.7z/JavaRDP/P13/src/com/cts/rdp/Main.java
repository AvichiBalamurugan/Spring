package com.cts.rdp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) throws IOException {

		ArrayList<Car> carList = new ArrayList<Car>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			String menu = "Menu: \n1) Add a Car\n" + "2) Find a Car\n" + "3) Find CarList\n" + "4) Exit";
			System.out.println(menu);
			// fill the code
			int option = Integer.parseInt(br.readLine());
			if (option == 1) {
				// fill the code
				carList.add(Car.addCar(br));
			}
			if (option == 2) {
				System.out.println("Licence Number");
				String licNo = br.readLine();
				if (Car.findCar(licNo, carList) != null)
					System.out.println(Car.findCar(licNo, carList));
				else
					System.out.println("Licence Number not present");
				// fill the code
			}
			if (option == 3) {
				ArrayList<Car> carList1 = new ArrayList<Car>();
				System.out.println("Model");
				String model = br.readLine();
				carList1 = Car.findCarList(model, carList);
				if (carList1 != null) {
					for (Car c : carList1) {
						System.out.println(c);
					}
				} else
					System.out.println("Car " + model + " not found");

			}
			if (option == 4) {
				// fill the code
				System.exit(0);
			}

		}
	}
}
