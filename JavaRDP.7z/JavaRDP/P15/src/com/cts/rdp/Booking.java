package com.cts.rdp;

import java.util.Date;

public class Booking {

	// fill the code
	private Long bookingId;
	private Date dateTimeOfService;
	private String paymentMode;
	private Customer Customer;
	private Car Car;

	private Double amount;
	private String serviceEngineer;

	public Booking(Long bookingId, Date dateTimeOfService, String paymentMode, Customer customer, Car car,
			Double amount, String serviceEngineer) {
		super();
		this.bookingId = bookingId;
		this.dateTimeOfService = dateTimeOfService;
		this.paymentMode = paymentMode;
		Customer = customer;
		Car = car;
		this.amount = amount;
		this.serviceEngineer = serviceEngineer;
	}

	public Booking() {
		super();
	}

	public Long getBookingId() {
		return bookingId;
	}

	public void setBookingId(Long bookingId) {
		this.bookingId = bookingId;
	}

	public Date getDateTimeOfService() {
		return dateTimeOfService;
	}

	public void setDateTimeOfService(Date dateTimeOfService) {
		this.dateTimeOfService = dateTimeOfService;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Customer getCustomer() {
		return Customer;
	}

	public void setCustomer(Customer customer) {
		Customer = customer;
	}

	public Car getCar() {
		return Car;
	}

	public void setCar(Car car) {
		Car = car;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getServiceEngineer() {
		return serviceEngineer;
	}

	public void setServiceEngineer(String serviceEngineer) {
		this.serviceEngineer = serviceEngineer;
	}

}
