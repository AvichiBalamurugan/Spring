package com.springboot.type;

import java.util.List;

public interface ServiceInterface {

	List<Type> getAllTypes();

	Type getType(String id);

	Type addType(Type type);

	Type updateType(Type type, String id);

	Type deleteType(String id);

}