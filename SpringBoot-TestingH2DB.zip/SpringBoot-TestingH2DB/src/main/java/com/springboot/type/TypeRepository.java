package com.springboot.type;

import org.springframework.data.repository.CrudRepository;

public interface TypeRepository extends CrudRepository<Type,String> {

	
}