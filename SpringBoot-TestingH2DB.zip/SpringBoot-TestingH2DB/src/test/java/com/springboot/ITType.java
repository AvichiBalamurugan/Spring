package com.springboot;

import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springboot.type.Type;
import com.springboot.type.TypeRepository;

import net.minidev.json.parser.ParseException;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBootBurgApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ITType {

	final static Logger logger = Logger.getLogger(ITType.class);
	
	@LocalServerPort
	private int port;
	
	HttpHeaders headers = new HttpHeaders();

	TestRestTemplate restTemplate = new TestRestTemplate();
	
	ObjectMapper mapper = new ObjectMapper();
	
	@Autowired
	private TypeRepository trepo;
	
	@Test
	public void testCreateType() throws JsonProcessingException, JSONException{
    
		   Type object = new Type("testpost","tests","Integration Testing POST");
		   String jsonval = mapper.writeValueAsString(object);
		   headers.setContentType(MediaType.APPLICATION_JSON);
		   HttpEntity<Type> request = new HttpEntity<>(object, headers);
		   ResponseEntity<String> response = restTemplate
		      		  .exchange(createURLWithPort("/types"), HttpMethod.POST, request, String.class);
		  String result_value = response.getBody();
		  logger.info("This is info of object result: " + result_value);
		  logger.info("This is info of object : " + jsonval);
		  //Delete the data added for testing
		  trepo.delete(object.getId());
		  assertEquals(HttpStatus.CREATED, response.getStatusCode());
		  JSONAssert.assertEquals(jsonval, result_value, true);

	}
	
	@Test
	public void testCreateTypeError() throws JsonProcessingException, JSONException{
    
       Type object = new Type("testpost","","");
	   headers.setContentType(MediaType.APPLICATION_JSON);
	   HttpEntity<Type> request = new HttpEntity<>(object, headers);
	   ResponseEntity<Type> response = restTemplate
	      		  .exchange(createURLWithPort("/types"), HttpMethod.POST, request, Type.class);
	  logger.info("This is info of object : " + response.toString());
	  assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	  assertNull(response.getBody().getId());
	

	}
	
	@Test
	public void testGetType() throws JsonProcessingException, JSONException{
	 
	  Type type = new Type("testGet","tests","Integration Testing POST");
	  trepo.save(type);
	  String jsonval = mapper.writeValueAsString(type);
	  String typeId = type.getId();
       
	  String uri = createURLWithPort("/types/")+ typeId;
	  //Now make a call to the API to get details
	  String result = restTemplate.getForObject(uri, String.class);
	  //Verify that the data from the API and data saved in the DB are same
	  assertNotNull(result);
	  logger.info("This is info of object : " + result);
	  logger.info("This is info of object : " + jsonval);
	  //Delete the Test data created
	  JSONAssert.assertEquals(jsonval, result, false);
	  trepo.delete(typeId);
	}
	
	@Test
	public void testGetTypeError() throws JsonProcessingException, JSONException, ParseException{
	 
	  String typeId = "String";
	  
	  String uri = createURLWithPort("/types/")+ typeId;
	
	  String result = restTemplate.getForObject(uri, String.class);
	 
	  logger.info("This is info of object : " + result);
	 
	  assertThat(result, containsString("\"status\":404"));
	  assertThat(result, containsString("\"message\":\"No type found\""));
	}
	
	
	@Test
	public void testGetAllTypes(){
		  String uri = createURLWithPort("/types");		
		  ResponseEntity<Object[]> responseEntity = restTemplate.getForEntity(uri, Object[].class);
		  Object[] objects = responseEntity.getBody();
		  System.out.print(objects);
		  logger.info("This is info of object from DB : " + objects.length);
		  assertTrue(objects.length == 0);
		  Type object = new Type("test8", "test8", "Desc1");
		  trepo.save(object);
     	  Type object2 = new Type("test9", "test8", "Desc2");
		  trepo.save(object2);
		  ResponseEntity<Object[]> responseEntity1 = restTemplate.getForEntity(uri, Object[].class);
		  Object[] objects2 = responseEntity1.getBody();
		  logger.info("This is info of object from DB : " + objects2.length);
		  assertTrue(objects2.length == 2);
		  trepo.delete(object.getId());
		  trepo.delete(object2.getId());
		  List<Type> obj = (List<Type>) trepo.findAll();
		  logger.info("This is info of object list : " + obj.toString());
	}
	
	
	@Test
	public void testUpdateType() throws JsonProcessingException, JSONException{
		Type object = new Type("test8", "test8", "Desc1");
		trepo.save(object);
		Type type = new Type("test8","testing","tested");
        String typeId = object.getId();
  	    String jsonval = mapper.writeValueAsString(type);
        String uri = createURLWithPort("/types/")+typeId;
        logger.info("This is info of updated object URL : " + uri);
        HttpEntity<Type> entity = new HttpEntity<Type>(type, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.PUT, entity, String.class);
        String result_value = response.getBody();
        logger.info("This is updated info response : " + result_value);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        Type typeFromDb = trepo.findOne(typeId);
     	logger.info("This is info of object from DB : " + typeFromDb.getDescription());
     	JSONAssert.assertEquals(jsonval, result_value, true);
     	trepo.delete(typeId);
	}
	
	@Test
	public void testUpdateTypeError() throws JsonProcessingException, JSONException{
		Type type = new Type("test8","testing","tested");
        String typeId = type.getId();
        String uri = createURLWithPort("/types/")+typeId;
        logger.info("This is info of updated object URL : " + uri);
        HttpEntity<Type> entity = new HttpEntity<Type>(type, headers);
        ResponseEntity<Type> response = restTemplate.exchange(uri, HttpMethod.PUT, entity, Type.class);
        logger.info("This is updated info error response : " + response.toString());
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());      
	}
	
	@Test
	public void testUpdateTypeFoundError() throws JsonProcessingException, JSONException{
		Type object = new Type("test8", "test8", "Desc1");
		trepo.save(object);
		Type type = new Type("test8","","");
        String typeId = object.getId();
        String uri = createURLWithPort("/types/")+typeId;
        logger.info("This is info of updated object URL : " + uri);
        HttpEntity<Type> entity = new HttpEntity<Type>(type, headers);
        ResponseEntity<Type> response = restTemplate.exchange(uri, HttpMethod.PUT, entity, Type.class);
        logger.info("This is updated info error response : " + response.toString());
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode()); 
        trepo.delete(typeId);
	}
	
	@Test
	public void testDeleteType() throws JsonProcessingException{
		Type object = new Type("test8", "test8", "Author1");
	    trepo.save(object);
        String typeId = object.getId();
        final String uri = "/types/{id}";
     	Map<String, String> params = new HashMap<String, String>();
     	params.put("id", typeId);
     	restTemplate.delete(createURLWithPort(uri), params);
     	Type typeFromDb = trepo.findOne(typeId);
     	  //and assert that there is no data found
     	  assertNull(typeFromDb);
     	 
	}
	
	@Test
	public void testDeleteTypeError() throws JsonProcessingException{
		String typeId = "testDelete";
        final String uri = "/types/"+typeId;
       	ResponseEntity<String> response = restTemplate.exchange(createURLWithPort(uri), HttpMethod.DELETE, null, String.class);  
     	assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode()); 
     	logger.info("This is updated info delete error response : " + response.toString());
	}
	
	
	private String createURLWithPort(String uri) {
		return "http://localhost:" + port + uri;
	}
}
