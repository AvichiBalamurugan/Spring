package com.springboot;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.springboot.type.Type;
import com.springboot.type.TypeRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
public class UTTypeRepository{

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private TypeRepository typeRepository;
    
	@Test
	public void no_types_found_if_repository_is_empty() {
		Iterable<Type> types = typeRepository.findAll();
 
		assertThat(types).isEmpty();
	}
	

	@Test
	public void should_save_type() {
		Type type = typeRepository.save(new Type("checkID", "checkName","checkDesc"));
 
		assertThat(type).hasFieldOrPropertyWithValue("id", "checkID");
		assertThat(type).hasFieldOrPropertyWithValue("name", "checkName");
		assertThat(type).hasFieldOrPropertyWithValue("description", "checkDesc");
	}
	
	@Test
	public void should_delete_all_types() {
		entityManager.persist(new Type("checkID_1", "checkName","checkDesc"));
		entityManager.persist(new Type("checkID_2", "checkName","checkDesc"));
 
		typeRepository.deleteAll();
 
		assertThat(typeRepository.findAll()).isEmpty();
	}
	
	@Test
	public void should_delete_by_type_id() {
		entityManager.persist(new Type("checkID_1", "checkName","checkDesc"));
 
		typeRepository.delete("checkID_1");
 
		assertNull(typeRepository.findOne("checkID_1"));
	}
	
	@Test
	public void should_find_all_types() {
		Type type_1 = new Type("checkID_1", "checkName","checkDesc");
		entityManager.persist(type_1);
 
		Type type_2 = new Type("checkID_2", "checkName","checkDesc");
		entityManager.persist(type_2);
 
		Type type_3 = new Type("checkID_3", "checkName","checkDesc");
		entityManager.persist(type_3);
 
		Iterable<Type> types = typeRepository.findAll();
 
		assertThat(types).hasSize(3).contains(type_1, type_2, type_3);
	}
	
	@Test
	public void should_find_type_by_id() {
		Type type_1 = new Type("checkID_1", "checkName","checkDesc");
		entityManager.persist(type_1);
 
		Type type_2 = new Type("checkID_2", "checkName","checkDesc");
		entityManager.persist(type_2);
 
		Type found_Type = typeRepository.findOne(type_2.getId());
 
		assertThat(found_Type).isEqualTo(type_2);
	}

	
}