package com.springboot;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;

import com.springboot.exception.NoTypesFoundException;
import com.springboot.exception.NoValuesFoundException;
import com.springboot.type.Type;
import com.springboot.type.TypeRepository;
import com.springboot.type.TypeService;

public class UTTypeService extends SpringBootBurgApplicationTests {

   final static Logger logger = Logger.getLogger(UTTypeService.class);
   
   private static final String ID = "TestID";
   private static final String NAME = "TestName";
   private static final String NAME_UPDATED = "updatedName";
   private static final String DESCRIPTION = "TestDescription";
   private static final String DESCRIPTION_UPDATED = "updatedDescription";

    private TypeService typeService;

    private TypeRepository typeRepositoryMock;
    
    @Before
    public void setUp() {
    	typeRepositoryMock = Mockito.mock(TypeRepository.class);

    	typeService = new TypeService(typeRepositoryMock);
    	
      }
    @Test
    public void add_NewType_SaveType() {
        Type object = new Type(ID,NAME,DESCRIPTION);

        typeService.addType(object);
        ArgumentCaptor<Type> typeArgument = ArgumentCaptor.forClass(Type.class);
        verify(typeRepositoryMock, times(1)).save(typeArgument.capture());
        verifyNoMoreInteractions(typeRepositoryMock);
        logger.info("This is info of TYPE ARGUMENT: " +typeArgument.getValue().toString());
        Type value = typeArgument.getValue();

        assertNotNull(value.getId());
        assertThat(value.getName(), is(object.getName()));
        assertThat(value.getDescription(), is(object.getDescription()));
        
        logger.info("This is info of value ID : " + value.getId());
        logger.info("This is info of value Name : " + value.getName());
        logger.info("This is info of value Description : " + value.getDescription());
    }
   
    @Test(expected = NoValuesFoundException.class)
    public void add_NewType_ThrowException() throws NoValuesFoundException{
        Type object = new Type(ID,"","");
        typeService.addType(object);
    }
    
    @Test
    public void deleteById_TypeFound_DeleteTypeEntryAndReturnIt() throws NoTypesFoundException {
    	Type object = new Type(ID,NAME,DESCRIPTION);

        when(typeRepositoryMock.findOne(ID)).thenReturn(object);

        Type value = typeService.deleteType(ID);

        verify(typeRepositoryMock, times(1)).findOne(ID);
        verify(typeRepositoryMock, times(1)).delete(ID);
        verifyNoMoreInteractions(typeRepositoryMock);

        assertThat(value, is(object));
    }
    
    @Test(expected = NoTypesFoundException.class)
    public void deleteById_TypeNotFound_ThrowException() throws NoTypesFoundException {
        when(typeRepositoryMock.findOne(ID)).thenReturn(null);

        typeService.deleteType(ID);

        verify(typeRepositoryMock, times(1)).findOne(ID);
        verifyNoMoreInteractions(typeRepositoryMock);
    }
    
    @Test
    public void findAll_ReturnListOfTypes() {
        List<Type> types = new ArrayList<>();
        when(typeRepositoryMock.findAll()).thenReturn(types);

        List<Type> values = typeService.getAllTypes();

        verify(typeRepositoryMock, times(1)).findAll();
        verifyNoMoreInteractions(typeRepositoryMock);

        assertThat(values, is(types));
    }
    
    @Test
    public void findById_TypeFound_ReturnFoundType() throws NoTypesFoundException {
    	Type object = new Type(ID,NAME,DESCRIPTION);

        when(typeRepositoryMock.findOne(ID)).thenReturn(object);

        Type value = typeService.getType(ID);

        verify(typeRepositoryMock, times(1)).findOne(ID);
        verifyNoMoreInteractions(typeRepositoryMock);

        assertThat(value, is(object));
    }
    
    @Test(expected = NoTypesFoundException.class)
    public void findById_TypeNotFound_ThrowException() throws NoTypesFoundException {
        when(typeRepositoryMock.findOne(ID)).thenReturn(null);

        typeService.getType(ID);

        verify(typeRepositoryMock, times(1)).findOne(ID);
        verifyNoMoreInteractions(typeRepositoryMock);
    }
    
    @Test
    public void update_TypeFound_UpdateType() throws NoTypesFoundException {
    Type object = new Type(ID,NAME,DESCRIPTION);
    Type updated_object = new Type(ID,NAME_UPDATED,DESCRIPTION_UPDATED);
     when(typeRepositoryMock.findOne(updated_object.getId())).thenReturn(object);
     typeService.updateType(updated_object, ID);
     ArgumentCaptor<Type> typeArgument = ArgumentCaptor.forClass(Type.class);
     verify(typeRepositoryMock, times(1)).save(typeArgument.capture());
     Type value = typeArgument.getValue();
     assertNotNull(value.getId());
     assertThat(value.getName(), is(updated_object.getName()));
     assertThat(value.getDescription(), is(updated_object.getDescription()));
     
     logger.info("This is info of updated value ID : " + value.getId());
     logger.info("This is info of updated value Name : " + value.getName());
     logger.info("This is info of updated value Description : " + value.getDescription());
    }
    
    @Test(expected = NoTypesFoundException.class)
    public void update_TypeNotFound_ThrowException() throws NoTypesFoundException {
    	Type updated_object = new Type(ID,NAME_UPDATED,DESCRIPTION_UPDATED);
        
        when(typeRepositoryMock.findOne(updated_object.getId())).thenReturn(null);

        typeService.updateType(updated_object, ID);

        verify(typeRepositoryMock, times(1)).findOne(updated_object.getId());
        verifyNoMoreInteractions(typeRepositoryMock);
    }
    
}
