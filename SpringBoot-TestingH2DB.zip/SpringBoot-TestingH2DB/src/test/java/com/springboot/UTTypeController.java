package com.springboot;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.springboot.exception.NoTypesFoundException;
import com.springboot.exception.NoValuesFoundException;
import com.springboot.type.Type;
import com.springboot.type.TypeController;
import com.springboot.type.TypeService;

@RunWith(SpringRunner.class)
@ContextConfiguration({"classpath*:spring-test.xml"})
public class UTTypeController{
	    
	    public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	    @Mock
	    private TypeService typeService;
	         
	    private MockMvc mockMvc;
	    
	    @InjectMocks
	    private TypeController typeController;
	    
	    @Before
	    public void setup() {
	        MockitoAnnotations.initMocks(this);
	        this.mockMvc = MockMvcBuilders.standaloneSetup(typeController).build();	 
	    }
	   	    
	    @Test
	    public void testGetType() throws Exception {
	        when(typeService.getType("test")).thenReturn(new Type("test","testing","test_desc"));
	 
	        mockMvc.perform(get("/types/{id}", "test"))
	                .andExpect(status().isOk())
	                .andDo(print());
	    }
	    
	    @Test
	    public void testGetTypeError() throws Exception {
	        when(typeService.getType("test")).thenThrow(new NoTypesFoundException());
	 
	        mockMvc.perform(get("/types/{id}", "test"))
	                .andExpect(status().is4xxClientError())
	                .andDo(print());
	    }
	    
	    @Test
	    public void testPostType() throws Exception {
	          	
	    	Type object = new Type("TestID","test","testing");
	    	when(typeService.addType(object)).thenReturn(object);
	    	
	        mockMvc.perform(post("/types")
	            .contentType(APPLICATION_JSON_UTF8)
	            .content(TestUtil.ObjecttoJSON(object)))
	            .andExpect(status().isCreated())
	            .andExpect(jsonPath("$.id", is("TestID")))
	            .andExpect(jsonPath("$.name", is("test")))
	            .andExpect(jsonPath("$.description", notNullValue()))
	            .andDo(print());
	       }
	    
	    @Test
	    public void testPostTypeError() throws Exception {
	          	
	    	Type object = new Type("TestID","Test", null);
	    	when(typeService.addType(object)).thenThrow(new NoValuesFoundException());
	    	
	        mockMvc.perform(post("/types")
	            .contentType(APPLICATION_JSON_UTF8)
	            .content(asJsonString(object)))
	            .andExpect(status().isBadRequest())
	            .andDo(print());
	       }
	    
	    @Test
	    public void testListAllTypes() throws Exception {
	        List<Type> types = Arrays.asList(
	                new Type("ID1", "Test", "Desc"),
	                new Type("ID2", "Testing", "Description"));
	        when(typeService.getAllTypes()).thenReturn(types);
	        mockMvc.perform(get("/types"))
	                .andExpect(status().isOk())
	                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
	                .andExpect(jsonPath("$[0].id", is("ID1")))
	                .andExpect(jsonPath("$[0].name", is("Test")))
	                .andExpect(jsonPath("$[0].description", is("Desc")))
	                .andExpect(jsonPath("$[1].id", is("ID2")))
	                .andExpect(jsonPath("$[1].name", is("Testing")))
	                .andExpect(jsonPath("$[1].description", is("Description")))
	                .andDo(print());
	        verify(typeService, times(1)).getAllTypes();
	        verifyNoMoreInteractions(typeService);
	    }
	    
	    @Test
	    public void testUpdateType() throws Exception {
	    	Type type_1 = new Type("ID1", "Test", "Desc");
	    	Type type_2 = new Type("ID1", "Testing", "Desc");

	        when(typeService.getType(type_2.getId())).thenReturn(type_1);
	        when(typeService.updateType(type_2, type_2.getId())).thenReturn(type_2);

	        mockMvc.perform(
	                put("/types/{id}", type_2.getId())
	                        .contentType(MediaType.APPLICATION_JSON)
	                        .content(asJsonString(type_2)))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$.name", is("Testing")))
	                .andDo(print());

	    }
	    
	    @Test
	    public void testUpdateTypeError() throws Exception {
	    	Type type_2 = new Type("Check", "Testing", "Desc");

	    	when(typeService.getType(type_2.getId())).thenThrow(new NoTypesFoundException());

	        mockMvc.perform(
	                put("/users/{id}", type_2.getId())
	                        .contentType(MediaType.APPLICATION_JSON)
	                        .content(asJsonString(type_2)))
	                .andExpect(status().isNotFound())
	                .andDo(print());

	    }
	    
	    @Test
	    public void testDeleteType() throws Exception {
	    	Type type_2 = new Type("ID1", "Testing_Delete", "Desc");

	        when(typeService.getType(type_2.getId())).thenReturn(type_2);
	        when(typeService.deleteType(type_2.getId())).thenReturn(null);

	        mockMvc.perform(
	        		delete("/types/{id}", type_2.getId()))
	                .andExpect(status().isOk())
	                .andDo(print());	        

	    }
	    
	    @Test
	    public void testDeleteTypeError() throws Exception {
	    	when(typeService.deleteType("check")).thenThrow(new NoTypesFoundException());

	        mockMvc.perform(
	        		delete("/types/{id}", "check"))
	        		.andExpect(status().isNotFound())
	                .andDo(print());	        

	    }
	       
	    public static String asJsonString(final Object obj) {
	        try {
	            return new ObjectMapper().writeValueAsString(obj);
	        } catch (Exception e) {
	            throw new RuntimeException(e);
	        }
	    }
}
