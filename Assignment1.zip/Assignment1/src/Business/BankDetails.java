/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author shubh
 */
public class BankDetails {
    
    private String bankname;
    private String routingnumber;
    private String savingaccountnumber;
    private String savingbalance;
    private String currentaccountnumber;
    private String currentbalance;
    

    public String getBankname() {
        return bankname;
    }

    public void setBankname(String bankname) {
        this.bankname = bankname;
    }

    public String getRoutingnumber() {
        return routingnumber;
    }

    public void setRoutingnumber(String routingnumber) {
        this.routingnumber = routingnumber;
    }

    public String getSavingaccountnumber() {
        return savingaccountnumber;
    }

    public void setSavingaccountnumber(String savingaccountnumber) {
        this.savingaccountnumber = savingaccountnumber;
    }

    public String getSavingbalance() {
        return savingbalance;
    }

    public void setSavingbalance(String savingbalance) {
        this.savingbalance = savingbalance;
    }

    public String getCurrentaccountnumber() {
        return currentaccountnumber;
    }

    public void setCurrentaccountnumber(String currentaccountnumber) {
        this.currentaccountnumber = currentaccountnumber;
    }

    public String getCurrentbalance() {
        return currentbalance;
    }

    public void setCurrentbalance(String currentbalance) {
        this.currentbalance = currentbalance;
    }
 
    
    
}
