
package com.cts.spring.book.repository;

import java.awt.print.Book;
import org.springframework.data.repository.CrudRepository;

public interface BookRepository extends CrudRepository<Book, String> {

}
