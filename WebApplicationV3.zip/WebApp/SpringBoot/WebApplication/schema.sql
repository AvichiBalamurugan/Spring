CREATE TABLE IF NOT EXISTS Population (
    year int(40),
    total int(40),
    male int(40),
    female int (40)
);