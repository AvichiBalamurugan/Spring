package com.cognizant.pcfsupport.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.cognizant.pcfsupport.PcfSupportToolApplication;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = PcfSupportToolApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RunnerMemoryControllerTest{

	@LocalServerPort
	private int port;

	final static Logger logger = Logger.getLogger(RunnerMemoryControllerTest.class);
	
	HttpHeaders headers = new HttpHeaders();
	
	public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
	
	private TestRestTemplate restTemplate = new TestRestTemplate();
	  
	@Test
	public void testgetFreeMemory(){
		
		String url = createURLWithPort("/GetMemory");
		String responseObject = restTemplate.getForObject(url, String.class);
		logger.info("This is the response: " + responseObject);
		assertNotNull(responseObject);
		assertThat(responseObject).contains("Total App Memory Used: ");
	}
	
	@Test
	public void testGetCfProductSummary(){
		
		String url = createURLWithPort("/GetCfProductSummary");
		String responseObject = restTemplate.getForObject(url, String.class);
		logger.info("This is the response: " + responseObject);
		assertNotNull(responseObject);
		assertThat(responseObject).contains("Product GUID: ");
	}
	
	@Test
	public void testGetTotalMemory(){
		
		String url = createURLWithPort("/GetTotalMemory");
		String responseObject = restTemplate.getForObject(url, String.class);
		logger.info("This is the response: " + responseObject);
		assertNotNull(responseObject);
		assertThat(responseObject).contains("Total Memory of Diego: ");
	}
	
	private String createURLWithPort(String uri) {
		return "http://localhost:" + port + uri;
	}
}
