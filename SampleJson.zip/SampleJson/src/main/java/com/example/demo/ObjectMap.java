package com.example.demo;

import java.io.IOException;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

@Component
public class ObjectMap {
	 private final Logger logger = LoggerFactory.getLogger(this.getClass());
	    public int readJsonWithObjectMapper() throws JsonParseException, JsonMappingException, IOException, UnirestException, JSONException {
	   	int memory = 0;

	    HttpResponse<String> response = Unirest.get("https://login.system.dev.digifabricpcf.com/oauth/token?username=pcfadmin&password=pcfadmin123&grant_type=password")
	    		  .header("authorization", "Basic Y2Y6")
	    		  .asString();
	    final JsonNode jsonNode = new ObjectMapper().readTree(response.getBody()).get("access_token");
	    logger.info("****************Token**********" + jsonNode);
	    String bearer = "Bearer "+jsonNode.toString();
	    bearer = bearer.replace("\"", "");
	    HttpResponse<String> appsResponse = Unirest.get("https://api.system.dev.digifabricpcf.com//v2/apps?&page=1&results-per-page=100")
	    		  .header("authorization", bearer)
	    		  .asString();
	    
	    logger.info("****************Response**********" + appsResponse.getBody());

	    final JsonNode page = new ObjectMapper().readTree(appsResponse.getBody()).get("total_pages");
	    int pages = page.asInt();
	    for(int i=1;i<=pages;i++) {
	    	String apiURL = "https://api.system.dev.digifabricpcf.com//v2/apps?&page="+ Integer.toString(i) +"&results-per-page=100";
	    	logger.info("****************API URL**********" + apiURL);
	    	 HttpResponse<String> nextAppResponse = Unirest.get(apiURL)
		    		  .header("authorization", bearer)
		    		  .asString();
	    final JsonNode arrNode = new ObjectMapper().readTree(nextAppResponse.getBody()).get("resources");
	    if (arrNode.isArray()) {
	        for (final JsonNode objNode : arrNode) {
	        	JsonNode entity = objNode.get("entity");
	        	JsonNode state = entity.get("state");
	        	String status = "\"STARTED\"";
	        	if(state.toString().equals(status))
	        	{
	        	JsonNode entityMemory = entity.get("memory");
	        	
	        memory = memory + entityMemory.asInt();
//	            logger.info("****************resource**********" + entity);
//	            logger.info("****************resource**********" + state);
//	            logger.info("****************resource**********" + state.toString());
//	            logger.info("****************resource**********" + status);
//	         	logger.info("****************resource Entity**********" + entityMemory);
          	}	
          }
	    }	       
	    }
	    logger.info("****************Total Memory**********" + memory);
	    	return memory;
	    }
}

