package com.example.demo.entity;

public class Result {

	private Resources resource;

	public Resources getResource() {
		return resource;
	}

	public void setResource(Resources resource) {
		this.resource = resource;
	}

}
