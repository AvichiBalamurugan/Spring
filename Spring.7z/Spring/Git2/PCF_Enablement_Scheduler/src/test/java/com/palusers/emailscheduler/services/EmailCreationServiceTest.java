package com.palusers.emailscheduler.services;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import com.palusers.emailscheduler.services.EmailCreationService;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import com.palusers.emailscheduler.domain.EmailEntity;
import com.palusers.emailscheduler.repository.EmailRepository;

public class EmailCreationServiceTest {

	private EmailCreationService emailCreationServiceMock;
	private EmailRepository emailRepositoryMock;	
	
	@Before
	public void setup() throws Exception
	{
		emailRepositoryMock = Mockito.mock(EmailRepository.class);
		emailCreationServiceMock = new EmailCreationService(emailRepositoryMock);		
	}
	
	@Test
    public void sendRegistrationEmail() throws Exception
    {			
		when(emailRepositoryMock.findAll()).thenReturn(getEmailEntities());
		List<EmailEntity> result = emailCreationServiceMock.listAll();
		assertEquals("receipient", result.get(0).getReceipient());			
    }
	
	@Test
    public void deleteEmail() throws Exception
    {	
		emailCreationServiceMock.deleteEmail(1L);
		verify(emailRepositoryMock, times(1)).delete(1L);	
    }
	
	@Test
    public void saveOrUpdate() throws Exception
    {			
		when(emailRepositoryMock.save(getEmailEntity())).thenReturn(getEmailEntity());
		EmailEntity result = emailCreationServiceMock.saveOrUpdate(getEmailEntity());
		assertEquals("receipient", result.getReceipient());			
    }
	
	@Test
    public void FindNotSentlist() throws Exception
    {			
		when(emailCreationServiceMock.findNotSentlist("status")).thenReturn(getEmailEntities());
		List<EmailEntity> result = emailCreationServiceMock.findNotSentlist("status");
		assertEquals("receipient", result.get(0).getReceipient());			
    }
	
	@Test
    public void UpdateEmailStatus() throws Exception
    {	
		LocalDateTime dt = LocalDateTime.now();
		emailRepositoryMock.updateEmailStatus("emailid", "activationstatus", Timestamp.valueOf(dt));
		verify(emailRepositoryMock, times(1)).updateEmailStatus("emailid", "activationstatus", Timestamp.valueOf(dt));	
    }
	
	private EmailEntity getEmailEntity()
	{
		EmailEntity e1 = new EmailEntity();
		e1.setReceipient("receipient");		
		return e1;
	}
	
	private List<EmailEntity> getEmailEntities()
	{
		List<EmailEntity> lstEmails = new ArrayList<EmailEntity>();
		EmailEntity e1 = new EmailEntity();
		e1.setReceipient("receipient");
		lstEmails.add(e1);
		return lstEmails;
	}
}
