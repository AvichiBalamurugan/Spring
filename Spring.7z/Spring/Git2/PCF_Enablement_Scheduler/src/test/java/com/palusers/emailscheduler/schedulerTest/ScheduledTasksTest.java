package com.palusers.emailscheduler.schedulerTest;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import com.palusers.emailscheduler.scheduler.ScheduledTasks;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.palusers.emailscheduler.scheduler.ScheduledTasks;

public class ScheduledTasksTest {

	private ScheduledTasks scheduledTasks;
	@Before
	public void setup() 
	{
		scheduledTasks = Mockito.mock(ScheduledTasks.class);				
	}
	
	@Test
    public void runJob() 
    {	
		scheduledTasks.runEmailJob();
		verify(scheduledTasks, times(1)).runEmailJob();	
    }
}
