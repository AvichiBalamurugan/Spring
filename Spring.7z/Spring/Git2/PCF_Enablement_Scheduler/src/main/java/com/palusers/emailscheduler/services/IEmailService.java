package com.palusers.emailscheduler.services;

import com.palusers.emailscheduler.domain.EmailRequest;
import com.palusers.emailscheduler.domain.PCFRunner;
import com.palusers.emailscheduler.domain.UserMailEntity;

public interface IEmailService {

	void sendAccountEmail(EmailRequest emailData);

	void sendErrorMail(EmailRequest emailData);

	void sendRegistrationEmail(EmailRequest emailData);

	void sendSupportTeamMail(EmailRequest emailData);

	void sendDeleteAccountRemainder(EmailRequest emailData);

	void sendDeleteAccount(EmailRequest emailData);

	void sendLimitMail(EmailRequest emailData);

	void sendUserCreationMail(UserMailEntity emailData);

	void sendMemoryMail(PCFRunner pcfInfo);

}
