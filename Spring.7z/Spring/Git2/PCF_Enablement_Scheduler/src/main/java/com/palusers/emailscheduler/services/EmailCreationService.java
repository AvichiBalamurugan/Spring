package com.palusers.emailscheduler.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.palusers.emailscheduler.domain.EmailEntity;
import com.palusers.emailscheduler.repository.EmailRepository;

@Service
public class EmailCreationService implements IEmailCreationService {

	private EmailRepository emailRepository;
	 
	@Autowired
	public EmailCreationService(EmailRepository emailRepository)
	{
		this.emailRepository = emailRepository;
	}
	
	@Override
	public List<EmailEntity> listAll() {
		List<EmailEntity> emails = new ArrayList<EmailEntity>();
		emailRepository.findAll().forEach(emails::add);
		return emails;
	}
	
	@Override
	public void deleteEmail(Long id) {
		emailRepository.delete(id);		
	}
	
	
	@Override
	public EmailEntity saveOrUpdate(EmailEntity email) {
		emailRepository.save(email);
		return email;
	}
	
	@Override
	public List<EmailEntity> findNotSentlist(String status) {
		return emailRepository.getEmailEntities(status);		
	}
	
	@Override
	public void updateEmailStatus(String emailid, String activationstatus, Date dt) {
		emailRepository.updateEmailStatus(emailid, activationstatus, dt);		
	}
}
