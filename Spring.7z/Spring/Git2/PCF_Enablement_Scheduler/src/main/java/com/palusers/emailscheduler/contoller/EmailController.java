package com.palusers.emailscheduler.contoller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.palusers.emailscheduler.configuration.EmailSenderConfig;
import com.palusers.emailscheduler.configuration.ScheduledTaskConfig;
import com.palusers.emailscheduler.domain.EmailEntity;
import com.palusers.emailscheduler.services.EmailCreationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RefreshScope
@RestController
@Api(value = "Email scheduler")
public class EmailController {

	@Autowired
	private EmailSenderConfig config;
	
	@Autowired
	private ScheduledTaskConfig config1;
	
	@Autowired
	private EmailCreationService emailCreationService;
	
	@RequestMapping("/GetEmails")
	@ApiOperation(value ="Get all emails",response = EmailEntity.class)
	public List<EmailEntity> get()
	{
		return emailCreationService.listAll();		
	}
	
	@ApiOperation(value ="Delete a particular email")	
	@RequestMapping("/DeleteEmail/{id}")
	public void deleteEmail(Long id)
	{
		emailCreationService.deleteEmail(id);		
	}
	
	// Testing
//	@GetMapping("/AllValues")
//	  public String getMessage(){
//	             		
//	      config.getAppmanagerconsole();
//	      config.getCfcli();
//	     
//	      config1.getApiurl();
//			String jsonval =  ("Appmanagerconsole: "+config.getAppmanagerconsole()+" Cfcli: "+config.getCfcli()+" Apiurl: "+   config1.getApiurl());
//			//logger.info("********************Config Values*****************" + jsonval);
//	      return jsonval;
//			    }
}
