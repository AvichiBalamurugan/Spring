package com.palusers.emailscheduler.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
public class ScheduledTaskConfig {

	
	private String supportteam;
	
	private String dotneturl;
	
	private String javaurl;
	
	private String apiurl;
	
	private String appmanagerurl;
	
	private String accountcreationurl;

	public String getSupportteam() {
		return supportteam;
	}

	public void setSupportteam(String supportteam) {
		this.supportteam = supportteam;
	}

	public String getDotneturl() {
		return dotneturl;
	}

	public void setDotneturl(String dotneturl) {
		this.dotneturl = dotneturl;
	}

	public String getJavaurl() {
		return javaurl;
	}

	public void setJavaurl(String javaurl) {
		this.javaurl = javaurl;
	}

	public String getApiurl() {
		return apiurl;
	}

	public void setApiurl(String apiurl) {
		this.apiurl = apiurl;
	}

	public String getAppmanagerurl() {
		return appmanagerurl;
	}

	public void setAppmanagerurl(String appmanagerurl) {
		this.appmanagerurl = appmanagerurl;
	}

	public String getAccountcreationurl() {
		return accountcreationurl;
	}

	public void setAccountcreationurl(String accountcreationurl) {
		this.accountcreationurl = accountcreationurl;
	}
	
	
	
}
