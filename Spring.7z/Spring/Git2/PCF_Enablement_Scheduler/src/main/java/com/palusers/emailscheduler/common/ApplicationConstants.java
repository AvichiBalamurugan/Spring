package com.palusers.emailscheduler.common;


public class ApplicationConstants {
	public enum ProgLanguage { DOTNET, JAVA}	
	public enum EmailTemplte { ACCOUNTEMAIL,ERROREMAIL,REGISTRATIONEMAIL,SUPPORTTEAMEMAIL,DELETEREMAINDEREMAIL,DELETEACCOUNTEMAIL,LIMITEMAIL}
	public enum EMAILSTATUS { SENT, NOTSENT}	
	
}



