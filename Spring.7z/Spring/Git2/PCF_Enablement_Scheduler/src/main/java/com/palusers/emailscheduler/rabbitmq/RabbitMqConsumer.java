package com.palusers.emailscheduler.rabbitmq;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.palusers.emailscheduler.domain.PCFRunner;
import com.palusers.emailscheduler.domain.UserMailEntity;
import com.palusers.emailscheduler.services.EmailSender;

@Component
public class RabbitMqConsumer {

	@Autowired
	private EmailSender emailSender;
		 
	    @RabbitListener(queues = "usermail-queue")
	    public void userEmailCreation(UserMailEntity userInfo) {
	     emailSender.sendUserCreationMail(userInfo);
	     System.out.println("Received Message :"+ userInfo);
	     System.out.println("Message Sent to " + userInfo.getUsername() + " with Subject " + userInfo.getSubject());

	    }
	    
	    @RabbitListener(queues = "spring-queue")
	    public void pcfIndo(PCFRunner pcfInfo) {
	     emailSender.sendMemoryMail(pcfInfo);
	     System.out.println("Received Message :"+ pcfInfo);
	     System.out.println("Message Sent to " + pcfInfo.getRecipient()+ " with Subject " + pcfInfo.getSubject());

	    }
	   

}