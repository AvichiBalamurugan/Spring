package com.palusers.emailscheduler.scheduler;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.palusers.emailscheduler.common.ApplicationConstants;
import com.palusers.emailscheduler.configuration.EmailSenderConfig;
import com.palusers.emailscheduler.configuration.ScheduledTaskConfig;
import com.palusers.emailscheduler.domain.EmailEntity;
import com.palusers.emailscheduler.domain.EmailRequest;
import com.palusers.emailscheduler.logger.ILogger;
import com.palusers.emailscheduler.logger.LoggerFactory;
import com.palusers.emailscheduler.services.EmailCreationService;
import com.palusers.emailscheduler.services.EmailSender;
 

@Component
public class ScheduledTasks {

	private static ILogger logger; 
	private EmailEntity emailEntity;	

	@Autowired
	private ScheduledTaskConfig config;
		
	@Autowired
	private EmailCreationService emailCreationService;
	
	@Autowired
	private EmailSender emailSender;
	
	public ScheduledTasks(LoggerFactory loggerFactory)
	{
		logger = loggerFactory.getLoggerInstance();
	}	
	 
	@Scheduled(fixedDelayString = "${fixedDelayEmailinmilliseconds}")
    public void runEmailJob() {		 
		try		
		{	
			logger.info("Email Sending Job Started at "+ LocalDateTime.now());
			
			List<EmailEntity> lstemailRequest = emailCreationService.findNotSentlist(ApplicationConstants.EMAILSTATUS.NOTSENT.name());
			if(lstemailRequest != null && lstemailRequest.size() > 0)
			{
				for (int i = 0; i < lstemailRequest.size(); i++) 
				{
					emailEntity= null;
					emailEntity  = lstemailRequest.get(i);
					if(emailEntity.getStatus().trim().equalsIgnoreCase("NOTSENT"))
					{
						logger.info("Sending email to "+ emailEntity.getReceipient().toLowerCase());
						boolean result = SendEmail();
						emailCreationService.updateEmailStatus(emailEntity.getReceipient(),ApplicationConstants.EMAILSTATUS.SENT.name(),Timestamp.valueOf(LocalDateTime.now()));
					}										
				}
			}
			else
			{
				logger.info("No Pending Emails to be sent at "+ LocalDateTime.now());
			}
			logger.info("Email Sending Job completed at "+ LocalDateTime.now());
			emailEntity =null;
		}
		catch(Exception ex)
		{
			emailCreationService.updateEmailStatus(emailEntity.getReceipient(),ApplicationConstants.EMAILSTATUS.NOTSENT.name(),Timestamp.valueOf(LocalDateTime.now()));
			logger.error(ex.getMessage());
			logger.info("Email Sending Job completed at "+ LocalDateTime.now());
			emailEntity=null;
		}
    }
	
	private boolean SendEmail()
	{
		try
		{	
			EmailRequest emailData = new EmailRequest();
			emailData.Recipient = emailEntity.getReceipient();
			emailData.HCMRecipient = emailEntity.getHcmreceipient();
			//emailData.Subject = emailEntity.getSubject();
			//emailData.Message = emailEntity;
			emailData.Username = emailEntity.getUsername();
			emailData.Password = emailEntity.getPassword();
			emailData.AppManagerUrl = config.getAppmanagerurl();
			emailData.ApiURL = config.getApiurl();
			emailData.Track = emailEntity.getTrack();
			emailData.AccountCreationUrl = config.getAccountcreationurl();
			emailData.UniqueId = emailEntity.getUniqueid();			
			if(emailEntity.getTrack() != null)
			{
				if(emailEntity.getTrack().trim().equalsIgnoreCase(ApplicationConstants.ProgLanguage.JAVA.name()))
				{
					emailData.LearningUrl = config.getJavaurl();
				}
				else if(emailEntity.getTrack().trim().equalsIgnoreCase(ApplicationConstants.ProgLanguage.DOTNET.name()))
				{
					emailData.LearningUrl = config.getDotneturl();
				}
			}
			if(emailEntity.getTemplate().trim().equalsIgnoreCase(ApplicationConstants.EmailTemplte.ACCOUNTEMAIL.name()))				
			{
				emailData.Subject=emailEntity.getSubject();
				emailSender.sendAccountEmail(emailData);	
				logger.info("Email Sent to.." + emailEntity.getReceipient());
			}
			else if(emailEntity.getTemplate().trim().equalsIgnoreCase(ApplicationConstants.EmailTemplte.REGISTRATIONEMAIL.name()))
			{
				emailData.Subject= emailEntity.getSubject();
				emailSender.sendRegistrationEmail(emailData);	
				logger.info("Email Sent to.." + emailEntity.getReceipient());
			}
			else if(emailEntity.getTemplate().trim().equalsIgnoreCase(ApplicationConstants.EmailTemplte.ERROREMAIL.name()))
			{
				emailData.Subject= emailEntity.getSubject();
				emailData.Message= emailEntity.getMessage();
				emailSender.sendErrorMail(emailData);		
				logger.info("Email Sent to.." + emailEntity.getReceipient());
			}
			else if(emailEntity.getTemplate().trim().equalsIgnoreCase(ApplicationConstants.EmailTemplte.DELETEACCOUNTEMAIL.name()))
			{
				emailData.Subject= emailEntity.getSubject();
				emailData.Message= emailEntity.getMessage();
				emailSender.sendDeleteAccount(emailData);		
				logger.info("Email Sent to.." + emailEntity.getReceipient());
			}
			else if(emailEntity.getTemplate().trim().equalsIgnoreCase(ApplicationConstants.EmailTemplte.DELETEREMAINDEREMAIL.name()))
			{
				emailData.Subject= emailEntity.getSubject();
				emailData.Message= emailEntity.getMessage();
				emailSender.sendDeleteAccountRemainder(emailData);		
				logger.info("Email Sent to.." + emailEntity.getReceipient());
			}
			else if(emailEntity.getTemplate().trim().equalsIgnoreCase(ApplicationConstants.EmailTemplte.SUPPORTTEAMEMAIL.name()))
			{
				emailData.Subject= emailEntity.getSubject();
				emailData.Message= emailEntity.getMessage();
				emailData.Recipient =config.getSupportteam();
				emailData.HCMRecipient=null;
				emailSender.sendSupportTeamMail(emailData);		
				logger.info("Email Sent to.." + config.getSupportteam());
			}	
			else if(emailEntity.getTemplate().trim().equalsIgnoreCase(ApplicationConstants.EmailTemplte.LIMITEMAIL.name()))
			{
				emailData.Subject= emailEntity.getSubject();
				emailData.Message= emailEntity.getMessage();
				emailSender.sendLimitMail(emailData);	
				logger.info("Email Sent to.." + emailEntity.getReceipient());
			}
			return true;
		}
		catch(Exception ex)
		{
			logger.error("Error in sending email "+ex.getMessage());
			logger.info("Error in sending email "+ex.getMessage()+" " + config.getSupportteam());
			return false;
		}
	} 
}
