package com.palusers.emailscheduler.domain;

import org.json.JSONException;
import org.json.JSONObject;

public class PCFRunner {

	public String apiendpoint;
	public String noofrunners;
	public String subject;
	public String recipient;
	public String runnerTotalMemory;
	public String usedMemory;
	public String availableMemory;
	public String percentRemainingSpace;
	public String thresholdInGB;
	public String thresholdPercentage;
	public String message;
	
	public PCFRunner() {
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}
	public String getApiendpoint() {
		return apiendpoint;
	}

	public void setApiendpoint(String apiendpoint) {
		this.apiendpoint = apiendpoint;
	}

	public String getNoofrunners() {
		return noofrunners;
	}

	public void setNoofrunners(String noofrunners) {
		this.noofrunners = noofrunners;
	}

	public String getRunnerTotalMemory() {
		return runnerTotalMemory;
	}

	public void setRunnerTotalMemory(String runnerTotalMemory) {
		this.runnerTotalMemory = runnerTotalMemory;
	}

	public String getUsedMemory() {
		return usedMemory;
	}

	public void setUsedMemory(String usedMemory) {
		this.usedMemory = usedMemory;
	}

	public String getAvailableMemory() {
		return availableMemory;
	}

	public void setAvailableMemory(String availableMemory) {
		this.availableMemory = availableMemory;
	}

	public String getPercentRemainingSpace() {
		return percentRemainingSpace;
	}

	public void setPercentRemainingSpace(String percentRemainingSpace) {
		this.percentRemainingSpace = percentRemainingSpace;
	}

	public String getThresholdInGB() {
		return thresholdInGB;
	}

	public void setThresholdInGB(String thresholdInGB) {
		this.thresholdInGB = thresholdInGB;
	}

	public String getThresholdPercentage() {
		return thresholdPercentage;
	}

	public void setThresholdPercentage(String thresholdPercentage) {
		this.thresholdPercentage = thresholdPercentage;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	// @Override
	// public String toString() {
	// return "PCFRunner [apiendpoint=" + apiendpoint + ", noofrunners=" +
	// noofrunners + ", runnerTotalMemory="
	// + runnerTotalMemory + ", usedMemory=" + usedMemory + ", availableMemory=" +
	// availableMemory
	// + ", percentRemainingSpace=" + percentRemainingSpace + ", thresholdInGB=" +
	// thresholdInGB
	// + ", thresholdPercentage=" + thresholdPercentage + "]";
	// }
	public String toString() {
		JSONObject jsonInfo = new JSONObject();

		try {
			jsonInfo.put("apiendpoint", this.apiendpoint);
			jsonInfo.put("noofrunners", this.noofrunners);
			jsonInfo.put("runnerTotalMemory", this.runnerTotalMemory);
			jsonInfo.put("usedMemory", this.usedMemory);
			jsonInfo.put("availableMemory", this.availableMemory);
			jsonInfo.put("percentRemainingSpace", this.percentRemainingSpace);
			jsonInfo.put("thresholdInGB", this.thresholdInGB);
			jsonInfo.put("thresholdPercentage", this.thresholdPercentage);
			jsonInfo.put("subject", this.subject);
			jsonInfo.put("recipient", this.recipient);
			jsonInfo.put("message", this.message);
		} catch (JSONException e1) {
		}
		return jsonInfo.toString();
	}

}
