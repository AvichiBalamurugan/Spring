package com.palusers.emailscheduler.domain;

public class EmailRequest {

	public String Recipient;
	public String HCMRecipient;
	public String Message;
	public String Subject;	 
	public Boolean isHtml;
	public String Track;
	public String LearningUrl;	
	public String UniqueId;
	public String Username;
	public String Password;
	public String ApiURL;
	public String AppManagerUrl;
	public String AccountCreationUrl;
}

