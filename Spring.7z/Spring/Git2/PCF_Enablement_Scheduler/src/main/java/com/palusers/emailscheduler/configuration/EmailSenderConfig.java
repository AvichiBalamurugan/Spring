package com.palusers.emailscheduler.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
public class EmailSenderConfig {

	
	private String awssource;
	private String appmanagerconsole;
	private String cfcli;
	private String cfclidownload;
	private String supportteam;
	private String accesskey;
	private String secretkey;
	public String getAwssource() {
		return awssource;
	}
	public void setAwssource(String awssource) {
		this.awssource = awssource;
	}
	public String getAppmanagerconsole() {
		return appmanagerconsole;
	}
	public void setAppmanagerconsole(String appmanagerconsole) {
		this.appmanagerconsole = appmanagerconsole;
	}
	public String getCfcli() {
		return cfcli;
	}
	public void setCfcli(String cfcli) {
		this.cfcli = cfcli;
	}
	public String getCfclidownload() {
		return cfclidownload;
	}
	public void setCfclidownload(String cfclidownload) {
		this.cfclidownload = cfclidownload;
	}
	public String getSupportteam() {
		return supportteam;
	}
	public void setSupportteam(String supportteam) {
		this.supportteam = supportteam;
	}
	public String getAccesskey() {
		return accesskey;
	}
	public void setAccesskey(String accesskey) {
		this.accesskey = accesskey;
	}
	public String getSecretkey() {
		return secretkey;
	}
	public void setSecretkey(String secretkey) {
		this.secretkey = secretkey;
	}
	
	
}
