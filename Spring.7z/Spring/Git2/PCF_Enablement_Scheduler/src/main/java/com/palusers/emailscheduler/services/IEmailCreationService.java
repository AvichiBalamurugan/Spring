package com.palusers.emailscheduler.services;

import java.util.Date;
import java.util.List;
import com.palusers.emailscheduler.domain.EmailEntity;

public interface IEmailCreationService {
	List<EmailEntity> listAll();	
	EmailEntity saveOrUpdate(EmailEntity email);
	void updateEmailStatus(String emailid,String activationstatus,Date dt);	
	List<EmailEntity> findNotSentlist(String status);
	void deleteEmail(Long id);
}
