package com.cognizant.pcfmonitor.services;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.cognizant.pcfmonitor.common.ApplicationConstants;
import com.cognizant.pcfmonitor.exception.AppMemoryException;
import com.cognizant.pcfmonitor.utils.SSLCertificateValidation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ApiService {
	
	@Value("${oauthTokenAPI}")
	private String oauthTokenAPI;
	
	@Value("${uaagetapplist}")
	private String uaagetapplist;
	
	@Value("${nextpageapplist}")
	private String nextpageapplist;
	
	@Value("${resultlimit}")
	private String resultlimit;
	
	@Value("${oauthCredentials}")
	private String oauthCredentials;
	
	RestTemplate restTemplate = new RestTemplate();
	
	HttpHeaders headers = new HttpHeaders();

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//ApiAccessToken from Oauth URL of PCF APPS Manager
	public String getApiAccessToken() throws JsonProcessingException, IOException {
		SSLCertificateValidation.disable(); //Disable SSL Validation for Authorizing HTTPS requests.
		headers.set(ApplicationConstants.AUTHORIZATION, ApplicationConstants.BASIC_AUTHORIZATION); 
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		String oauthUrl = oauthTokenAPI + oauthCredentials;  
		logger.info("****************URL Response**********" + oauthUrl);
		ResponseEntity<String> responseAccessToken = restTemplate.exchange(oauthUrl, HttpMethod.GET, entity, String.class);
		final JsonNode accessToken = new ObjectMapper().readTree(responseAccessToken.getBody()).get(ApplicationConstants.ACCESS_TOKEN); 
		logger.info("****************Token**********" + accessToken.toString());
		String bearer = "Bearer " + accessToken.toString();
		bearer = bearer.replace("\"", "");
		logger.info("****************Token**********" + bearer);
		return bearer;
	}
	
	public int getTotalAppMemory() throws JsonProcessingException, IOException {
		int memory = 0;
		SSLCertificateValidation.disable();
		String bearer = getApiAccessToken();
		
		headers.set(ApplicationConstants.AUTHORIZATION, bearer);
		HttpEntity<String> httpentity = new HttpEntity<String>(headers);
		ResponseEntity<String> responseNoOfPages = restTemplate.exchange(uaagetapplist, HttpMethod.GET, httpentity, String.class);
		
		logger.info("****************Response**********" + responseNoOfPages.getBody());
		final JsonNode totalPages = new ObjectMapper().readTree(responseNoOfPages.getBody()).get(ApplicationConstants.TOTAL_PAGES);
		int pages = totalPages.asInt();

		//Iterate result pages to get memory of each app where each page consists of 100 apps detail
		for (int i = 1; i <= pages; i++) {
			String apiURL = nextpageapplist + Integer.toString(i)
					+ resultlimit;
			logger.info("****************API URL**********" + apiURL);
			
			ResponseEntity<String> nextAppResponse = restTemplate.exchange(apiURL, HttpMethod.GET, httpentity, String.class);
			logger.info("****************App Response **********" + nextAppResponse.getBody() +"for page " +i);
			final JsonNode appResources = new ObjectMapper().readTree(nextAppResponse.getBody()).get(ApplicationConstants.RESOURCES);
			if (appResources.isArray()) {
				for (final JsonNode objNode : appResources) {
					JsonNode entity = objNode.get(ApplicationConstants.ENTITY);
					JsonNode state = entity.get(ApplicationConstants.STATE);
					String status = ApplicationConstants.STARTED;
					if (state.toString().equals(status)) {
						JsonNode entityMemory = entity.get(ApplicationConstants.MEMORY);
						memory = memory + entityMemory.asInt();
					}
				}
			}
		}
		logger.info("****************Total Memory**********" + memory);
		if(memory==0)
		{
			throw new AppMemoryException();
		}
		else
		{
			return memory;
		}
	}
}
