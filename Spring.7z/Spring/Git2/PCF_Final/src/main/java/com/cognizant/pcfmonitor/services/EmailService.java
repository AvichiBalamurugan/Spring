package com.cognizant.pcfmonitor.services;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cognizant.pcfmonitor.entity.PCFRunner;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class EmailService {
	
	@Autowired
	private ApiService apiService;
	
	@Autowired
	private AwsService awsService;

	@Value("${fixedThresholdLimit}")
	private int limit;
	
	@Value("${apiendpoint}")
	private String apiendpoint;
	
	@Value("${emailRecipient}")
	private String emailRecipient;
	
	@Value("${pcfEmailSubject}")
	private String pcfEmailSubject;
	
	PCFRunner pcfrunner = new PCFRunner();
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	//Set Email Content which will consist of Runner Details
	public PCFRunner pcfemailData() throws JsonProcessingException, IOException, KeyManagementException, NoSuchAlgorithmException
	{			
		int memory = apiService.getTotalAppMemory();
		double usedMemory = Double.valueOf(memory)/1024;
		usedMemory =	Math.round(usedMemory*100.0)/100.0;
		
		List<String> runnerValues = awsService.getTotalRunnerMemory();
		
		String noofrunners = runnerValues.get(0);
		
		double runnerTotalMemory = Double.parseDouble(runnerValues.get(2));	
		double availableMemory = runnerTotalMemory - (Double.valueOf(memory)/1024);
		double percentRemainingSpace = (availableMemory/runnerTotalMemory)*100;
		double threshold = (runnerTotalMemory * limit)/100;
		
		runnerTotalMemory =	Math.round(runnerTotalMemory*100.0)/100.0;
		availableMemory =	Math.round(availableMemory*100.0)/100.0;
		percentRemainingSpace =	Math.round(percentRemainingSpace*100.0)/100.0;
		threshold =	Math.round(threshold*100.0)/100.0;
		logger.info("****************Memory Response**********" + memory);
		logger.info("****************Threshold Response**********" + threshold);
		if(usedMemory>threshold)
		{
			pcfrunner.setMessage("Total Memory has been exceeded the given threshold. The following are the details of PCF Instance");
		}
		else
		{
			pcfrunner.setMessage("The following are the details of PCF Instance");	
		}
		
		pcfrunner.setApiendpoint(apiendpoint);
		pcfrunner.setNoofrunners(noofrunners);
		pcfrunner.setAvailableMemory(Double.toString(availableMemory));
		pcfrunner.setPercentRemainingSpace(Double.toString(percentRemainingSpace));
		pcfrunner.setRunnerTotalMemory(Double.toString(runnerTotalMemory));
		pcfrunner.setUsedMemory(Double.toString(usedMemory));
		pcfrunner.setThresholdPercentage(Integer.toString(limit));
		pcfrunner.setThresholdInGB(Double.toString(threshold));
		pcfrunner.setRecipient(emailRecipient);
		pcfrunner.setSubject(pcfEmailSubject);
		System.out.println(pcfrunner.toString());
		return pcfrunner;
	}
}
