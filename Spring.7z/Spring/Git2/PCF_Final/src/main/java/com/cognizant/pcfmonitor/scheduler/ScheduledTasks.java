package com.cognizant.pcfmonitor.scheduler;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.cognizant.pcfmonitor.entity.PCFRunner;
import com.cognizant.pcfmonitor.rabbitmq.RabbitMqProducer;
import com.cognizant.pcfmonitor.services.EmailService;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class ScheduledTasks {

	@Autowired
	private RabbitMqProducer producer;
	
	@Autowired
	EmailService emailService;
	
	PCFRunner pcfInfo = new PCFRunner();
		
	//Runner Updates for every 2 hours
	@Scheduled(fixedDelayString = "${fixedRate}")
    public void runEmailJob() throws JsonProcessingException, IOException, KeyManagementException, NoSuchAlgorithmException {		 
		pcfInfo = emailService.pcfemailData();
		if(Double.parseDouble(pcfInfo.usedMemory)>Double.parseDouble(pcfInfo.thresholdInGB)) {
			producer.produce(pcfInfo);
		}	
    }
	
	//Runner Updates for everyday
	@Scheduled(cron = "0 30 03 * * ?")
    public void runEmail() throws JsonProcessingException, IOException, KeyManagementException, NoSuchAlgorithmException {		 
		pcfInfo = emailService.pcfemailData();
		producer.produce(pcfInfo);
    }
}
