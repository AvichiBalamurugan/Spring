package com.cognizant.pcfmonitor.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.OK, reason="No Apps are running")
public class AppMemoryException extends RuntimeException{

private static final long serialVersionUID =3935230481555340069L;
}