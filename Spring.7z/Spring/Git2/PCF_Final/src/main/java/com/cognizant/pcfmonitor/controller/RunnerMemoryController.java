package com.cognizant.pcfmonitor.controller;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.pcfmonitor.services.ApiService;
import com.cognizant.pcfmonitor.services.AwsService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.exceptions.UnirestException;

@RefreshScope
@RestController
public class RunnerMemoryController {
	
	@Autowired
	private ApiService apiService;

	@Autowired
	private AwsService awsService;
	
	
	@RequestMapping(value = "/GetMemory", method = RequestMethod.GET)
	public ResponseEntity<Object> getFreeMemory() throws JsonProcessingException, UnirestException, IOException
	{
		int memory = apiService.getTotalAppMemory();
		memory = memory/1024;
		return new ResponseEntity<Object>("Total App Memory Used: "+ Integer.toString(memory) + " GB", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/GetTotalMemory", method = RequestMethod.GET)
	public ResponseEntity<Object> getTotalMemory() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException
	{
		List<String> totalMemory = awsService.getTotalRunnerMemory();
		return new ResponseEntity<Object>("Number of Instances is " + totalMemory.get(0) + " and Instance Type is " + totalMemory.get(1) + " Total Memory of Diego: "+ totalMemory.get(2), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/GetAvailableMemory", method = RequestMethod.GET)
	public ResponseEntity<Object> GetAvailableMemory() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException
	{
		List<String> totalMemory = awsService.getTotalRunnerMemory();
		double memory = Double.parseDouble(totalMemory.get(2)) - ((double)apiService.getTotalAppMemory()/1024);
		memory =	Math.round(memory*100.0)/100.0;
		return new ResponseEntity<Object>("Available memory " + memory + " GB", HttpStatus.OK);
	}
	
}
