package com.cognizant.pcfmonitor.controller;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.cognizant.pcfmonitor.entity.PCFRunner;
import com.cognizant.pcfmonitor.services.EmailService;
import com.fasterxml.jackson.core.JsonProcessingException;

@Controller
public class EmailController{

	@Autowired
	private EmailService emailService;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}

	@GetMapping("/pcfspacedetails")
	public String pcf(Model model) throws KeyManagementException, JsonProcessingException, NoSuchAlgorithmException, IOException {
		PCFRunner pcfInfo = new PCFRunner();
		pcfInfo = emailService.pcfemailData();
		model.addAttribute("apiendpoint", pcfInfo.getApiendpoint());
		model.addAttribute("noofrunners", pcfInfo.getMessage());
		model.addAttribute("runnerTotalMemory", pcfInfo.getRunnerTotalMemory());
		model.addAttribute("usedMemory", pcfInfo.getUsedMemory());
		model.addAttribute("availableMemory", pcfInfo.getAvailableMemory());
		model.addAttribute("percentRemainingSpace", pcfInfo.getPercentRemainingSpace());
		model.addAttribute("thresholdInGB", pcfInfo.getThresholdInGB());
		model.addAttribute("thresholdPercentage", pcfInfo.getThresholdPercentage());
		return "pcfspacedetails";
	}
}
