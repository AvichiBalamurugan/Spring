package com.cognizant.pcfmonitor.scheduler;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.cognizant.pcfmonitor.rabbitmq.RabbitMqProducer;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class ScheduledTasks {

	@Autowired
	private RabbitMqProducer producer;
	
	//Runner Updates for every 2 hours
	@Scheduled(fixedDelayString = "${fixedRate}")
    public void runEmailJob() throws JsonProcessingException, IOException, KeyManagementException, NoSuchAlgorithmException {		 

		producer.produce();
		//producer.testProduce("Rabbit Mq Message Sent");
    }
	
	//Runner Updates for everyday
	@Scheduled(cron = "0 0 09 * * ?")
    public void runEmail() throws JsonProcessingException, IOException, KeyManagementException, NoSuchAlgorithmException {		 
	    producer.produce();
    }
}
