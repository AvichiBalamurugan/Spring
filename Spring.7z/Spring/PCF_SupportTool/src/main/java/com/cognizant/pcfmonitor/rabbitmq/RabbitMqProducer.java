package com.cognizant.pcfmonitor.rabbitmq;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.pcfmonitor.entity.PCFRunner;
import com.cognizant.pcfmonitor.services.EmailService;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class RabbitMqProducer {

	private final RabbitTemplate template;

	@Autowired
	public RabbitMqProducer(RabbitTemplate template) {
		this.template = template;
	}

	@Autowired
	EmailService emailService;

	public void produce()
			throws KeyManagementException, JsonProcessingException, NoSuchAlgorithmException, IOException {
		PCFRunner pcfInfo = new PCFRunner();
		pcfInfo = emailService.pcfemailData();
		this.template.convertAndSend("spring-queue", pcfInfo);
		System.out.println("Send msg = " + pcfInfo);
	}
}
