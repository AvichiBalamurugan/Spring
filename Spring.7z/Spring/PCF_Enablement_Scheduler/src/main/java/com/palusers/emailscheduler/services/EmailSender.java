package com.palusers.emailscheduler.services;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClient;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;
import com.amazonaws.services.simpleemail.model.SendEmailResult;
import com.palusers.emailscheduler.configuration.EmailSenderConfig;
import com.palusers.emailscheduler.domain.EmailRequest;
import com.palusers.emailscheduler.domain.PCFRunner;
import com.palusers.emailscheduler.domain.UserMailEntity;

@Service
public class EmailSender implements IEmailService {
	
	@Value("${firstMail}")
    private String firstMail;

    @Value("${secondMail}")
    private String secondMail;

    @Value("${thirdMail}")
    private String thirdMail;


	@Autowired
	private TemplateEngine templateEngine;

	@Autowired
	private EmailSenderConfig config;
	

	@Override
    public void sendRegistrationEmail(EmailRequest emailData)  {
    	Context context = new Context();
        context.setVariable("track", emailData.Track);
        context.setVariable("link", emailData.LearningUrl);
        context.setVariable("entrycode", emailData.UniqueId);
        context.setVariable("accountcreationurl", emailData.AccountCreationUrl);
        String htmlBody =  templateEngine.process("RegistrationEmailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    
    @Override
    public void sendAccountEmail(EmailRequest emailData)  {
    	Context context = new Context();
    	context.setVariable("username", emailData.Username);
        context.setVariable("password", emailData.Password);
        context.setVariable("apiurl", emailData.ApiURL);
        context.setVariable("appmanagerurl", emailData.AppManagerUrl);
        context.setVariable("appmanagerconsole", config.getAppmanagerconsole());  
        context.setVariable("cfcli", config.getCfcli());  
        context.setVariable("cfclidownload", config.getCfclidownload());        
        String htmlBody =  templateEngine.process("AccountEmailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    
    @Override
    public void sendErrorMail(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("ErrorMailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    
    @Override
    public void sendDeleteAccount(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("DeleteAccountMailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }

    @Override
    public void sendDeleteAccountRemainder(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("DeleteRemainderMailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    @Override
    public void sendSupportTeamMail(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("SupportTeamEmailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    
	private void sendMail(String to, String supervisoremail, String subject, String htmlbody) {
		
		 Content subjectContent = new Content(subject);		 
	     String newhtml = htmlbody.replace("<html lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\">", "<html>");
	     System.out.println("newhtml: "+newhtml);
	     System.out.println("support team email: "+config.getSupportteam());
		 Content bodyContent = new Content().withData(newhtml);
	     Body msgBody = new Body().withHtml(bodyContent);
	     Message msg = new Message(subjectContent, msgBody);
	     List<String> toAddresses = Arrays.asList(to);
	     Destination destination = null;
	     if(supervisoremail == null)
	     {
	    	 destination= new Destination().withToAddresses(toAddresses).withCcAddresses(firstMail).withCcAddresses(secondMail).withCcAddresses(thirdMail).withBccAddresses(config.getSupportteam());
		 }
	     else if(supervisoremail == "Cumuluslabs")
	     {
	    	 destination= new Destination().withToAddresses(toAddresses).withBccAddresses(config.getSupportteam());
	     }	     
	     else
	     {	    	 
	    	 destination= new Destination().withToAddresses(toAddresses).withCcAddresses(supervisoremail).withBccAddresses(config.getSupportteam());  
	     }
	     SendEmailRequest request = new SendEmailRequest(config.getAwssource(), destination, msg);	     
	     AWSCredentials credentials = new BasicAWSCredentials(config.getAccesskey(), config.getSecretkey());
	     AmazonSimpleEmailServiceClient sesClient = new AmazonSimpleEmailServiceClient(credentials);
	     SendEmailResult result = sesClient.sendEmail(request);
    }
	
	 @Override
	    public void sendLimitMail(EmailRequest emailData) {
	    	Context context = new Context();
	        context.setVariable("message", emailData.Message);
	        String htmlBody =  templateEngine.process("LimitErrorMailTemplate", context);
	        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
	    }
	 
	 //Send User Creation Mail
	 @Override
	    public void sendUserCreationMail(UserMailEntity emailData) {
	    		Context context = new Context();
	        context.setVariable("username", emailData.getUsername());
	        context.setVariable("password", emailData.getPassword());
	        context.setVariable("orgName", emailData.getOrgName());
	        context.setVariable("spaceName", emailData.getSpaceName());
	        context.setVariable("appsManagerURL", emailData.getAppsManagerURL());
	        context.setVariable("apiEndpointURL", emailData.getApiEndpointURL());
	        String htmlBody =  templateEngine.process("UserCreationEmailTemplate", context);
	        sendMail(emailData.getUsername(),"Cumuluslabs",emailData.getSubject(),htmlBody);
	    }
	 
	 // Send Runner Memory Mail
	 	@Override
	    public void sendMemoryMail(PCFRunner pcfInfo) {
	    		Context context = new Context();
	    		context.setVariable("message", pcfInfo.getMessage());
	    		context.setVariable("apiendpoint", pcfInfo.getApiendpoint());
	        context.setVariable("noofrunners", pcfInfo.getNoofrunners());
	        context.setVariable("runnerTotalMemory", pcfInfo.getRunnerTotalMemory());
	        context.setVariable("usedMemory", pcfInfo.getUsedMemory());
	        context.setVariable("availableMemory", pcfInfo.getAvailableMemory());
	        context.setVariable("percentRemainingSpace", pcfInfo.getPercentRemainingSpace());
	        context.setVariable("thresholdPercentage", pcfInfo.getThresholdPercentage());
	        context.setVariable("thresholdInGB", pcfInfo.getThresholdInGB());
	        
	        String htmlBody =  templateEngine.process("RunnerMemoryMailTemplate", context);
	        sendMail(pcfInfo.getRecipient(),null,pcfInfo.getSubject(),htmlBody);
	    }
	 

}
