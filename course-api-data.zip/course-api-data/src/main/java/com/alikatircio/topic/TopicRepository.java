package com.alikatircio.topic;

import org.springframework.data.repository.CrudRepository;

/**
 * Created by ali on 13.12.2017.
 */
public interface TopicRepository extends CrudRepository<Topic, String > {
}
