package com.cognizant.pcfsupport.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.OK, reason="Null value found")
public class ProductGuidException extends RuntimeException{

private static final long serialVersionUID =3935230281555340069L;
}