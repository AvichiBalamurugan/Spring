package com.cognizant.pcfsupport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcfSupportToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcfSupportToolApplication.class, args);
	}
}
