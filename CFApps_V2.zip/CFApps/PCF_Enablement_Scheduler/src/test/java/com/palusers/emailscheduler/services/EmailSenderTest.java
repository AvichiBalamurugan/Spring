package com.palusers.emailscheduler.services;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import com.palusers.emailscheduler.services.EmailSender;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.palusers.emailscheduler.domain.EmailRequest;

public class EmailSenderTest {
	private EmailSender emailSenderMock;		
	private EmailRequest emailRequest; 
	@Before
	public void setup() throws Exception
	{
		emailSenderMock = Mockito.mock(EmailSender.class);
		emailRequest = getEmailRequest();
	}
	
	@Test
    public void sendAccountEmail() throws Exception
    {	
		emailSenderMock.sendAccountEmail(emailRequest);
		verify(emailSenderMock, times(1)).sendAccountEmail(emailRequest);	
    }
	
	@Test
    public void sendErrorMail() throws Exception
    {	
		emailSenderMock.sendErrorMail(emailRequest);
		verify(emailSenderMock, times(1)).sendErrorMail(emailRequest);	
    }
	
	@Test
    public void sendRegistrationEmail() throws Exception
    {	
		emailSenderMock.sendRegistrationEmail(emailRequest);
		verify(emailSenderMock, times(1)).sendRegistrationEmail(emailRequest);	
    }
	
	@Test
    public void sendSupportTeamMail() throws Exception
    {	
		emailSenderMock.sendSupportTeamMail(emailRequest);
		verify(emailSenderMock, times(1)).sendSupportTeamMail(emailRequest);	
    }
	
	@Test
    public void sendLimitEmail() throws Exception
    {	
		emailSenderMock.sendLimitMail(emailRequest);
		verify(emailSenderMock, times(1)).sendLimitMail(emailRequest);	
    }
	
	private EmailRequest getEmailRequest()
	{
		EmailRequest emailRequest = new EmailRequest();		
		emailRequest.Recipient = "Recipient";		
		return emailRequest;
	}
}
