package com.cognizant.pcfsupport.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.OK, reason="Not a valid Access Token")
public class AccessTokenException extends RuntimeException{

private static final long serialVersionUID =3936230281555340069L;
}