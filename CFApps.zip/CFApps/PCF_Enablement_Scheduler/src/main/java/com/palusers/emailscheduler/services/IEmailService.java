package com.palusers.emailscheduler.services;

import com.palusers.emailscheduler.domain.EmailRequest;

public interface IEmailService {

	void sendAccountEmail(EmailRequest emailData);

	void sendErrorMail(EmailRequest emailData);

	void sendRegistrationEmail(EmailRequest emailData);

	void sendSupportTeamMail(EmailRequest emailData);

	void sendDeleteAccountRemainder(EmailRequest emailData);

	void sendDeleteAccount(EmailRequest emailData);

	void sendLimitMail(EmailRequest emailData);

	void sendMemoryMail(EmailRequest emailData);

}
