package com.palusers.scheduler;


import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.palusers.common.ApplicationConstants;
import com.palusers.configuration.ScheduledTaskConfig;
import com.palusers.domain.EmailRequest;
import com.palusers.domain.UAAEmailData;
import com.palusers.domain.UAAUserData;
import com.palusers.domain.UserEntity;
import com.palusers.logger.ILogger;
import com.palusers.logger.LoggerFactory;
import com.palusers.services.CloudUserManageService;
import com.palusers.services.EmailCreation;
import com.palusers.services.UserCreationService; 

@Component
public class ScheduledTasks {

	private static ILogger logger;	
	private UserEntity userEntity; 
	 
	@Autowired
	private EmailCreation emailTemplate; 
	
	@Autowired
	private CloudUserManageService cloudUsrManageService;
	
	@Autowired
	private UserCreationService userservice;
	
	@Autowired
    private ScheduledTaskConfig config;
	
	public ScheduledTasks(LoggerFactory loggerFactory)
	{
		logger = loggerFactory.getLoggerInstance();
	}
	
	@Scheduled(fixedDelayString = "${fixedDelayDeleteAccountinmilliseconds}")
	public void deleteAccount() {		
		try
		{
			int getbackDays = Integer.parseInt(config.getGetdeletebackdays());
			int getRemainderday =Integer.parseInt(config.getGetremainderDeletedays());
			logger.info("Delete Account started for "+ LocalDateTime.now().minusDays(getbackDays));
			logger.info("No of back days set for deletion:  "+ getbackDays);
			logger.info("No of days set for remainder: "+ getRemainderday);
			List<UserEntity> lstUsersDeletion = userservice.getDeletionUsers(Timestamp.valueOf(LocalDateTime.now().minusDays(getbackDays)),ApplicationConstants.ActivationStatus.ACTIVATED.name());
			List<UserEntity> lstUsersRemainder = userservice.getDeletionRemainder(Timestamp.valueOf(LocalDateTime.now().minusDays(getRemainderday)),ApplicationConstants.ActivationStatus.ACTIVATED.name());
			logger.info("No of users for deletion: "+ lstUsersDeletion.size());
			logger.info("No of users for remainder: "+ lstUsersRemainder.size());
			if(lstUsersRemainder !=null && lstUsersRemainder.size() >0)
			{
				   String emailId = "";
				   String supervisoremail = "";
				   try
				   {
				     for(UserEntity usr:  lstUsersRemainder)
				     {
				    	 emailId = usr.getEmployeeemailid();
				    	 supervisoremail= usr.getSupervisoremailid();
				    	 logger.info("Saving remanider email : "+ usr.getEmployeeemailid());
				    	 saveDeleteEmail(config.getDeletremainderesubject(), config.getDeleteremaindermessage(), emailId, usr.getSupervisoremailid(), true, false);
				    	 logger.info("Saved remanider email : "+ usr.getEmployeeemailid());
				     }
				   }
				   catch(Exception ex)
				   {
					   logger.error("Error has occured in deleting account for "+ emailId+ " error: " + ex.getMessage());
				       saveDeleteEmail(config.getDeleteerrorsubject(), config.getDeleteerrormessgae(), emailId, supervisoremail, false, true); 

				   }
			}
			if(lstUsersDeletion !=null && lstUsersDeletion.size() >0)
			{
				String oAuthtoken = cloudUsrManageService.getAuthtokenforOrgCreation(config.getOauthusername(),config.getOauthpassword(),ApplicationConstants.OAUTHGRANTTYPE);//propertyFileReader.getMessage(ApplicationConstants.OAUTHUSERNAME),propertyFileReader.getMessage(ApplicationConstants.OAUTHPASSWORD),ApplicationConstants.OAUTHGRANTTYPE);
				if(oAuthtoken !=null)
				{
				   String emailId = "";
				   String supervisoremail = "";
				   try
				   {
				     for(UserEntity usr:  lstUsersDeletion)
				     {
					     logger.info("Deleting account : "+ usr.getEmployeeemailid());
					     logger.info("Deleting account's orgid : "+ usr.getOrgid());
						 userservice.updateActStatus(usr.getEmployeeemailid(),ApplicationConstants.ActivationStatus.DELETING.name(),Timestamp.valueOf(LocalDateTime.now()));
				    	 emailId = usr.getEmployeeemailid();
				    	 supervisoremail= usr.getSupervisoremailid();
				    	 HttpStatus resultStatus = cloudUsrManageService.deleteOperations(oAuthtoken,usr.getOrgid(),usr.getEmployeeemailid());
				    	 //HttpStatus resultOrg= cloudUsrManageService.deleteOrg(oAuthtoken, usr.getOrgid());
					     userservice.updateActStatus(usr.getEmployeeemailid(),ApplicationConstants.ActivationStatus.DELETED.name(),Timestamp.valueOf(LocalDateTime.now()));
					     logger.info("Deleted account : "+ usr.getEmployeeemailid());
				    	 saveDeleteEmail(config.getDeletesubject(), config.getDeletemessage(), emailId, usr.getSupervisoremailid(), false, false); 
				     }
				   }
				   catch(Exception ex)
				   {
					   userservice.updateActStatus(emailId,ApplicationConstants.ActivationStatus.ACTIVATED.name(),Timestamp.valueOf(LocalDateTime.now()));
					   logger.error("Error has occured in deleting account for "+ emailId+ " error: " + ex.getMessage());
				       saveDeleteEmail(config.getDeleteerrorsubject(), config.getDeleteerrormessgae(), emailId, supervisoremail, false, true); 

				   }
				}
			}	
			logger.info("Delete Account completed at "+ LocalDateTime.now());
		}
		catch(Exception ex)
		{
			logger.info("Exception in Delete Account "+ ex.getMessage());
		}
	
	}
	
	@Scheduled(fixedDelayString = "${fixedDelayCreateAccountinmilliseconds}")
    public void createAccountJob() {
		userEntity = null;
		try		
		{		
			logger.info("Account creation job started at "+ LocalDateTime.now());
			List<UserEntity> lstuserRequest = userservice.getUserForActivation(ApplicationConstants.ActivationStatus.TOBEACTIVATED.name(),Integer.parseInt(config.getNoofattempts()));
			if(lstuserRequest != null && lstuserRequest.size() > 0)
			{
				userEntity = lstuserRequest.get(0);				
			}
			if (userEntity != null && userEntity.getEmployeeemailid() !=null)
			{	
				userservice.updateActStatus(userEntity.getEmployeeemailid(),ApplicationConstants.ActivationStatus.ACTIVATING.name(),Timestamp.valueOf(LocalDateTime.now()));
				logger.info("Creating CF account for "+ userEntity.getEmployeeemailid());
				logger.info("Getting Token for creating users"+ userEntity.getEmployeeemailid());
				String token = cloudUsrManageService.getToken(config.getUaalogin());				
				if(token !=null)
				{
					logger.info("Token received for creating users "+ userEntity.getEmployeeemailid());					//
					logger.info("Creating user in CF " + userEntity.getEmployeeemailid());
					String password = UUID.randomUUID().toString().substring(0, Integer.parseInt(config.getUserpasswordlength()));
					String newuserId = createUserInCF(token,password);					
					if(newuserId !=null)
					{
						logger.info("User created in CF " + userEntity.getEmployeeemailid());					    
						logger.info("Getting Token for creating org and association "+ userEntity.getEmployeeemailid());
						String oAuthtoken = cloudUsrManageService.getAuthtokenforOrgCreation(config.getOauthusername(),config.getOauthpassword(),ApplicationConstants.OAUTHGRANTTYPE);//propertyFileReader.getMessage(ApplicationConstants.OAUTHUSERNAME),propertyFileReader.getMessage(ApplicationConstants.OAUTHPASSWORD),ApplicationConstants.OAUTHGRANTTYPE);
						if(oAuthtoken !=null)
						{
							logger.info("Token received for creating org and association "+ userEntity.getEmployeeemailid());						
							logger.info("Creating org "+ userEntity.getEmployeeemailid());
							String orgName =userEntity.getEmployeeemailid().substring(0, userEntity.getEmployeeemailid().indexOf('@')).replace('.','-');
							String orgId = cloudUsrManageService.createOrg(oAuthtoken, orgName);	
							if(orgId !=null)
							{
								userservice.updateOrgID(userEntity.getEmployeeemailid(),orgId,Timestamp.valueOf(LocalDateTime.now()));								
								logger.info("Org created "+ userEntity.getEmployeeemailid());
								logger.info("Associating user to org "+ userEntity.getEmployeeemailid());
								HttpStatus resOrgtoUsr = cloudUsrManageService.associateOrgtoUser(oAuthtoken,userEntity.getEmployeeemailid(),orgId);
								if(resOrgtoUsr== HttpStatus.CREATED)
								{
									logger.info("User associated to org "+ userEntity.getEmployeeemailid());
									logger.info("Creating space "+ userEntity.getEmployeeemailid());
									String spaceId = cloudUsrManageService.createSpace(oAuthtoken, config.getSpacename(), orgId);
									if(spaceId !=null)
									{
										logger.info("Space created "+ userEntity.getEmployeeemailid());									
										logger.info("Associating user to space "+ userEntity.getEmployeeemailid());
										HttpStatus resSpacetoUsr = cloudUsrManageService.associateSpacetoUser(oAuthtoken, userEntity.getEmployeeemailid(), spaceId);
										logger.info("User associated to space "+ userEntity.getEmployeeemailid());							
		
										if(resSpacetoUsr== HttpStatus.CREATED)
										{
											logger.info("Saving Email for.." + userEntity.getEmployeeemailid());
											userservice.updateAccountCreationStatus(userEntity.getEmployeeemailid(),ApplicationConstants.ActivationStatus.ACTIVATED.name(),Timestamp.valueOf(LocalDateTime.now()));
											saveAccountEmail(config.getAccountcreationemailsubject(),"",password,true);
										}
										else
										{logError(config.getErrorinAccountCreationmsg(),"Error in associating user to space: ");}
									}
									else
									{logError(config.getErrorinAccountCreationmsg(),"Error in creating space: ");}
								}
								else
								{logError(config.getErrorinAccountCreationmsg(),"Error in associating user to org: ");}
							}
							else
							{logError(config.getErrorinAccountCreationmsg(),"Error in creating org and org id is null: ");}
						}
						else
						{logError(config.getErrorinAccountCreationmsg(),"Oauth token is null: ");}
					}
					else
					{logError(config.getErrorinAccountCreationmsg(),"Error in creating user in CF: ");}
				}
				else
				{logError(config.getErrorinAccountCreationmsg(),"Error in getting token (user create) is null: ");}
				
				logger.info("Created CF account for "+ userEntity.getEmployeeemailid());
			}
			else
			{
				logger.info("No users available for account creation");				
			}			
			logger.info("Account creation job completed at "+ LocalDateTime.now());
		}
		catch(Exception ex)
		{
			if(userEntity!=null)
			{
				userservice.updateActStatus(userEntity.getEmployeeemailid(),ApplicationConstants.ActivationStatus.TOBEACTIVATED.name(),Timestamp.valueOf(LocalDateTime.now()));
			}			
			logger.error(ex.getMessage());
			logger.info("Account creation job completed at "+ LocalDateTime.now());
		}
    }
	
	private void logError(String usrMsg, String adminMsg)
	{
		userservice.updateNoofAttempts(userEntity.getEmployeeemailid(), userEntity.getNumberofattempts()+1,ApplicationConstants.ActivationStatus.TOBEACTIVATED.name());
		saveAccountEmail(config.getErrorinAccountCreationsubject(),usrMsg + userEntity.getEmployeeemailid(),"",false);
		logger.error(adminMsg + userEntity.getEmployeeemailid());		
	}
	
	private void saveAccountEmail(String subject,String message,String password, boolean isSuccess)
	{
		try
		{
			EmailRequest emailData = new EmailRequest();
			emailData.Recipient = userEntity.getEmployeeemailid();
			emailData.HCMRecipient = userEntity.getSupervisoremailid();
			emailData.Subject = subject;
			emailData.Message = message;
			emailData.Username = userEntity.getEmployeeemailid();
			emailData.Password = password;
			//emailData.AppManagerUrl = appmanagerurl;
			//emailData.ApiURL = apiurl;
			if(isSuccess)
				emailTemplate.sendAccountEmail(emailData);
			else
			{
				emailTemplate.sendErrorMail(emailData);
				emailData.Message = message +" "+ userEntity.getEmployeeemailid();
				emailTemplate.sendSupportTeamMail(emailData);
			}
			logger.info("Email Saved for.." + userEntity.getEmployeeemailid());			
		}
		catch(Exception ex)
		{
			logger.error(this.getClass().getName() + ": Error in saving email");			
		}
	}
	
	private void saveDeleteEmail(String subject,String message, String recipient, String supervisoremail, boolean isRemainder,boolean isError)
	{
		try
		{
			EmailRequest emailData = new EmailRequest();
			emailData.Recipient = recipient;
			emailData.HCMRecipient = supervisoremail;
			emailData.Subject = subject;
			emailData.Message = message;
			emailData.Username = recipient;
			emailData.Password = "";
			//emailData.AppManagerUrl = appmanagerurl;
			//emailData.ApiURL = apiurl;
			if(isError)
			{
				emailTemplate.sendSupportTeamMail(emailData);
			}
			else
			{
			   if(isRemainder)
				 emailTemplate.sendDeleteRemainderMail(emailData);
			   else
			   {
				 emailTemplate.sendDeleteAccountMail(emailData);
				 emailData.Message = message +" "+ recipient;
				 emailTemplate.sendSupportTeamMail(emailData);
			   }
			}
			logger.info("Delete Email Saved for.." + recipient);			
		}
		catch(Exception ex)
		{
			logger.error(this.getClass().getName() + ": Error in saving email");			
		}
	}
	
	private String createUserInCF(String token,String password)
	{	 
		UAAUserData uaaUserData = new UAAUserData();
		uaaUserData.externalId= userEntity.getFirstname();
		uaaUserData.userName= userEntity.getEmployeeemailid();
		
		UAAEmailData uaaEmail = new UAAEmailData();
		uaaEmail.primary =true;
		uaaEmail.value=userEntity.getEmployeeemailid();
		List<UAAEmailData> emailList= new ArrayList<UAAEmailData>();
		emailList.add(uaaEmail);
		uaaUserData.emails = emailList;
		
		uaaUserData.active = true;
		uaaUserData.verified =true;
		uaaUserData.origin="uaa";
		uaaUserData.password= password;
		List<String> lst = Arrays.asList("urn:scim:schemas:core:1.0");
		uaaUserData.schemas =lst;
		return cloudUsrManageService.createUser(token, uaaUserData);		
	}
	
}
