package com.palusers.controllers;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.palusers.CloudCFApplication;
import com.palusers.controllers.UserController;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = CloudCFApplication.class)
public class UserControllerTest {

	@Autowired
	private UserController unitController;
	
	private MockMvc mockMvc;

	@Autowired
	UserController userController;
	@Before
	public void setUp() throws Exception {
	this.mockMvc = MockMvcBuilders.standaloneSetup(unitController).build();
	MockitoAnnotations.initMocks(this);
	}

	@Test
	public void registerUserTest() throws Exception {
			MvcResult result = this.mockMvc
			.perform(post("/UserManagement/RegisterUser")
			.content("{\r\n" + 
					"	\"firstName\":\"test1234565981253\",\r\n" + 
					"	\"lastName\":\"ctslast\",\r\n" + 
					"	\"employeeId\":5456454,\r\n" + 
					"	\"employeeEmailId\":\"ctstest11234656981253@cognizant.com\",\r\n" + 
					"	\"supervisorEmailId\":\"ctstest1123465t7981253@cognizant.com\",\r\n" + 
					"	\"department\":\"CTS\",\r\n" + 
					"	\"progLanguage\":\"DOTNET\",\r\n" + 
					"	\"proficiencylevel\":\"p1\",\r\n" + 
					"	\"frameworks\":\"f1\",\r\n" + 
					"	\"linuxskill\":\"l1\",\r\n" + 
					"	\"fullstackcompleted\":\"fs\",\r\n" + 
					"	\"fullstackskills\":\"fsk\",\r\n" + 
					"	\"userthoughtstraning\":\"ut\",\r\n" + 
					"	\"usercommentstraining\":\"tc\",\r\n" + 
					"	\"phoneNumber\":12353,\r\n" + 
					"	\"uniqueid\":\"734851\"\r\n" + 
					"}")
			.accept(MediaType.parseMediaType("application/json; charset=utf-8"))
			.header("Content-type", "application/json")
			.header("Authorization", "Basic cGFsdXNlcjpTaW1wbGU0dSE="))	
			.andDo(print())
			//.andExpect(status().isOk()).andExpect(content().contentType("application/json; charset=utf-8"))
			.andReturn();
			System.out.println(
			"**********************************************************************************************"
			+ "###############################################################################"
			+ result.getResponse().getContentAsString());
			assertNotNull(result.getResponse().getContentAsString());
		}
	
	/*	
	@Test
	public void insertTest1() throws Exception {
			MvcResult result = this.mockMvc
			.perform(post("/UserManagement/RegisterUser")
			.content("{\r\n" + 
					"	\"firstName\":\"test2\",\r\n" + 
					"	\"lastName\":\"ctslast\",\r\n" + 
					"	\"employeeId\":9456454,\r\n" + 
					"	\"employeeEmailId\":\"ctstest12@cognizant.com\",\r\n" + 
					"	\"supervisorEmailId\":\"ctstest12t@cognizant.com\",\r\n" + 
					"	\"department\":\"CTS\",\r\n" + 
					"	\"progLanguage\":\"DOTNET\",\r\n" + 
					"	\"proficiencylevel\":\"p1\",\r\n" + 
					"	\"frameworks\":\"f1\",\r\n" + 
					"	\"linuxskill\":\"l1\",\r\n" + 
					"	\"fullstackcompleted\":\"fs\",\r\n" + 
					"	\"fullstackskills\":\"fsk\",\r\n" + 
					"	\"userthoughtstraning\":\"ut\",\r\n" + 
					"	\"usercommentstraining\":\"tc\",\r\n" + 
					"	\"phoneNumber\":12353,\r\n" + 
					"	\"uniqueid\":\"734851\"\r\n" + 
					"}")
			.accept(MediaType.parseMediaType("application/json; charset=utf-8"))
			.header("Content-type", "application/json")
			.header("Authorization", "Basic cGFsdXNlcjpTaW1wbGU0dSE="))			
			.andExpect(status().isOk()).andExpect(content().contentType("application/json; charset=utf-8"))
			.andReturn();
			System.out.println(
			"**********************************************************************************************"
			+ "###############################################################################"
			+ result.getResponse().getContentAsString());
			assertNotNull(result.getResponse().getContentAsString());
		}
	
	@Test
	public void insertTest2() throws Exception {
			MvcResult result = this.mockMvc
			.perform(post("/UserManagement/RegisterUser")
			.content("{\r\n" + 
					"	\"firstName\":\"test3\",\r\n" + 
					"	\"lastName\":\"ctslast\",\r\n" + 
					"	\"employeeId\":5456454,\r\n" + 
					"	\"employeeEmailId\":\"ctstest13@cognizant.com\",\r\n" + 
					"	\"supervisorEmailId\":\"ctstest13t@cognizant.com\",\r\n" + 
					"	\"department\":\"CTS\",\r\n" + 
					"	\"progLanguage\":\"DOTNET\",\r\n" + 
					"	\"proficiencylevel\":\"p1\",\r\n" + 
					"	\"frameworks\":\"f1\",\r\n" + 
					"	\"linuxskill\":\"l1\",\r\n" + 
					"	\"fullstackcompleted\":\"fs\",\r\n" + 
					"	\"fullstackskills\":\"fsk\",\r\n" + 
					"	\"userthoughtstraning\":\"ut\",\r\n" + 
					"	\"usercommentstraining\":\"tc\",\r\n" + 
					"	\"phoneNumber\":12353,\r\n" + 
					"	\"uniqueid\":\"734851\"\r\n" + 
					"}")
			.accept(MediaType.parseMediaType("application/json; charset=utf-8"))
			.header("Content-type", "application/json")
			.header("Authorization", "Basic cGFsdXNlcjpTaW1wbGU0dSE="))			
			.andExpect(status().isOk()).andExpect(content().contentType("application/json; charset=utf-8"))
			.andReturn();
			System.out.println(
			"**********************************************************************************************"
			+ "###############################################################################"
			+ result.getResponse().getContentAsString());
			assertNotNull(result.getResponse().getContentAsString());
		}
	
	@Test
	public void insertTest3() throws Exception {
			MvcResult result = this.mockMvc
			.perform(post("/UserManagement/RegisterUser")
			.content("{\r\n" + 
					"	\"firstName\":\"test4\",\r\n" + 
					"	\"lastName\":\"ctslast\",\r\n" + 
					"	\"employeeId\":5456454,\r\n" + 
					"	\"employeeEmailId\":\"ctstest14@cognizant.com\",\r\n" + 
					"	\"supervisorEmailId\":\"ctstest14t@cognizant.com\",\r\n" + 
					"	\"department\":\"CTS\",\r\n" + 
					"	\"progLanguage\":\"DOTNET\",\r\n" + 
					"	\"proficiencylevel\":\"p1\",\r\n" + 
					"	\"frameworks\":\"f1\",\r\n" + 
					"	\"linuxskill\":\"l1\",\r\n" + 
					"	\"fullstackcompleted\":\"fs\",\r\n" + 
					"	\"fullstackskills\":\"fsk\",\r\n" + 
					"	\"userthoughtstraning\":\"ut\",\r\n" + 
					"	\"usercommentstraining\":\"tc\",\r\n" + 
					"	\"phoneNumber\":12353,\r\n" + 
					"	\"uniqueid\":\"734851\"\r\n" + 
					"}")
			.accept(MediaType.parseMediaType("application/json; charset=utf-8"))
			.header("Content-type", "application/json")
			.header("Authorization", "Basic cGFsdXNlcjpTaW1wbGU0dSE="))			
			.andExpect(status().isOk()).andExpect(content().contentType("application/json; charset=utf-8"))
			.andReturn();
			System.out.println(
			"**********************************************************************************************"
			+ "###############################################################################"
			+ result.getResponse().getContentAsString());
			assertNotNull(result.getResponse().getContentAsString());
		}
	*/
}