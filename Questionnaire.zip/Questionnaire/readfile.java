import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class readfile {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		String[] command = {"/bin/sh", "-c", "bash getAppDetails.sh api.system.dev.digifabricpcf.com pcfadmin pcfadmin123 1"};
		
		try {
			String last = "";
			String line;
			Process p = Runtime.getRuntime().exec(command);
			new ProcessBuilder(command).redirectOutput(new File("file.txt")).start();
		 	int exitCode = p.waitFor();
          	BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
          	 while ((line = br.readLine()) != null) {
     	        last = line;
     	    }
     	   
     	    System.out.println("Last Line "+exitCode);
     	    System.out.println("Last Line "+last);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Finished");
	}

}
