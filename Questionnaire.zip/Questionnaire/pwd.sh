/usr/bin/expect -f - <<EOD

spawn sudo user

expect "Password:"

send "cts@f2@f3@blr\r" 

interact