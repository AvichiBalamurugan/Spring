/usr/bin/expect -f

uaac token owner get

expect "Client ID:"

send $1

expect "Client secret:"

send "\r"

expect "User name:"

send $2

expect "Password:"

send $3

interact

