import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class token {
	
	public static void main(String[] args) throws IOException, InterruptedException {
		String output = "";
		String[] command = {"/bin/sh", "-c", "bash 1.sh"};
		
		try {
			String last = "";
			String line;
			Process p = Runtime.getRuntime().exec(command);
			StringBuilder builder = new StringBuilder();
		 	int exitCode = p.waitFor();
          	BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
          	 while ((line = br.readLine()) != null) {
     	        last = line;
     	       // System.out.println(last);
     	         builder.append(line);
  				 builder.append(System.getProperty("line.separator"));
     	    }
     	    output = builder.toString();
     	    
    	    System.out.println(output);
    	    System.out.println("************END************");
        } catch (IOException e) {
            e.printStackTrace();
        }
         System.out.println("Finished");
	}
	
}
