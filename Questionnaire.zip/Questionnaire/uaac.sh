/usr/bin/expect -f - <<EOD

spawn uaac token owner get
expect "Client ID:"
send "opsman\r"
expect "Client secret:"
send "\r"
expect "User name:"
send "pcfopsadmin\r"
expect "Password:"
send "pcfops123\r"
expect eof





