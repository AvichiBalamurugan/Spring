/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.Date;

/**
 *
 * @author Shubh
 */
public class Flight {
    
    private String fNumber;
    private String locFrom;
    private String locTo;
    private Date date;
    private String time;
    private int price;
    private Seat[][] seatArray;
    Airliner airliner;

    public Flight(Airliner airliner) {
        this.airliner = airliner;
    }

    public Flight() {
    }
    
    public void initFlight(){
    seatArray=new Seat[25][6];
    for(int i=0;i<25;i++)
    {
    for(int j=0;j<6;j++)
    {
    seatArray[i][j]=new Seat(this);
    seatArray[i][j].setSeat(true);
    seatArray[i][j].setSeatNo(i+"_"+j);
    }
    }
    
    }

    public Airliner getAirliner() {
        return airliner;
    }

    public void setAirliner(Airliner airliner) {
        this.airliner = airliner;
    }

    public String getfNumber() {
        return fNumber;
    }

    public void setfNumber(String fNumber) {
        this.fNumber = fNumber;
    }

    public String getLocFrom() {
        return locFrom;
    }

    public void setLocFrom(String locFrom) {
        this.locFrom = locFrom;
    }

    public String getLocTo() {
        return locTo;
    }

    public void setLocTo(String locTo) {
        this.locTo = locTo;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Seat[][] getSeatArray() {
        return seatArray;
    }

    public void setSeatArray(Seat[][] seatArray) {
        this.seatArray = seatArray;
    }
    
    

    @Override
    public String toString() {
        return this.fNumber;
    }

    
    
    
}
