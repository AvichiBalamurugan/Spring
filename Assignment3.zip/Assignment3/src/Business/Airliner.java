/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Shubh
 */
public class Airliner {
  
    private String aName;
    private String aAddress;
    private int aPhone;

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public String getaAddress() {
        return aAddress;
    }

    public void setaAddress(String aAddress) {
        this.aAddress = aAddress;
    }

    public int getaPhone() {
        return aPhone;
    }

    public void setaPhone(int aPhone) {
        this.aPhone = aPhone;
    }

    @Override
    public String toString() {
        return this.getaName();
    }
    
    
    
}
