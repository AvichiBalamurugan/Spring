/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

/**
 *
 * @author Shubh
 */
public class Airplane {
    
    private String Model;

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }
    
    /**
     *
     * @return
     */

    @Override
    public String toString() {
        return this.getModel();
    }
    
    
    
}
