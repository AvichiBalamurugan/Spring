/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.ArrayList;

/**
 *
 * @author Shubh
 */
public class AirplaneDirectory {
   
ArrayList<Airplane> airplaneDirectory;


    public Airplane getAirplane() {
        return airplane;
    }

    public void setAirplane(Airplane airplane) {
        this.airplane = airplane;
    }

Airplane airplane;

    public AirplaneDirectory() {
        
       airplaneDirectory=new ArrayList<Airplane>();
    }

    public ArrayList<Airplane> getAirplaneDirectory() {
        return airplaneDirectory;
    }

    public void setAirplaneDirectory(ArrayList<Airplane> airplaneDirectory) {
        this.airplaneDirectory = airplaneDirectory;
    }

    public Airplane addAirplane(){
        Airplane newAirplane=new Airplane();
        airplaneDirectory.add(newAirplane);
        return newAirplane;
    }
    
    public void deleteAirplane(Airplane airplane)
    {
    airplaneDirectory.remove(airplane);
    }
    

    
}
