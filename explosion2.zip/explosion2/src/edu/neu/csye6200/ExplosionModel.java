package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ExplosionModel extends AbstractExplosionModel {

	private List<Explosion> explosionList = new ArrayList<Explosion>();

	@Override
	public void load() {

		Explosion ab = new HydroBomb();
		ab.setMetric(10);
		ab.setName("HydroBomb");
		ab.setWeight(10.0);
		Explosion ab1 = new HydrogenBomb();
		ab1.setMetric(15);
		ab1.setName("HydrogenBomb");
		ab1.setWeight(8.0);
		Explosion ab2 = new NuclearBomb();
		ab2.setMetric(20);
		ab2.setName("NuclearBomb");
		ab2.setWeight(30.0);
		add(ab1);
		add(ab2);
		add(ab);

	}

	@Override
	public void add(Explosion e) {
		this.explosionList.add(e);

	}

	@Override
	public void explodeAll() {
		for (Explosion exp : explosionList) {
			// exp.explode();
			System.out.println(exp);
		}
		System.out.println("Default Sorting");
		Collections.sort(explosionList);
		for (Explosion exp : explosionList) {
			// exp.explode();
			System.out.println(exp);
		}
		
		System.out.println("Name Sorting");
		NameSort ns = new NameSort();
		Collections.sort(explosionList, ns);
		for (Explosion exp : explosionList) {
			// exp.explode();
			System.out.println(exp);
		}
		
		System.out.println("Weight Sorting");
		WeightSort ws = new WeightSort();
		Collections.sort(explosionList, ws);
		for (Explosion exp : explosionList) {
			// exp.explode();
			System.out.println(exp);
		}
	}

	public static void demo() {

		System.out.println("demo from ExplosionModel");
		ExplosionModel object = new ExplosionModel();
		object.load();
		object.explodeAll();

	}

}
