package edu.neu.csye6200;

public abstract class AbstractExplosionModelA {
	
	public abstract void load();
	public abstract void add(AbstractExplosion ae);
	public abstract void explodeAll();
	
	}


