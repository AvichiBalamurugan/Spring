package edu.neu.csye6200;

public abstract class AbstractExplosion{
		public  void explode() {
		System.out.println("Blast from AbstractExplosion");
	}
	
}
