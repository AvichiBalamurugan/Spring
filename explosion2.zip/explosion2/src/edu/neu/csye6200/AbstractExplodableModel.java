package edu.neu.csye6200;

public abstract class AbstractExplodableModel {
	
	public abstract void load();
	public abstract void add(Explodable em);
	public abstract void explodeAll();
	
}
