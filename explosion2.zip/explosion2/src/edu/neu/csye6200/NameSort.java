package edu.neu.csye6200;

import java.util.Comparator;

class NameSort implements Comparator<Explosion> 
{ 
 public int compare(Explosion obj1, Explosion obj2) 
 { 
   return obj1.getName().compareTo(obj2.getName());
 } 
} 