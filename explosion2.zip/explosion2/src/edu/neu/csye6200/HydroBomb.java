package edu.neu.csye6200;

public class HydroBomb extends Explosion{
		public void explode() {
		System.out.println("HydroBomb Blast");
	}

}
