package edu.neu.csye6200;

public abstract class AbstractExplosionModel {
	
	public abstract void load();
	public abstract void add(Explosion e);
	public abstract void explodeAll();
	
	}
 

