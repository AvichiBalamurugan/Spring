package edu.neu.csye6200;

public class NuclearBomb extends Explosion{
	public void explode() {
		System.out.println("NuclearBomb Blast");
	}
}
