package edu.neu.csye6200;

public class AerialBomb extends AbstractExplosion {

	@Override
	public void explode() {
		// TODO Auto-generated method stub
		System.out.println("AerialBomb blast");
	}

	



	

}
