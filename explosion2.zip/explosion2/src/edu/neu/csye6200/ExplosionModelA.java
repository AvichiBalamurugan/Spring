package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ExplosionModelA extends AbstractExplosionModelA{

private static List<AbstractExplosion> explosionList = new ArrayList<AbstractExplosion>();
	
	
	@Override
	public void load() {
		add(new AerialBomb());
		add(new AeroBomb());
		add(new AtomBomb());	
	}

	@Override
	public void add(AbstractExplosion ae) {
		this.explosionList.add(ae);
		
	}

	@Override
	public void explodeAll() {
		for( AbstractExplosion exp:explosionList)
		{
		exp.explode();
	}
	}
		
		public static void demo(){
			
			System.out.println("demo from ExplosionModelA");
			ExplosionModelA object = new ExplosionModelA();
			object.load();
			object.explodeAll();	
			
		}
}
