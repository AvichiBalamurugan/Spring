package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.List;

public class ExplodableModel extends AbstractExplodableModel {
private List<Explodable> explosionList = new ArrayList<Explodable>();
	
	
	@Override
	public void load() {
		add(new BarmudaBomb());
	}

	@Override
	public void add(Explodable e) {
		this.explosionList.add(e);
		
	}

	@Override
	public void explodeAll() {
		for( ExplodableAPI exp:explosionList)
		{
		exp.explode();
	}
	}
		
		public static void demo(){
			
			System.out.println("demo from ExplodableModel");
			ExplodableModel object = new ExplodableModel();
			object.load();
			object.explodeAll();	
			
		}
}
