package edu.neu.csye6200;

public class AeroBomb extends AbstractExplosion {
	

	@Override
	public void explode() {
		// TODO Auto-generated method stub
		System.out.println("Aerobomb Blast");
	}
	

	
}
