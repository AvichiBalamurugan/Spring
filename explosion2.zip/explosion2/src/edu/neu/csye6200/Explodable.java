package edu.neu.csye6200;

public class Explodable implements ExplodableAPI, Comparable<Explodable> {

	@Override
	public void explode() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int compareTo(Explodable exp) {
		// TODO Auto-generated method stub
		return 0;
	}

}
