package edu.neu.csye6200;

public class HydrogenBomb extends Explosion {
		public void explode() {
		System.out.println("HydrogenBomb Blast");
	}


}
