$('.notice-close').on('click', function(event){
  $('.notice-warning').remove();
});