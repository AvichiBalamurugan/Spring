<html>
<head>
<title>Student Database</title>
</head>
<body>
<center><h2 style="color:#F00; background-color:#000">STUDENT DATABASE</h2></center>
<center><ul style="list-style:none;">
<li style="display:inline; padding:15px;"><a href="insert.php" style="text-decoration:none;">Insert</a></li>
<li style="display:inline; padding:15px;"><a href="search.php" style="text-decoration:none;">Search</a></li>
<li style="display:inline; padding:15px;"><a href="update.php" style="text-decoration:none;">Update</a></li>
<li style="display:inline; padding:15px;"><a href="delete.php" style="text-decoration:none;">Delete</a></li>
<li style="display:inline; padding:15px;"><a href="view.php" style="text-decoration:none;">View Records</a></li>
</ul></center>
</body>
</html>