<?php
$server="localhost";
$username="root";
$password="system";
$connect_mysql=mysql_connect($server,$username,$password) or die ("Connection Failed!");
$mysql_db=mysql_select_db("student",$connect_mysql) or die ("Could not Connect to Database");
$query = "SELECT * FROM stud";
$result=mysql_query($query) or die("Query Failed : ".mysql_error());
while($rows=mysql_fetch_array($result))
{
	echo "Roll No: ".$rows['rollno']."<br/>";
	echo "Name: ".$rows['name']."<br/>";
	echo "Total Marks: ".$rows['mark']."<br/>";
	echo "Course: ".$rows['course']."<br/>";
	echo "<br/>";
}
?>
<p align=right><a href="index.php">HOME</a></p>