<html>
<body>
<form method="POST" action="">
Roll No: <input name="rollno" type="text" /><br />
Name: <input name="name" type="text" /><br />
Total Marks: <input name="marks" type="text" /><br />
Course: <input name="course" type="text" /><br />
<input name="submit" type="submit" value="Insert"/><br />
<input name="reset" type="reset" value="Reset"/>
</form>

<?php

if(isset($_POST['submit']))
{
$rollno=$_POST['rollno'];
$name=$_POST['name'];
$marks=$_POST['marks'];
$course=$_POST['course'];

$server="localhost";
$username="root";
$password="system";
$connect_mysql=mysql_connect($server,$username,$password) or die ("Connection Failed!");
$mysql_db=mysql_select_db("student",$connect_mysql) or die ("Could not Connect to Database");
$query = "INSERT INTO stud VALUES ('$rollno','$name','$marks','$course')";
$result=mysql_query($query) or die("Query Failed : ".mysql_error());
$message="Student Details Successfully Added";
echo $message;
mysql_close($connect_mysql);


}
?>

<p align=right><a href="view.php">VIEW RECORDS</a></p>
<p align=right><a href="index.php">HOME</a></p>