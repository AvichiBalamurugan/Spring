<html>
<body>
<?php
$server="localhost";
$username="root";
$password="system";
$connect_mysql=mysql_connect($server,$username,$password) or die ("Connection Failed!");
$mysql_db=mysql_select_db("student",$connect_mysql) or die ("Could not Connect to Database");
$query = "SELECT * FROM stud";
$result=mysql_query($query) or die("Query Failed : ".mysql_error());
$i=0;
while($rows=mysql_fetch_array($result))
{
$roll[$i]=$rows['rollno'];
$i++;
}
$total_elmt=count($roll);
?>
<form method="POST" action="">
Select Roll No: <select name="sel">
<option>Select</option>
<?php 
for($j=0;$j<$total_elmt;$j++)
{
?><option><?php 
echo $roll[$j];
?></option><?php
}
?>
</select>

<input name="submit" type="submit" value="Search"/><br />

</form>

<?php

if(isset($_POST['submit']))
{
$value=$_POST['sel'];

$query2 = "SELECT * FROM stud WHERE rollno='$value'";
$result2=mysql_query($query2) or die("Query Failed : ".mysql_error());
while($row=mysql_fetch_array($result2))
{
	echo "Roll No: ".$row['rollno']."<br/>";
	echo "Name: ".$row['name']."<br/>";
	echo "Total Marks: ".$row['mark']."<br/>";
	echo "Course: ".$row['course'];
}
mysql_close($connect_mysql);
}
?>

<p align=right><a href="index.php">HOME</a></p>