<html>

<head>
<title>System</title>
<link rel="stylesheet" href="main.css">
</head>

<body>

<header>
<div id="nav">
<br>
			<ul>
		<li><a href="home.html"><b>Home</b></a></li>
			</ul>	
		</div>
<div class="head">
<h1 class="logo">Shopping Website</h1>

</div>

</header>

<section class="content">



<div class="reg">
<center>
<h1><b>Message</b></h1>
</center>
		<?php $smsg = "Process was completed Successfully."; 
		if(isset($smsg)){ ?><div class="alert alert-success"> <a href="#" >&times;</a> <?php echo $smsg; ?> </div><?php } ?>
  </div>




</section>





<br><br><br><br>
 <footer class="primary-footer container group">

      <small>&copy; System</small>

    </footer>

</body>
</html>