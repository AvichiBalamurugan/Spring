<html>

<head>
<title>System</title>
<link rel="stylesheet" href="main.css">
<script src= "cartscrpt.js" type="text/javascript"></script>
</head>

<body>

<header>
<div id="nav">
<br>
			<ul>
        <li><a href="view.jsp"><b>View</b></a></li>
        <li><a href="add.html"><b>Add</b></a></li>
        <li><a href="del.html"><b>Delete</b></a></li>
        <li><a href="update.html"><b>Update</b></a></li>
		<li><a href="logout.jsp"><b>Logout</b></a></li>
			</ul>	
		</div>
<div class="head">
<h1 class="logo">Shopping Website</h1>

</div>

</header>



<br><br><br>
<section class="content">
<center>
<table >
<caption>Product Catalog</caption>
 <thead>
 <tr>
 <th>PID</th>
 <th>PName</th>
 <th>Price</th>
 <th>Quantity</th>
 <th>PType</th>
 </tr>
 </thead>
 <tbody>
 <tr>
 <?php
require('connect.php');
$query = "SELECT * FROM product";
$result=mysql_query($query) or die("Query Failed : ".mysql_error());
while($rows=mysql_fetch_array($result))
{
	echo"<td>".$rows['pid']."</td>";
	echo"<td>".$rows['pname']."</td>";
	echo"<td>".$rows['price']."</td>";
	echo"<td>".$rows['qty']."</td>";
	echo"<td>".$rows['ptype']."</td>";
	echo "</tr>";
}
mysql_close($conn);
?>						
</table>							
						
					</center>
</section>

<br><br><br><br><br><br><br><br><br><br><br><br><br>



 <footer class="primary-footer container group">

      <small>&copy; System</small>

    </footer>





</body>
</html>