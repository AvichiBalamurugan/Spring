<html>

<head>
<title>System</title>
<link rel="stylesheet" href="main.css">
</head>


<?php
require('connect.php');
$query = "SELECT * FROM product";
$result=mysql_query($query) or die("Query Failed : ".mysql_error());
$i=0;
while($rows=mysql_fetch_array($result))
{
$roll[$i]=$rows['pid'];
$i++;
}
$total_elmt=count($roll);
?>




<body>
<header>
<div id="nav">
<br>
			<ul>
		<li><a href="home.html"><b>Home</b></a></li>
        <li><a href="add.html"><b>Add</b></a></li>
        <li><a href="update.html"><b>Update</b></a></li>
		<li><a href="logout.jsp"><b>Logout</b></a></li>
			</ul>	
		</div>
<div class="head">
<h1 class="logo">Shopping Website</h1>

</div>

</header>

<section class="content">
<p>Fill All The Fields</p>


<div class="login">
<center>
<h1><b>Update Product</b></h1>
</center>

    
	
	<form method="POST" action="updat.php">
								
									
								
								 <select name="pid" type="text" placeholder="Select the Product ID to Update" required  style="width:250px;"> <br><br>
<option>Select</option>
<?php 
for($j=0;$j<$total_elmt;$j++)
{
?><option><?php 
echo $roll[$j];
?></option><?php
}
?>
</select>
								
											
								 					
							
									 <select name="getval" type="text" placeholder="Product Field" required  style="width:250px;"> <br><br>
                      <option value="pname">Product Name</option>
                      <option value="price">Price</option>
                                      </select>
									
									 <input type="text" name="val" placeholder="Enter Value" required  style="width:250px;"> <br><br>
									
									
								<center>
  <input class="btn btn-alt" type="submit" name="submit" value="Update">&nbsp&nbsp
		  <input class="btn btn-alt" type="reset" name="submit" value="Reset">
		  
		   </center>
  </form>
							
	
	
	
	
	
	
	
	
	
  
  </div>




</section>





<br><br><br><br>
 <footer class="primary-footer container group">

      <small>&copy; System</small>

    </footer>

</body>
</html>