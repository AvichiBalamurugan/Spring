package com.mark;

public class doctrate extends student {


    public void CalculateBand(float phd) {


        if (phd <= 50) {
            System.out.println("Band III");
            System.out.println("Not Eligible");
        } else if (phd <= 70 && phd > 50) {
            System.out.println("Band II");
            System.out.println("Eligible for Group 2");

        } else if (phd > 75 && phd <= 100) {
            System.out.println("Band I");
            System.out.println("Eligible for G");
        } else {
            System.out.println("Invalid data");
        }
    }
}