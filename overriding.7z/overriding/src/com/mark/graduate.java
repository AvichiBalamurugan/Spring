package com.mark;

public class graduate extends student{
    float pg;
}
