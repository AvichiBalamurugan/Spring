package com.mark;
import java.util.Scanner;

public class student {


    public static void main(String[] args) {

        graduate g = new graduate();
        doctrate d = new doctrate();
        school s = new school();
        college c = new college();
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the percentage ");
        float sslc = input.nextFloat();
        float phd = input.nextFloat();
        float ug = input.nextFloat();
        float pg = input.nextFloat();


    }


    public void CalculateBand(float pg) {
        if (pg <= 60) {
            System.out.println("Band III");
            System.out.println("Not Eligible");
        } else if (pg <= 80 && pg > 60) {
            System.out.println("Band II");
            System.out.println("Eligible for Grade 2");

        } else if (pg > 80 && pg <= 100) {
            System.out.println("Band I");
            System.out.println("Eligible for Grade 1");
        } else {
            System.out.println("Invalid data");
        }
    }


}

