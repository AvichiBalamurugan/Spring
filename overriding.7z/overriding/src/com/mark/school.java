package com.mark;

public class school extends student {


    public void CalculateBand(float sslc) {


        if (sslc <= 60) {
            System.out.println("Band III");
            System.out.println("Not Eligible");
        } else if (sslc <= 80 && sslc > 60) {
            System.out.println("Band II");
            System.out.println("Eligible for Grade 2");

        } else if (sslc > 80 && sslc <= 100) {
            System.out.println("Band I");
            System.out.println("Eligible for Grade 1");
        } else {
            System.out.println("Invalid data");
        }
    }
}
