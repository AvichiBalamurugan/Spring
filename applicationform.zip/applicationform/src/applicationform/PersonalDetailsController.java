package applicationform;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PersonalDetailsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public PersonalDetailsController() {
        super();
      
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String nameone = request.getParameter("firstname");
		String nametwo = request.getParameter("lastname");
		String Addr = request.getParameter("address");
		String age = request.getParameter("age");
		String marstatus=request.getParameter("maritalstatus");
		String nation = request.getParameter("nationality");
		
		if(nameone.isEmpty()||nametwo.isEmpty()||Addr.isEmpty()||age.isEmpty()||marstatus.isEmpty()||nation.isEmpty())
		{
			RequestDispatcher rd = request.getRequestDispatcher("personalDetails.jsp");
			out.println("<font color=red>Please fill all the fields</font>");
			rd.include(request, response);
		}
		else
		{
			RequestDispatcher rd = request.getRequestDispatcher("educationalDetails.jsp");
			rd.forward(request, response);
		}
	}

}
