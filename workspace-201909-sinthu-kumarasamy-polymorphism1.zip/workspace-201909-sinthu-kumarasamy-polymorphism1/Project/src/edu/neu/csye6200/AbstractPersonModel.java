package edu.neu.csye6200;

public abstract class AbstractPersonModel {
	public abstract void showPersons();
	public abstract void add(Person p);
	

}
