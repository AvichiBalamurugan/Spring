package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Person implements Comparable<Person> {
	private String name;
	private int age;
	
	@Override
	public int compareTo(Person p) {
		return Integer.compare(this.getAge(), p.getAge());
	}
	
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public String toString() {
		return "Employee name"+name+"and age is"+age;
	}
	
	public static void demo() {
		Person[] perArray = {new Person("Sinthu",20),new Person("Abc",23),new Person("Xyz",25)};
		Person obj1 = new Person("Sinthu",20);
		Person obj2 = new Person("Abc",23);
		Person obj3 = new Person("Xyz",25);
		List<Person> persons = new ArrayList<Person>(Arrays.asList(perArray));
//		persons.add(obj1);
//		persons.add(obj2);
//		persons.add(obj3);
		persons.sort(null);//sort in default order
		for(Person person:persons) {
			System.out.println(person);
		}
		//sort by comparator
		persons.sort(new Comparator<Person>() {

			@Override
			public int compare(Person o1, Person o2) {
				// TODO Auto-generated method stub
				return o1.getName().compareToIgnoreCase(o2.getName());
			}
			
		});
		
		System.out.println("Sort by comparator...");
		for(Person person:persons) {
			System.out.println(person);
		}
		
	}
	

}
