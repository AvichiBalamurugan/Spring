package edu.neu.csye6200;

public class Employee extends Person {
	private double wage;

	public Employee(String name, int age, double wage) {
		super(name, age);
		this.wage = wage;
	}

	public double getWage() {
		return wage;
	}

	public void setWage(double wage) {
		this.wage = wage;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(super.getName());
		sb.append(",age ").append(super.getAge());
		sb.append("  having a wage of ").append(this.getWage());
		return sb.toString();
	}

}
