package edu.neu.csye6200;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PersonModel.demo();
		Person.demo();

	}

}
