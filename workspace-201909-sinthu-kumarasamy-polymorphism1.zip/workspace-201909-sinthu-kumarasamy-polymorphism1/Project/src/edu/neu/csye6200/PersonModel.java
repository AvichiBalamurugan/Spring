package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.List;

public class PersonModel extends AbstractPersonModel{
	List<Person>persons = new ArrayList<Person>();
	
	@Override
	 public void add(Person p) {
		 persons.add(p);
	 }
	
	@Override
	public void showPersons() {
		for(Person p:persons) {
			System.out.println(p);
		}
	}
	
	public static void demo() {
		PersonModel obj = new PersonModel();
		obj.add(new Student("Keerthana",25,3.7));
		obj.add(new Employee("Sinthu",24,20.00));
		obj.showPersons();
	}

}
