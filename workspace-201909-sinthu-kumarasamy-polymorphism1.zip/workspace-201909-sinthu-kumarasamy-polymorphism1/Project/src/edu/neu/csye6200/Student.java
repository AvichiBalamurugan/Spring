package edu.neu.csye6200;

public class Student extends Person{
	private double gpa;
	
	public Student(String name,int age,double gpa) {
		super(name,age);
		this.gpa = gpa;
	}
	
	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(super.getName());	
		sb.append(",age ").append(super.getAge());
		sb.append("  having a wage of ").append(this.getGpa());
		return sb.toString();
	}
}
