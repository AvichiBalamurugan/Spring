package com.palusers.emailscheduler.logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class LoggerFactory {

	@Autowired
	private ILogger fileAppenderLog;
	
	@Value("${logger_select}")
	private String logger_select;
	
	@Value("${file}")
	private String file;
	
	public ILogger getLoggerInstance() {		
		String loggerMode = logger_select;
		if (loggerMode.equalsIgnoreCase(file)) {
			return fileAppenderLog;
		} 
		//TODO
		return fileAppenderLog;
	}
}
