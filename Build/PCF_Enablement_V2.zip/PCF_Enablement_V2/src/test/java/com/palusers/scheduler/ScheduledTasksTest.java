package com.palusers.scheduler;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import com.palusers.scheduler.*;

public class ScheduledTasksTest {

	private ScheduledTasks scheduledTasks;
	@Before
	public void setup() 
	{
		scheduledTasks = Mockito.mock(ScheduledTasks.class);				
	}
	
	@Test
    public void runJob() 
    {	
		scheduledTasks.createAccountJob();
		verify(scheduledTasks, times(1)).createAccountJob();	
    }
	
	@Test
    public void deleteAccount() 
    {	
		scheduledTasks.deleteAccount();
		verify(scheduledTasks, times(1)).deleteAccount();
    }
}
