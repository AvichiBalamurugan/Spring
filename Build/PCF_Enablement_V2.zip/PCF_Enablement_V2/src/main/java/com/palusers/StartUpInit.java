package com.palusers;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.palusers.cloudAPI.ManageUsers;
import com.palusers.controllers.UserController;
import com.palusers.logger.LoggerFactory;
import com.palusers.scheduler.ScheduledTasks;

@Component
public class StartUpInit {

  @Autowired
  UserController uc; 
  
  @Autowired
  ManageUsers  mu;
  
  @Autowired
  ScheduledTasks st;

  @PostConstruct
  public void init(){
     uc.setUserController();
     mu.setManageUsers();
     st.setScheduledTasks();
  }
}