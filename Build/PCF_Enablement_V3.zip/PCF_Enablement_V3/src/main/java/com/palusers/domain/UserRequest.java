package com.palusers.domain;
 

public class UserRequest {	 
	public String firstName;	
	public String lastName;
	public Long employeeId;	
	public String employeeEmailId;	
	public String supervisorEmailId;	
	public String department;
	public String progLanguage;	
	public String phoneNumber;	
	public String timeZone;	
	public String uniqueid;
	public String proficiencylevel;
	public String frameworks;
	public String linuxskill;
	public String fullstackcompleted;
	public String fullstackskills;
	public String userthoughtstraning;
	public String usercommentstraining;
}
