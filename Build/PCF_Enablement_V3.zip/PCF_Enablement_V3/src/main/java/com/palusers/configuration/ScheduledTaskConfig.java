package com.palusers.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
public class ScheduledTaskConfig {

	private String accountcreationemailsubject;	

	private String userpasswordlength;	
	
	private String deletesubject;
	
	private String deleteerrormessgae;
	
	private String deleteerrorsubject;
	
	private String errorinAccountCreationmsg;
	
	private String errorinAccountCreationsubject;
	
	private String deleteremaindermessage;
	
	private String deletremainderesubject;
	
	private String deletemessage;
	
	private String spacename;
	
	private String noofattempts;
	
	private String getdeletebackdays;
	
	private String getremainderDeletedays;	
	
	private String oauthpassword;
	
	private String oauthusername;
	
	private String uaalogin;

	public String getAccountcreationemailsubject() {
		return accountcreationemailsubject;
	}

	public void setAccountcreationemailsubject(String accountcreationemailsubject) {
		this.accountcreationemailsubject = accountcreationemailsubject;
	}

	public String getUserpasswordlength() {
		return userpasswordlength;
	}

	public void setUserpasswordlength(String userpasswordlength) {
		this.userpasswordlength = userpasswordlength;
	}

	public String getDeletesubject() {
		return deletesubject;
	}

	public void setDeletesubject(String deletesubject) {
		this.deletesubject = deletesubject;
	}

	public String getDeleteerrormessgae() {
		return deleteerrormessgae;
	}

	public void setDeleteerrormessgae(String deleteerrormessgae) {
		this.deleteerrormessgae = deleteerrormessgae;
	}

	public String getDeleteerrorsubject() {
		return deleteerrorsubject;
	}

	public void setDeleteerrorsubject(String deleteerrorsubject) {
		this.deleteerrorsubject = deleteerrorsubject;
	}

	public String getErrorinAccountCreationmsg() {
		return errorinAccountCreationmsg;
	}

	public void setErrorinAccountCreationmsg(String errorinAccountCreationmsg) {
		this.errorinAccountCreationmsg = errorinAccountCreationmsg;
	}

	public String getErrorinAccountCreationsubject() {
		return errorinAccountCreationsubject;
	}

	public void setErrorinAccountCreationsubject(String errorinAccountCreationsubject) {
		this.errorinAccountCreationsubject = errorinAccountCreationsubject;
	}

	public String getDeleteremaindermessage() {
		return deleteremaindermessage;
	}

	public void setDeleteremaindermessage(String deleteremaindermessage) {
		this.deleteremaindermessage = deleteremaindermessage;
	}

	public String getDeletremainderesubject() {
		return deletremainderesubject;
	}

	public void setDeletremainderesubject(String deletremainderesubject) {
		this.deletremainderesubject = deletremainderesubject;
	}

	public String getDeletemessage() {
		return deletemessage;
	}

	public void setDeletemessage(String deletemessage) {
		this.deletemessage = deletemessage;
	}

	public String getSpacename() {
		return spacename;
	}

	public void setSpacename(String spacename) {
		this.spacename = spacename;
	}

	public String getNoofattempts() {
		return noofattempts;
	}

	public void setNoofattempts(String noofattempts) {
		this.noofattempts = noofattempts;
	}

	public String getGetdeletebackdays() {
		return getdeletebackdays;
	}

	public void setGetdeletebackdays(String getdeletebackdays) {
		this.getdeletebackdays = getdeletebackdays;
	}

	public String getGetremainderDeletedays() {
		return getremainderDeletedays;
	}

	public void setGetremainderDeletedays(String getremainderDeletedays) {
		this.getremainderDeletedays = getremainderDeletedays;
	}

	public String getOauthpassword() {
		return oauthpassword;
	}

	public void setOauthpassword(String oauthpassword) {
		this.oauthpassword = oauthpassword;
	}

	public String getOauthusername() {
		return oauthusername;
	}

	public void setOauthusername(String oauthusername) {
		this.oauthusername = oauthusername;
	}

	public String getUaalogin() {
		return uaalogin;
	}

	public void setUaalogin(String uaalogin) {
		this.uaalogin = uaalogin;
	}
}
