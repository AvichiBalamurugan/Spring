package com.palusers.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
public class UserControllerConfig {
	
	private String welcomepalemailsubject;
	
	private String invalidemailsubject;
	
	private String invalidemailmsg;
	
	private String invalidaccountsubject;
	
	private String invalidaccountmsg;
	
	private String maliciousemailsubject;
	
	private String invaliduniqueidsubject;

	private String invaliduniqueidmsg;

	private String maliciousemailmsg;
		
	private String limitmailsubject;
	
	private int userlimit;

	public String getWelcomepalemailsubject() {
		return welcomepalemailsubject;
	}

	public void setWelcomepalemailsubject(String welcomepalemailsubject) {
		this.welcomepalemailsubject = welcomepalemailsubject;
	}

	public String getInvalidemailsubject() {
		return invalidemailsubject;
	}

	public void setInvalidemailsubject(String invalidemailsubject) {
		this.invalidemailsubject = invalidemailsubject;
	}

	public String getInvalidemailmsg() {
		return invalidemailmsg;
	}

	public void setInvalidemailmsg(String invalidemailmsg) {
		this.invalidemailmsg = invalidemailmsg;
	}

	public String getInvalidaccountsubject() {
		return invalidaccountsubject;
	}

	public void setInvalidaccountsubject(String invalidaccountsubject) {
		this.invalidaccountsubject = invalidaccountsubject;
	}

	public String getInvalidaccountmsg() {
		return invalidaccountmsg;
	}

	public void setInvalidaccountmsg(String invalidaccountmsg) {
		this.invalidaccountmsg = invalidaccountmsg;
	}

	public String getMaliciousemailsubject() {
		return maliciousemailsubject;
	}

	public void setMaliciousemailsubject(String maliciousemailsubject) {
		this.maliciousemailsubject = maliciousemailsubject;
	}

	public String getInvaliduniqueidsubject() {
		return invaliduniqueidsubject;
	}

	public void setInvaliduniqueidsubject(String invaliduniqueidsubject) {
		this.invaliduniqueidsubject = invaliduniqueidsubject;
	}

	public String getInvaliduniqueidmsg() {
		return invaliduniqueidmsg;
	}

	public void setInvaliduniqueidmsg(String invaliduniqueidmsg) {
		this.invaliduniqueidmsg = invaliduniqueidmsg;
	}

	public String getMaliciousemailmsg() {
		return maliciousemailmsg;
	}

	public void setMaliciousemailmsg(String maliciousemailmsg) {
		this.maliciousemailmsg = maliciousemailmsg;
	}

	public String getLimitmailsubject() {
		return limitmailsubject;
	}

	public void setLimitmailsubject(String limitmailsubject) {
		this.limitmailsubject = limitmailsubject;
	}

	public int getUserlimit() {
		return userlimit;
	}

	public void setUserlimit(int userlimit) {
		this.userlimit = userlimit;
	}
	
	
}
