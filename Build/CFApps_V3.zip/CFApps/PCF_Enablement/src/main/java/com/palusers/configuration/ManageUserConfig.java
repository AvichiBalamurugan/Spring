package com.palusers.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
public class ManageUserConfig {

	private String uaaloginurl;
	
	private String uaacreateuser;
	
	private String uaacreateorg;
	
	private String uaacreatespace;
	
	private String uaadeleteapps;

	private String uaadeletespaceroute;
		
	private String uaadeleteservice;
	
	private String uaadeleteusers;
	
	private String oauthToken;

	public String getUaaloginurl() {
		return uaaloginurl;
	}

	public void setUaaloginurl(String uaaloginurl) {
		this.uaaloginurl = uaaloginurl;
	}

	public String getUaacreateuser() {
		return uaacreateuser;
	}

	public void setUaacreateuser(String uaacreateuser) {
		this.uaacreateuser = uaacreateuser;
	}

	public String getUaacreateorg() {
		return uaacreateorg;
	}

	public void setUaacreateorg(String uaacreateorg) {
		this.uaacreateorg = uaacreateorg;
	}

	public String getUaacreatespace() {
		return uaacreatespace;
	}

	public void setUaacreatespace(String uaacreatespace) {
		this.uaacreatespace = uaacreatespace;
	}

	public String getUaadeleteapps() {
		return uaadeleteapps;
	}

	public void setUaadeleteapps(String uaadeleteapps) {
		this.uaadeleteapps = uaadeleteapps;
	}

	public String getUaadeletespaceroute() {
		return uaadeletespaceroute;
	}

	public void setUaadeletespaceroute(String uaadeletespaceroute) {
		this.uaadeletespaceroute = uaadeletespaceroute;
	}

	public String getUaadeleteservice() {
		return uaadeleteservice;
	}

	public void setUaadeleteservice(String uaadeleteservice) {
		this.uaadeleteservice = uaadeleteservice;
	}

	public String getUaadeleteusers() {
		return uaadeleteusers;
	}

	public void setUaadeleteusers(String uaadeleteusers) {
		this.uaadeleteusers = uaadeleteusers;
	}

	public String getOauthToken() {
		return oauthToken;
	}

	public void setOauthToken(String oauthToken) {
		this.oauthToken = oauthToken;
	}
	
	
	
}
