package com.palusers.emailscheduler.configuration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties
public class ConfigProperties {

	private String supportteam;

	private String dotneturl;

	private String javaurl;

	private String apiurl;

	private String appmanagerurl;

	private String accountcreationurl;

	private String logger_select;

	private String file;

	private String awssource;

	private String appmanagerconsole;

	private String cfcli;

	private String cfclidownload;

	private String accesskey;

	private String secretkey;

	public String getSupportteam() {
		return supportteam;
	}

	public void setSupportteam(String supportteam) {
		this.supportteam = supportteam;
	}

	public String getDotneturl() {
		return dotneturl;
	}

	public void setDotneturl(String dotneturl) {
		this.dotneturl = dotneturl;
	}

	public String getJavaurl() {
		return javaurl;
	}

	public void setJavaurl(String javaurl) {
		this.javaurl = javaurl;
	}

	public String getApiurl() {
		return apiurl;
	}

	public void setApiurl(String apiurl) {
		this.apiurl = apiurl;
	}

	public String getAppmanagerurl() {
		return appmanagerurl;
	}

	public void setAppmanagerurl(String appmanagerurl) {
		this.appmanagerurl = appmanagerurl;
	}

	public String getAccountcreationurl() {
		return accountcreationurl;
	}

	public void setAccountcreationurl(String accountcreationurl) {
		this.accountcreationurl = accountcreationurl;
	}

	public String getLogger_select() {
		return logger_select;
	}

	public void setLogger_select(String logger_select) {
		this.logger_select = logger_select;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getAwssource() {
		return awssource;
	}

	public void setAwssource(String awssource) {
		this.awssource = awssource;
	}

	public String getAppmanagerconsole() {
		return appmanagerconsole;
	}

	public void setAppmanagerconsole(String appmanagerconsole) {
		this.appmanagerconsole = appmanagerconsole;
	}

	public String getCfcli() {
		return cfcli;
	}

	public void setCfcli(String cfcli) {
		this.cfcli = cfcli;
	}

	public String getCfclidownload() {
		return cfclidownload;
	}

	public void setCfclidownload(String cfclidownload) {
		this.cfclidownload = cfclidownload;
	}

	public String getAccesskey() {
		return accesskey;
	}

	public void setAccesskey(String accesskey) {
		this.accesskey = accesskey;
	}

	public String getSecretkey() {
		return secretkey;
	}

	public void setSecretkey(String secretkey) {
		this.secretkey = secretkey;
	}

}
