package com.palusers.emailscheduler.logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.palusers.emailscheduler.configuration.ConfigProperties;


@Component
public class LoggerFactory {

	@Autowired
	private ILogger fileAppenderLog;
	
	@Autowired
    private ConfigProperties config;
	
    private String logger_select;
	
	private String file;
	
	public void setLogger_select() {
		this.logger_select = config.getLogger_select();
	}

	public void setFile() {
		this.file = config.getFile();
	}
	
	public ILogger getLoggerInstance() {	
		setLogger_select();
		setFile();
		String loggerMode = logger_select;
		if (loggerMode.equalsIgnoreCase(file)) {
			return fileAppenderLog;
		} 
		//TODO
		return fileAppenderLog;
	}
}
