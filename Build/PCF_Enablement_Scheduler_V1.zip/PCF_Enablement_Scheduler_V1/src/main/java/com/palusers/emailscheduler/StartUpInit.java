package com.palusers.emailscheduler;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.palusers.emailscheduler.scheduler.ScheduledTasks;
import com.palusers.emailscheduler.services.EmailSender;


@Component
public class StartUpInit {

  @Autowired
  EmailSender es; 
  
  @Autowired
  ScheduledTasks st;

  @PostConstruct
  public void init(){
     es.setEmailSender();
     st.setScheduledTasks();
  }
}