package com.palusers.emailscheduler.rabbitmq;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.palusers.emailscheduler.services.EmailSender;

@Component
public class RabbitMqConsumer {

	@Autowired
	private EmailSender emailSender;

	 @Bean
	 public Queue queue(){
	 return new Queue("spring-queue", false);
	 }
	//
	// @RabbitListener(queues="spring-queue")
	// public void recievedMessage(String message) {
	// System.out.println("Recieved Message: " + message);
	// EmailRequest emailData = new EmailRequest();
	// emailData.Recipient = "Sneha.Saha2@cognizant.com";
	// emailData.Subject = "Runner Memory Exceeded";
	// emailData.Message = message;
	// // emailSender.sendMemoryMail(emailData);
	// System.out.println("Message Sent to " + emailData.Recipient + " with Subject
	// " + emailData.Subject + " and Message " + emailData.Message);
	// }

	    @RabbitListener(queues = "spring-queue")
	    public void process(String message) {
	        System.out.println(">>> " + message);
	    }

}