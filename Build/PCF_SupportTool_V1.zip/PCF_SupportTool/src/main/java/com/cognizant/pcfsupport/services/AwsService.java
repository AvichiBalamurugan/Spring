package com.cognizant.pcfsupport.services;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.cognizant.pcfsupport.utils.SSLCertificateValidation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class AwsService {
	
	@Value("${producturl}")
	private String producturl;
	
	@Value("${productResource_url}")
	private String productresource_url;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	RestTemplate restTemplate = new RestTemplate();
	
	HttpHeaders headers = new HttpHeaders();
	
	String access_token = getAwsToken();
	String bearer = "Bearer " + access_token;
	
	public String getProductGuid() throws JsonProcessingException, IOException {
		String product_guid = "";
		SSLCertificateValidation.disable();
		headers.set("Authorization", bearer);
		final String productUrl = producturl;

		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<String> responseProducts = restTemplate.exchange(productUrl, HttpMethod.GET, entity, String.class);
		String result = responseProducts.getBody();
		final JsonNode products = new ObjectMapper().readTree(result);
		logger.info("****************Products Response**********" + products.toString());
		
		if (products.isArray()) {
			for (final JsonNode objNode : products) {
				JsonNode type = objNode.get("type");
				if ((type.toString()).equals("\"cf\"")) {
					JsonNode guid = objNode.get("guid");
					product_guid = guid.toString().replace("\"", "");
					logger.info("****************Guid Response**********" + guid.toString());

					logger.info("****************Product Guid Response**********" + product_guid);

				}
			}
		}
		return product_guid;
	}
	
	public String getTotalRunnerMemory() throws JsonProcessingException, IOException {
		
		SSLCertificateValidation.disable();
		String product_guid = getProductGuid();
		String diegoInstance = "";
		final String productResource_url = productresource_url
				+ product_guid + "/resources";
		logger.info("****************Product_url**********" + productResource_url);
		
		HttpEntity<String> entity = new HttpEntity<String>(headers);

		ResponseEntity<String> resource = restTemplate.exchange(productResource_url, HttpMethod.GET, entity, String.class);
		String product_result = resource.getBody();
		logger.info("****************product_result**********" + product_result);

		final JsonNode productResources = new ObjectMapper().readTree(product_result).get("resources");

		if (productResources.isArray()) {
			for (final JsonNode objNode : productResources) {

				String id_name = "\"diego_cell\"";
				if (objNode.get("identifier").toString().equals(id_name)) {
					JsonNode instance = objNode.get("instances");
					JsonNode instance_type = objNode.get("instance_type_best_fit");

					logger.info("****************Instance**********" + instance);
					logger.info("****************Instance Type**********" + instance_type);
					
					diegoInstance = "Number of Instances is " + instance.toString() + " and Instance Type is " + instance_type.toString();
				}
			}
		}

		return diegoInstance;
	}
	
	public String getAwsToken()
	{
		String response = "access_token: eyJhbGciOiJSUzI1NiIsImtpZCI6ImtleS0xIiwidHlwIjoiSldUIn0.eyJqdGkiOiJhNTBlY2MxYjI2MmY0MDdlODVhMmJkNGUxOTg0NWY3MCIsInN1YiI6IjYyYTA2MDU0LTZhY2YtNDU1YS05N2IzLWQxZWM1MTJhOGUzMyIsInNjb3BlIjpbIm9wc21hbi5hZG1pbiIsInNjaW0ubWUiLCJvcHNtYW4udXNlciIsInVhYS5hZG1pbiIsImNsaWVudHMuYWRtaW4iXSwiY2xpZW50X2lkIjoib3BzbWFuIiwiY2lkIjoib3BzbWFuIiwiYXpwIjoib3BzbWFuIiwiZ3JhbnRfdHlwZSI6InBhc3N3b3JkIiwidXNlcl9pZCI6IjYyYTA2MDU0LTZhY2YtNDU1YS05N2IzLWQxZWM1MTJhOGUzMyIsIm9yaWdpbiI6InVhYSIsInVzZXJfbmFtZSI6InBjZm9wc2FkbWluIiwiZW1haWwiOiJhZG1pbkB0ZXN0Lm9yZyIsImF1dGhfdGltZSI6MTUxNjY3NzgzNCwicmV2X3NpZyI6ImUyZWJmZDVkIiwiaWF0IjoxNTE2Njc3ODM0LCJleHAiOjE1MTY3MjEwMzQsImlzcyI6Imh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC91YWEvb2F1dGgvdG9rZW4iLCJ6aWQiOiJ1YWEiLCJhdWQiOlsic2NpbSIsIm9wc21hbiIsImNsaWVudHMiLCJ1YWEiXX0.YBqZlgljlVBFjpBokEtji6vzoMN-Cda-52T2_DmHyM6Ysk5ANZczG4PUt3r5ADjHIAsiKIFYQZytZMi-3nVfULNOj1lc1ySCcxupZNMPExW7K_eGangnfjNZQ41jGTOmWZSypBu2ivKp47B91lxxyMbaVB_3whm3lGBYdJj8KkFH0sX6xSyRh_uxMZ8xv454XihxUt_r5rJp8aLAwo6c-wKZjmqFojmjbYRvgJjpwMnVK_EKL11SPbfXtDDUaikZ_7MmIDdYfpU9lxiNDpiFdhqRCR7JtEmi_wflcMSq0ZfegW6ZAa6ozd55LrMKqEO1-5A62kENKhOsUUxfGb4Iww\n" + 
				"      token_type: bearer";
		String awstoken = StringUtils.substringBetween(response, "access_token: ", "      token_type");
		awstoken = awstoken.replace("\n", "");
		return awstoken;
	}
}
