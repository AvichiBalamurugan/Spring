package com.cognizant.pcfsupport.common;

public class ApplicationConstants {

	public static final String AUTHORIZATION = "authorization";
	public static final String BASIC_AUTHORIZATION = "Basic Y2Y6";
	
	//JSON Constants
	public static final String ACCESS_TOKEN = "access_token";
}
