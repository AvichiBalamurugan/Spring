package com.cognizant.pcfsupport.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cognizant.pcfsupport.PcfSupportToolApplication;
import com.cognizant.pcfsupport.exception.AppMemoryException;
import com.cognizant.pcfsupport.exception.NullValuesFoundException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.exceptions.UnirestException;

@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcfSupportToolApplication.class)
public class ApiServiceTest {
 
 	private ApiService mock = Mockito.mock(ApiService.class);
          
    final static Logger logger = Logger.getLogger(ApiServiceTest.class);
   
    @Test
    public void whenRequestIsCorrect_getApiAccessToken() throws JsonProcessingException, UnirestException, IOException {
   
    	when(mock.getApiAccessToken()).thenReturn("Bearer");
        assertEquals("Bearer", mock.getApiAccessToken());
    }
    
    @Test
    public void whenRequestIsNotCorrect_getApiAccessToken() throws JsonProcessingException, UnirestException, IOException {
   
    	when(mock.getApiAccessToken()).thenReturn("");        
    	assertNotEquals("Bearer", mock.getApiAccessToken());
    	
    }
    
	@SuppressWarnings("unchecked")
	@Test(expected = AppMemoryException.class)
    public void IfMemoryIsEmpty_getTotalAppMemory() throws Exception {
    	when(mock.getTotalAppMemory()).thenThrow(AppMemoryException.class);       
    	mock.getTotalAppMemory();
    }
	
	@Test
    public void IfMemoryIsNotEmpty_getTotalAppMemory() throws Exception {
    		when(mock.getTotalAppMemory()).thenReturn(9000);
    		assertEquals(9000, mock.getTotalAppMemory());
    }
	
	
	
 }