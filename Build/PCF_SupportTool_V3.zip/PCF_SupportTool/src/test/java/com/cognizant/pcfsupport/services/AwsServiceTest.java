package com.cognizant.pcfsupport.services;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cognizant.pcfsupport.PcfSupportToolApplication;
import com.cognizant.pcfsupport.exception.AccessTokenException;
import com.cognizant.pcfsupport.exception.ProductGuidException;
import com.cognizant.pcfsupport.exception.TotalMemoryException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.exceptions.UnirestException;

@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcfSupportToolApplication.class)
public class AwsServiceTest {

	private AwsService mock = Mockito.mock(AwsService.class);
    
    final static Logger logger = Logger.getLogger(AwsServiceTest.class);
    
    @SuppressWarnings("unchecked")
	@Test(expected = AccessTokenException.class)
    public void whenAccessTokenIsNull_getProductGuid() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException {
   
    	when(mock.getProductGuid()).thenThrow(AccessTokenException.class);
    mock.getProductGuid();  
    }
    
    @SuppressWarnings("unchecked")
	@Test(expected = ProductGuidException.class)
    public void whenGuidIsNull_getProductGuid() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException {
    	when(mock.getProductGuid()).thenThrow(ProductGuidException.class);
    	mock.getProductGuid(); 
    }
    
    @Test
    public void whenGuidIsReturned_getProductGuid() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException {
    	when(mock.getProductGuid()).thenReturn("cf-2fa6d442ae3b944d2de7");
    	assertEquals("cf-2fa6d442ae3b944d2de7",mock.getProductGuid());
    }
      
    @SuppressWarnings("unchecked")
	@Test(expected = ProductGuidException.class)
    public void whenGuidIsNull_getTotalRunnerMemory() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException {
    	when(mock.getTotalRunnerMemory()).thenThrow(ProductGuidException.class);
    	mock.getTotalRunnerMemory(); 
    }
    
    @SuppressWarnings("unchecked")
   	@Test(expected = TotalMemoryException.class)
       public void whenMemoryIsEmpty_getTotalRunnerMemory() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException {
       	when(mock.getTotalRunnerMemory()).thenThrow(TotalMemoryException.class);
       	mock.getTotalRunnerMemory(); 
       }
    
    @Test
    public void whenMemoryIsNotEmpty_getTotalRunnerMemory() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException {
    	List<String> object = Arrays.asList("Number of Instances is 4"," and Instance Type is r3.large"," with Total Memory 120");
    	when(mock.getTotalRunnerMemory()).thenReturn(object);
    	assertEquals(object,mock.getTotalRunnerMemory());
    }
    
    @SuppressWarnings("unchecked")
   	@Test(expected = AccessTokenException.class)
       public void whenRequestIsIncorrect_getAwsToken() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException {
       	when(mock.getAwsToken()).thenThrow(AccessTokenException.class);
       	mock.getAwsToken(); 
       }
    
    @Test
    public void whenRequestIsCorrect_getAwsToken() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException {
    	when(mock.getAwsToken()).thenReturn("EYfa6d442ae3b944d2de7");
    	assertEquals("EYfa6d442ae3b944d2de7",mock.getAwsToken());
    }
}
