package com.cognizant.pcfsupport.common;

public class ApplicationConstants {

	public static final String AUTHORIZATION = "authorization";
	public static final String BASIC_AUTHORIZATION = "Basic Y2Y6";
	
	//JSON Constants
	public static final String ACCESS_TOKEN = "access_token";	
	public static final String TOTAL_PAGES = "total_pages";
	public static final String RESOURCES = "resources";
	public static final String GUID = "guid";
	public static final String ENTITY = "entity";
	public static final String STATE = "state";
	public static final String MEMORY = "memory";
	public static final String STARTED = "\"STARTED\"";
	public static final String STOPPED = "\"STOPPED\"";
	public static final String TYPE = "type";
	public static final String CF_IDENTIFIER = "\"cf\"";
	public static final String DIEGO_CELL = "\"diego_cell\"";
	public static final String IDENTIFIER = "identifier";
	public static final String INSTANCES = "instances";
	public static final String INSTANCES_TYPE_BEST_FIT = "instance_type_best_fit";
	
	//VM Types
	public static final String r3xlarge = "\"r3.xlarge\"";
	public static final String t2micro = "\"t2.micro\"";
	public static final String t2small = "\"t2.small\"";
	public static final String m3medium = "\"m3.medium\"";
	public static final String c4large = "\"c4.large\"";
	public static final String m3large = "\"m3.large\"";
	public static final String r3large = "\"r3.large\"";
	public static final String c4xlarge = "\"c4.xlarge\"";
	public static final String m3xlarge = "\"m3.xlarge\"";
	public static final String c42xlarge = "\"c4.2xlarge\"";
	public static final String m32xlarge = "\"m3.2xlarge\"";
	public static final String r32xlarge = "\"r3.2xlarge\"";
	public static final String c44xlarge = "\"c4.4xlarge\"";
	public static final String r34xlarge = "\"r3.4xlarge\"";
	public static final String i28xlarge = "\"i2.8xlarge\"";
	public static final String d28xlarge = "\"d2.8xlarge\"";
	
	//VM Ram Memory
	
	public static final double r3xlarge_ram = 30.5;
	public static final double t2micro_ram = 1;
	public static final double t2small_ram = 2;
	public static final double m3medium_ram = 3.75;
	public static final double c4large_ram = 3.75;
	public static final double m3large_ram = 7.5;
	public static final double r3large_ram = 15.3;
	public static final double c4xlarge_ram = 7.5;
	public static final double m3xlarge_ram = 15;
	public static final double c42xlarge_ram = 15;
	public static final double m32xlarge_ram = 30;
	public static final double r32xlarge_ram = 61;
	public static final double c44xlarge_ram = 30;
	public static final double r34xlarge_ram = 122;
	public static final double i28xlarge_ram = 244;
	public static final double d28xlarge_ram = 244;
	
	
}
