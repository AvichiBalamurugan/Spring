package com.cognizant.pcfsupport.rabbitmq;

import java.io.IOException;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cognizant.pcfsupport.exception.NoMessageFoundException;
import com.cognizant.pcfsupport.services.ApiService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.exceptions.UnirestException;

@Component
public class RabbitMqProducer {
	
	@Autowired
	private AmqpTemplate amqpTemplate;
	
	@Autowired
	private ApiService apiService;
	
	@Value("${jsa.rabbitmq.exchange}")
	private String exchange;
	
	@Value("${jsa.rabbitmq.routingkey}")
	private String routingkey;

	private int limit = 90000;
	
	public void produce() throws JsonProcessingException, UnirestException, IOException
	{
		String message = "";
		int memory = apiService.getTotalAppMemory();
		if(memory>limit)
		{
			message = "Total App Memory has got exceeded the pre-configured memory. Currently total memory used is "+ Integer.toString(memory);
			amqpTemplate.convertAndSend(exchange, routingkey, message);
			System.out.println("Send msg = " + message);
		}
		
	}
	
	public void testProduce(String message){		
		if(message==null || message.isEmpty())
		{
			throw new NoMessageFoundException();
		}
		amqpTemplate.convertAndSend(exchange, routingkey, message);
		System.out.println("Send msg = " + message);
			
	}
}

