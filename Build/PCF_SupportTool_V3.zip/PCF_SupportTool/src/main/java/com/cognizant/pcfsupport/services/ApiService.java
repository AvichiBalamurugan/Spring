package com.cognizant.pcfsupport.services;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cognizant.pcfsupport.common.ApplicationConstants;
import com.cognizant.pcfsupport.exception.AppMemoryException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

@Component
public class ApiService {
	
	@Value("${oauthTokenAPI}")
	private String oauthTokenAPI;
	
	@Value("${uaagetapplist}")
	private String uaagetapplist;
	
	@Value("${nextpageapplist}")
	private String nextpageapplist;
	
	@Value("${resultlimit}")
	private String resultlimit;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	public String getApiAccessToken() throws UnirestException, JsonProcessingException, IOException {
		HttpResponse<String> responseApiToken = Unirest.get(
				oauthTokenAPI)
				.header(ApplicationConstants.AUTHORIZATION, ApplicationConstants.BASIC_AUTHORIZATION).asString();
		final JsonNode accessToken = new ObjectMapper().readTree(responseApiToken.getBody()).get(ApplicationConstants.ACCESS_TOKEN);
		logger.info("****************Token**********" + accessToken);
		String bearer = "Bearer " + accessToken.toString();
		bearer = bearer.replace("\"", "");
		return bearer;
	}

	public int getTotalAppMemory() throws JsonProcessingException, UnirestException, IOException {
		int memory = 0;
		String bearer = getApiAccessToken();
		HttpResponse<String> responseNoOfPages = Unirest
				.get(uaagetapplist)
				.header(ApplicationConstants.AUTHORIZATION, bearer).asString();
		logger.info("****************Response**********" + responseNoOfPages.getBody());

		final JsonNode totalPages = new ObjectMapper().readTree(responseNoOfPages.getBody()).get(ApplicationConstants.TOTAL_PAGES);
		int pages = totalPages.asInt();

		for (int i = 1; i <= pages; i++) {
			String apiURL = nextpageapplist + Integer.toString(i)
					+ resultlimit;
			logger.info("****************API URL**********" + apiURL);
			HttpResponse<String> nextAppResponse = Unirest.get(apiURL).header(ApplicationConstants.AUTHORIZATION, bearer).asString();
			final JsonNode appResources = new ObjectMapper().readTree(nextAppResponse.getBody()).get(ApplicationConstants.RESOURCES);
			if (appResources.isArray()) {
				for (final JsonNode objNode : appResources) {
					JsonNode entity = objNode.get(ApplicationConstants.ENTITY);
					JsonNode state = entity.get(ApplicationConstants.STATE);
					String status = ApplicationConstants.STARTED;
					if (state.toString().equals(status)) {
						JsonNode entityMemory = entity.get(ApplicationConstants.MEMORY);
						memory = memory + entityMemory.asInt();
					}
				}
			}
		}
		logger.info("****************Total Memory**********" + memory);
		if(memory==0)
		{
			throw new AppMemoryException();
		}
		else
		{
			return memory;
		}
	}
}
