package com.cognizant.pcfsupport.scheduler;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.cognizant.pcfsupport.rabbitmq.RabbitMqProducer;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class ScheduledTasks {

	@Autowired
	private RabbitMqProducer producer;
		
	@Scheduled(fixedDelayString = "${fixedRate}")
    public void runEmailJob() throws JsonProcessingException, IOException {		 
		
		producer.produce();
		//producer.testProduce("Rabbit Mq Message Sent");
    }
	
	
}
