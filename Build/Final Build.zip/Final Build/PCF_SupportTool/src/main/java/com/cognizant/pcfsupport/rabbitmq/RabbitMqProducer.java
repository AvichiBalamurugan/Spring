package com.cognizant.pcfsupport.rabbitmq;

import java.io.IOException;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.cognizant.pcfsupport.exception.NoMessageFoundException;
import com.cognizant.pcfsupport.services.ApiService;
import com.fasterxml.jackson.core.JsonProcessingException;

@Component
public class RabbitMqProducer {
	
	private final RabbitTemplate template;
	
	 @Autowired
	    public RabbitMqProducer(RabbitTemplate template) {
	        this.template = template;
	    }
	 
	@Autowired
	private ApiService apiService;

	private int limit = 90000;
	
	public void produce() throws JsonProcessingException, IOException
	{
		String message = "";
		int memory = apiService.getTotalAppMemory();
		if(memory>limit)
		{
			message = "Total App Memory has got exceeded the pre-configured memory. Currently total memory used is "+ Integer.toString(memory);
			this.template.convertAndSend("spring-queue", message);
			System.out.println("Send msg = " + message);
		}
		
	}
	
	@Bean
    public Queue queue() {
        return new Queue("spring-queue", false);
    }
	
	public void testProduce(String message){		
		if(message==null || message.isEmpty())
		{
			throw new NoMessageFoundException();
		}
		this.template.convertAndSend("spring-queue", message);
		System.out.println("Send msg = " + message);
			
	}
}

