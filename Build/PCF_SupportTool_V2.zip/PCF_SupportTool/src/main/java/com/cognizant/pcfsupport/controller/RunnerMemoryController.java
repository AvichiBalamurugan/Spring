package com.cognizant.pcfsupport.controller;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.pcfsupport.services.ApiService;
import com.cognizant.pcfsupport.services.AwsService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.exceptions.UnirestException;

@RefreshScope
@RestController
public class RunnerMemoryController {
	
	@Autowired
	private ApiService apiService;

	@Autowired
	private AwsService awsService;
	
	@RequestMapping(value = "/GetMemory", method = RequestMethod.GET)
	public ResponseEntity<Object> getFreeMemory() throws JsonProcessingException, UnirestException, IOException
	{
		int memory = apiService.getTotalAppMemory();
		return new ResponseEntity<Object>("Total App Memory Used: "+ Integer.toString(memory), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/GetCfProductSummary", method = RequestMethod.GET)
	public ResponseEntity<Object>  getProductSummary() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException
	{
		String guid = awsService.getProductGuid();
		return new ResponseEntity<Object>("Product GUID: "+ guid, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/GetTotalMemory", method = RequestMethod.GET)
	public ResponseEntity<Object> getTotalMemory() throws JsonProcessingException, UnirestException, IOException, KeyManagementException, NoSuchAlgorithmException
	{
		String totalMemory = awsService.getTotalRunnerMemory();
		return new ResponseEntity<Object>("Total Memory of Diego: "+ totalMemory, HttpStatus.OK);
	}
	
}
