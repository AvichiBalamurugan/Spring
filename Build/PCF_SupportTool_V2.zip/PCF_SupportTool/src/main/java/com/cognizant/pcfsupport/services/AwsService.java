package com.cognizant.pcfsupport.services;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cognizant.pcfsupport.common.ApplicationConstants;
import com.cognizant.pcfsupport.utils.SSLCertificateValidation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class AwsService {
	
	@Value("${producturl}")
	private String producturl;
	
	@Value("${productResource_url}")
	private String productresource_url;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	RestTemplate restTemplate = new RestTemplate();
	
	HttpHeaders headers = new HttpHeaders();
	
	String access_token;
	
	public String getProductGuid() throws JsonProcessingException, IOException, KeyManagementException, NoSuchAlgorithmException {
		access_token = getAwsToken();
		String bearer = "Bearer " + access_token;
		String product_guid = "";
		SSLCertificateValidation.disable();
		headers.set(ApplicationConstants.AUTHORIZATION, bearer);
		final String productUrl = producturl;

		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<String> responseProducts = restTemplate.exchange(productUrl, HttpMethod.GET, entity, String.class);
		String result = responseProducts.getBody();
		final JsonNode products = new ObjectMapper().readTree(result);
		logger.info("****************Products Response**********" + products.toString());
		
		if (products.isArray()) {
			for (final JsonNode objNode : products) {
				JsonNode type = objNode.get(ApplicationConstants.TYPE);
				if ((type.toString()).equals(ApplicationConstants.CF_IDENTIFIER)) {
					JsonNode guid = objNode.get(ApplicationConstants.GUID);
					product_guid = guid.toString().replace("\"", "");
					logger.info("****************Guid Response**********" + guid.toString());

					logger.info("****************Product Guid Response**********" + product_guid);

				}
			}
		}
		return product_guid;
	}
	
	public String getTotalRunnerMemory() throws JsonProcessingException, IOException, KeyManagementException, NoSuchAlgorithmException {
		
		SSLCertificateValidation.disable();
		String product_guid = getProductGuid();
		String diegoInstance = "";
		final String productResource_url = productresource_url
				+ product_guid + "/resources";
		logger.info("****************Product_url**********" + productResource_url);
		
		HttpEntity<String> entity = new HttpEntity<String>(headers);

		ResponseEntity<String> resource = restTemplate.exchange(productResource_url, HttpMethod.GET, entity, String.class);
		String product_result = resource.getBody();
		logger.info("****************product_result**********" + product_result);

		final JsonNode productResources = new ObjectMapper().readTree(product_result).get(ApplicationConstants.RESOURCES);

		if (productResources.isArray()) {
			for (final JsonNode objNode : productResources) {

				String id_name = ApplicationConstants.DIEGO_CELL;
				if (objNode.get(ApplicationConstants.IDENTIFIER).toString().equals(id_name)) {
					JsonNode instance = objNode.get(ApplicationConstants.INSTANCES);
					JsonNode instance_type = objNode.get(ApplicationConstants.INSTANCES_TYPE_BEST_FIT);

					logger.info("****************Instance**********" + instance);
					logger.info("****************Instance Type**********" + instance_type);
					
					diegoInstance = "Number of Instances is " + instance.toString() + " and Instance Type is " + instance_type.toString();
				}
			}
		}

		return diegoInstance;
	}
	
	public String getAwsToken() throws KeyManagementException, NoSuchAlgorithmException, IOException
	{		
		SSLCertificateValidation.disable();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		String url = "https://ec2-54-255-164-233.ap-southeast-1.compute.amazonaws.com/uaa/oauth/token";
		headers.set("Accept", "application/json");
		headers.set("Content-Type", "application/x-www-form-urlencoded");
		MultiValueMap<String, String> arguments = new LinkedMultiValueMap<String, String>();     
		  arguments.add("grant_type", "password");
	      arguments.add("client_id", "opsman");
	      arguments.add("client_secret", "");
	      arguments.add("username", "pcfopsadmin");
	      arguments.add("password", "pcfops123");
	      arguments.add("response_type", "token");
	   HttpEntity<?> httpEntity = new HttpEntity<Object>(arguments, headers);
	   ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, httpEntity, String.class);
	   final JsonNode access_token = new ObjectMapper().readTree(response.getBody()).get("access_token");
	   String token = access_token.toString();
	   token = token.toString().replace("\"", "");
	   logger.info("*******************AWS Token*******************"+token);
	   return token;
	}
}
