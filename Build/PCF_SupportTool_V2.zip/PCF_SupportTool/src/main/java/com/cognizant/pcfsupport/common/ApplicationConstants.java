package com.cognizant.pcfsupport.common;

public class ApplicationConstants {

	public static final String AUTHORIZATION = "authorization";
	public static final String BASIC_AUTHORIZATION = "Basic Y2Y6";
	
	//JSON Constants
	public static final String ACCESS_TOKEN = "access_token";	
	public static final String TOTAL_PAGES = "total_pages";
	public static final String RESOURCES = "resources";
	public static final String GUID = "guid";
	public static final String ENTITY = "entity";
	public static final String STATE = "state";
	public static final String MEMORY = "memory";
	public static final String STARTED = "\"STARTED\"";
	public static final String STOPPED = "\"STOPPED\"";
	public static final String TYPE = "type";
	public static final String CF_IDENTIFIER = "\"cf\"";
	public static final String DIEGO_CELL = "\"diego_cell\"";
	public static final String IDENTIFIER = "identifier";
	public static final String INSTANCES = "instances";
	public static final String INSTANCES_TYPE_BEST_FIT = "instance_type_best_fit";
	
	
	
	
	
}
