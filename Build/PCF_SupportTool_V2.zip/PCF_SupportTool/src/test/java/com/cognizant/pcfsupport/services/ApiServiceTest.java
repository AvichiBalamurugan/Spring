package com.cognizant.pcfsupport.services;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cognizant.pcfsupport.PcfSupportToolApplication;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.exceptions.UnirestException;


@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = PcfSupportToolApplication.class)
public class ApiServiceTest {
 
 	private ApiService mock = Mockito.mock(ApiService.class);
          
    final static Logger logger = Logger.getLogger(ApiServiceTest.class);
   
    @Test
    public void whenRequestIsCorrect_getApiAccessToken() throws JsonProcessingException, UnirestException, IOException {
   
    	when(mock.getApiAccessToken()).thenReturn("Bearer");
        assertEquals("Bearer", mock.getApiAccessToken());
    }
    
 }