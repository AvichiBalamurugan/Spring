package com.palusers.logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.palusers.common.ApplicationConstants;
import com.palusers.configuration.ConfigProperties;
import com.palusers.utils.PropertyFileReader;

@Component
public class LoggerFactory {

	@Autowired
	private PropertyFileReader propertyFileReader;
	@Autowired
	private ILogger fileAppenderLog;
	@Autowired
    private ConfigProperties config;
	
	private String logger_select;
	
	private String file;
	
	public void setLogger_select() {
		this.logger_select = config.getLogger_select();
	}

	public void setFile() {
		this.file = config.getFile();
	}
	
	public ILogger getLoggerInstance() {	
		setLogger_select();
		setFile();
		String loggerMode =logger_select;
		if (loggerMode.equalsIgnoreCase(file)) {
			return fileAppenderLog;
		} 
		//TODO
		return fileAppenderLog;
	}
}
