package com.cognizant.pcfsupport.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.pcfsupport.rabbitmq.RabbitMqProducer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.mashape.unirest.http.exceptions.UnirestException;

@RestController
public class TestController {

	@Autowired
	RabbitMqProducer producer;
	
	@RequestMapping("/send")
	public String sendMsg() throws JsonProcessingException, UnirestException, IOException{
		producer.produce();
		return "Done";
	}
	
	@RequestMapping(value = "/product", method = RequestMethod.POST)
	public ResponseEntity<Object> addType(@RequestBody String message) throws JsonProcessingException, UnirestException, IOException {
		producer.produce();
		return new ResponseEntity<Object>(message, HttpStatus.CREATED);
	}
}
