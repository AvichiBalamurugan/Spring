package com.cts;

public class college extends student {
    public void CalculateBand(float ug ){

        System.out.println("Percentage for UG");
        if(ug<=50){
            System.out.println("Band III");
            System.out.println("Not Eligible");
        }
        else if(ug<=75 && ug>50){
            System.out.println("Band II");
            System.out.println("Eligible");

        }
        else if(ug>75 && ug<=100){
            System.out.println("Band I");
            System.out.println("Eligible");
        }
        else{
            System.out.println("Invalid data");
        }
    }
}
