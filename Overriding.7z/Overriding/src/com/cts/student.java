package com.cts;
import java.util.Scanner;


public class student {
    public void CalculateBand(float pg) {
        if (pg <= 60) {
            System.out.println("Band III");
            System.out.println("Not Eligible");
        } else if (pg <= 80 && pg > 60) {
            System.out.println("Band II");
            System.out.println("Eligible for Grade 2");

        } else if (pg > 80 && pg <= 100) {
            System.out.println("Band I");
            System.out.println("Eligible for Grade 1");
        } else {
            System.out.println("Invalid data");
        }
    }

    public static void main(String[] args) {

          graduate g = new graduate();
          doctorate d = new doctorate();
          school s = new school();
          college c = new college();
         Scanner input = new Scanner(System.in);

        System.out.println("Band Calculation ");
        System.out.println("Enter the sslc percentage ");
        float sslc = input.nextFloat();
        System.out.println("Enter the phd percentage ");
        float phd = input.nextFloat();
        System.out.println("Enter the ug percentage ");
        float ug = input.nextFloat();
        System.out.println("Enter the pg percentage ");
        float pg = input.nextFloat();

        d.CalculateBand(phd);
        g.CalculateBand(pg);
        s.CalculateBand(sslc);
        c.CalculateBand(ug);




    }


}
