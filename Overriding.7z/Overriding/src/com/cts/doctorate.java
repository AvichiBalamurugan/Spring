package com.cts;

public class doctorate extends student {

    public void CalculateBand(float phd) {
        System.out.println("Percentage for PHD");

        if (phd <= 50) {
            System.out.println("Band III");
            System.out.println("Not Eligible");
        } else if (phd <= 70 && phd > 50) {
            System.out.println("Band II");
            System.out.println("Eligible for Group 2");

        } else if (phd > 70 && phd <= 100) {
            System.out.println("Band I");
            System.out.println("Eligible for Group 1");
        } else {
            System.out.println("Invalid data");
        }
    }
}
