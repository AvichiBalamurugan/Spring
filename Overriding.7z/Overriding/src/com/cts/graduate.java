package com.cts;

public class graduate extends student {


}
