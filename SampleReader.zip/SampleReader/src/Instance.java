import java.util.HashMap;
import java.util.Map;

public class Instance {
	String name;  
	Double type;
	
	public Instance(String name, Double type) {    
        this.name = name;    
        this.type = type;   
    }   
	public Instance() {    
    } 
	
	public Map<String,Instance> get_Instance()
	{
		 	Map<String,Instance> instance=new HashMap<String,Instance>();    
	        //Creating Books    
	        Instance type_1 =new Instance(ApplicationConstants.r3xlarge,ApplicationConstants.r3xlarge_ram);
	        Instance type_2 =new Instance(ApplicationConstants.r3large,ApplicationConstants.r3large_ram);
	        Instance type_3 =new Instance(ApplicationConstants.r32xlarge,ApplicationConstants.r32xlarge_ram);
	        Instance type_4 =new Instance(ApplicationConstants.r34xlarge,ApplicationConstants.r34xlarge_ram);
	        Instance type_5 =new Instance(ApplicationConstants.c4xlarge,ApplicationConstants.c4xlarge_ram);
	        Instance type_6 =new Instance(ApplicationConstants.c4large,ApplicationConstants.c4large_ram);
	        Instance type_7 =new Instance(ApplicationConstants.c42xlarge,ApplicationConstants.c42xlarge_ram);
	        Instance type_8 =new Instance(ApplicationConstants.c44xlarge,ApplicationConstants.c44xlarge_ram);
	        Instance type_9 =new Instance(ApplicationConstants.d28xlarge,ApplicationConstants.d28xlarge_ram);
	        Instance type_10 =new Instance(ApplicationConstants.i28xlarge,ApplicationConstants.i28xlarge_ram);
	        Instance type_11 =new Instance(ApplicationConstants.m3xlarge,ApplicationConstants.m3xlarge_ram);
	        Instance type_12 =new Instance(ApplicationConstants.m32xlarge,ApplicationConstants.m32xlarge_ram);
	        Instance type_13 =new Instance(ApplicationConstants.m3large,ApplicationConstants.m3large_ram);
	        Instance type_14 =new Instance(ApplicationConstants.m3medium,ApplicationConstants.m3medium_ram);
	        Instance type_15 =new Instance(ApplicationConstants.t2micro,ApplicationConstants.t2micro_ram);
	        Instance type_16 =new Instance(ApplicationConstants.t2small,ApplicationConstants.t2small_ram);
	        
			instance.put(ApplicationConstants.r3xlarge,type_1);  
	        instance.put(ApplicationConstants.r3large,type_2);  
	        instance.put(ApplicationConstants.r32xlarge,type_3);  
	        instance.put(ApplicationConstants.r34xlarge,type_4);  
	        instance.put(ApplicationConstants.c4xlarge,type_5);  
	        instance.put(ApplicationConstants.c4large,type_6);  
	        instance.put(ApplicationConstants.c42xlarge,type_7);  
	        instance.put(ApplicationConstants.c44xlarge,type_8);  
	        instance.put(ApplicationConstants.d28xlarge,type_9); 
	        instance.put(ApplicationConstants.i28xlarge,type_10); 
	        instance.put(ApplicationConstants.m3xlarge,type_11);         
	        instance.put(ApplicationConstants.m32xlarge,type_12); 
	        instance.put(ApplicationConstants.m3large,type_13);    
	        instance.put(ApplicationConstants.m3medium,type_14);   
	        instance.put(ApplicationConstants.t2micro,type_15);    
	        instance.put(ApplicationConstants.t2small,type_16); 
	        
	        return instance;
	}
}
