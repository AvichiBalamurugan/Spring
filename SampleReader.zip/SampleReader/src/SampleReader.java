    import java.util.*;    
    
    public class SampleReader {    
    public static void main(String[] args) {    
        Instance inst = new Instance();
        Map<String,Instance> get_instance= inst.get_Instance();
          
        String instance_type = "\"c4.xlarge\"";
        
        for(Map.Entry<String, Instance> value:get_instance.entrySet()){    
            String key=value.getKey();  
            if(key.equals(instance_type))
            {
            	Instance get_Instance = value.getValue();
            	System.out.println(key+" Details:"); 
                System.out.println(get_Instance.name+" "+get_Instance.type);  
            }
        }    
    }    
    }    