package neu.edu;

import java.util.Comparator;

class WeightSort implements Comparator<Explosion> {
  public int compare(Explosion obj1, Explosion obj2) {
    if (obj1.getWeight() > obj2.getWeight())
      return 1;
    else
      return -1;
  }
}