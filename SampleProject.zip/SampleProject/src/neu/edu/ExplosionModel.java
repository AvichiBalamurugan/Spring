package neu.edu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ExplosionModel extends AbstractExplosionModel{
  
  List<Explosion> explosionList = new ArrayList<Explosion>();
  
  
  
  public static void demo(){
    ExplosionModel obj = new ExplosionModel();
    
    obj.load();
    obj.explodeAll();
  }

  @Override
  public void load() {
  
    Explosion ab = new AerialBomb();
    ab.setMetric(10);
    ab.setName("Ashwanth");
    ab.setWeight(10.0);
    Explosion ab1 = new AtomBomb();
    ab1.setMetric(15);
    ab1.setName("Bala");
    ab1.setWeight(8.0);
    Explosion ab2 = new AeroBomb();
    ab2.setMetric(20);
    ab2.setName("Aishwarya");
    ab2.setWeight(30.0);
    add(ab1);
    add(ab);
    add(ab2);
    
  }

  @Override
  public void add(Explosion e) {
    explosionList.add(e);
    
  }

  @Override
  public void explodeAll() {
    System.out.println("After Metric Sorting");
    Collections.sort(explosionList);
    for(Explosion e: explosionList)
    {
      System.out.println(e);
     // e.explode();
    }
    
    System.out.println("After Weight Sorting");
    WeightSort ws = new WeightSort();
    Collections.sort(explosionList, ws);
    for(Explosion e: explosionList)
    {
      System.out.println(e);
     // e.explode();
    }
    
    System.out.println("After Name Sorting");
    NameSort ns = new NameSort();
    Collections.sort(explosionList, ns);
    for(Explosion e: explosionList)
    {
      System.out.println(e);
     // e.explode();
    }
    

  }
}
