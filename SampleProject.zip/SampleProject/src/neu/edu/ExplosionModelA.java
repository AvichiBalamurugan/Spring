package neu.edu;

public class ExplosionModelA  extends AbstractExplosionModelA{
  public static void demo(){
    
  }

  @Override
  public void load() {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void add(AbstractExplosion e) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void explodeAll() {
    // TODO Auto-generated method stub
    
  }
}
