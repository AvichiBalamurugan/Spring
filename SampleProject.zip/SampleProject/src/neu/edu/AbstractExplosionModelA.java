package neu.edu;

public abstract class AbstractExplosionModelA {
  public abstract void load();
  
  public abstract void add(AbstractExplosion e);
  
  public abstract void explodeAll();
}
