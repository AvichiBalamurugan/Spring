package neu.edu;

public class AerialBomb extends Explosion{
  
  @Override
  public void explode() {
    System.out.println("Blast from AerialBomb");
  }
}
