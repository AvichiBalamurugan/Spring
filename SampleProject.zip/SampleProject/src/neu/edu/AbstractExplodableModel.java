package neu.edu;

public abstract class AbstractExplodableModel {
  
  public abstract void load();
  
  public abstract void add(ExplodableAPI e);
  
  public abstract void explodeAll();

}
