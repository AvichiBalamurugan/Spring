package neu.edu;

public class AtomBomb extends Explosion{
  
  @Override
  public void explode() {
    System.out.println("Blast from AtomBomb");
  }
}
