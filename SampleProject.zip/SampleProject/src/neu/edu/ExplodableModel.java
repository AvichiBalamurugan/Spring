package neu.edu;

public class ExplodableModel extends AbstractExplodableModel {

  public static void demo(){
    
  }

  @Override
  public void load() {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void add(ExplodableAPI e) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void explodeAll() {
    // TODO Auto-generated method stub
    
  }
}
