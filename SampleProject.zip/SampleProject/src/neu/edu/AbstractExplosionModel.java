package neu.edu;

public abstract class AbstractExplosionModel {
  public abstract void load();
  
  public abstract void add(Explosion e);
  
  public abstract void explodeAll();
}
