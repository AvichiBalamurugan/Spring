package neu.edu;

public class AeroBomb extends Explosion{
  
  @Override
  public void explode() {
    System.out.println("Blast from AeroBomb");
  }

}
