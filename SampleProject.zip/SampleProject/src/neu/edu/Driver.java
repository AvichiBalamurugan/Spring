package neu.edu;

public class Driver {

  public static void main(String[] args) {

    ExplosionModel.demo();
//    ExplosionModelA.demo();
//    ExplodableModel.demo();
  }

}
