package neu.edu;

public abstract class AbstractExplosion {

  public abstract void explode();
}
