package neu.edu;

public interface ExplodableAPI {
  public void explode();
}
