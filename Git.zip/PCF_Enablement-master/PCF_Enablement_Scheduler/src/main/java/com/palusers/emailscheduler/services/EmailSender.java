package com.palusers.emailscheduler.services;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClient;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;
import com.amazonaws.services.simpleemail.model.SendEmailResult;
import com.palusers.emailscheduler.domain.EmailRequest;

@Service
public class EmailSender implements IEmailService {
	
	@Autowired
	private TemplateEngine templateEngine;
	@Value("${awssource}")
	private String awssource;
	@Value("${appmanagerconsole}")
	private String appmanagerconsole;
	@Value("${cfcli}")
	private String cfcli;
	@Value("${cfclidownload}")
	private String cfclidownload;
	@Value("${supportteam}")
	private String supportteam;
	@Value("${accesskey}")
	private String accesskey;
	@Value("${secretkey}")
	private String secretkey;	
	
    @Override
    public void sendRegistrationEmail(EmailRequest emailData)  {
    	Context context = new Context();
        context.setVariable("track", emailData.Track);
        context.setVariable("link", emailData.LearningUrl);
        context.setVariable("entrycode", emailData.UniqueId);
        context.setVariable("accountcreationurl", emailData.AccountCreationUrl);
        String htmlBody =  templateEngine.process("RegistrationEmailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    
    @Override
    public void sendAccountEmail(EmailRequest emailData)  {
    	Context context = new Context();
    	context.setVariable("username", emailData.Username);
        context.setVariable("password", emailData.Password);
        context.setVariable("apiurl", emailData.ApiURL);
        context.setVariable("appmanagerurl", emailData.AppManagerUrl);
        context.setVariable("appmanagerconsole", appmanagerconsole);  
        context.setVariable("cfcli", cfcli);  
        context.setVariable("cfclidownload", cfclidownload);        
        String htmlBody =  templateEngine.process("AccountEmailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    
    @Override
    public void sendErrorMail(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("ErrorMailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    
    @Override
    public void sendDeleteAccount(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("DeleteAccountMailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }

    @Override
    public void sendDeleteAccountRemainder(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("DeleteRemainderMailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    @Override
    public void sendSupportTeamMail(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("SupportTeamEmailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }    
    
    @Override
    public void sendLimitMail(EmailRequest emailData) {
    	Context context = new Context();
        context.setVariable("message", emailData.Message);
        String htmlBody =  templateEngine.process("LimitErrorMailTemplate", context);
        sendMail(emailData.Recipient,emailData.HCMRecipient,emailData.Subject,htmlBody);
    }
    
	private void sendMail(String to, String supervisoremail, String subject, String htmlbody) {
		
		 Content subjectContent = new Content(subject);		 
	     String newhtml = htmlbody.replace("<html lang=\"en\" xmlns=\"http://www.w3.org/1999/xhtml\">", "<html>");
	     System.out.println("newhtml: "+newhtml);
	     System.out.println("support team email: "+supportteam);
		 Content bodyContent = new Content().withData(newhtml);
	     Body msgBody = new Body().withHtml(bodyContent);
	     Message msg = new Message(subjectContent, msgBody);
	     List<String> toAddresses = Arrays.asList(to);
	     Destination destination = null;
	     if(supervisoremail !=null)
	     {
	    	 destination= new Destination().withToAddresses(toAddresses).withCcAddresses(supervisoremail).withBccAddresses(supportteam);
	     }
	     else
	     {
	    	 destination= new Destination().withToAddresses(toAddresses).withBccAddresses(supportteam);
	     }	     
	    	 
	     SendEmailRequest request = new SendEmailRequest(awssource, destination, msg);	     
	     AWSCredentials credentials = new BasicAWSCredentials(accesskey, secretkey);
	     AmazonSimpleEmailServiceClient sesClient = new AmazonSimpleEmailServiceClient(credentials);
	     SendEmailResult result = sesClient.sendEmail(request);
    }
}
