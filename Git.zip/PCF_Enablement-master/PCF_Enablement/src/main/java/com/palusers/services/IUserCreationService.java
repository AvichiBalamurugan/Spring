package com.palusers.services;


import java.util.Date;
import java.util.List;
import com.palusers.domain.UserEntity;

public interface IUserCreationService {
	List<UserEntity> listAll();
	UserEntity getById(Long id);
	UserEntity saveOrUpdate(UserEntity user);
	void delete(Long id);
	UserEntity findbyEmailId(String employeeemailid);
	List<UserEntity> getUserForActivation(String activationstatus,Integer numberofattempts);
	void updateActStatus(String employeeemailid, String activationstatus,Date dt);
	void updateAccountCreationStatus(String employeeemailid, String activationstatus,Date dt);	
	void deleteActStatus(String activationstatus, Date date);	
	void updateNoofAttempts(String employeeemailid, Integer attempt,String activationstatus);
	void updateOrgID(String employeeemailid, String orgid, Date dt);
	List<UserEntity> getDeletionUsers(Date dt,String activationstatus);
	List<UserEntity> getDeletionRemainder(Date dt,String activationstatus);
	String getCount(Date from, Date to);
}
