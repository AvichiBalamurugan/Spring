package com.springconfig.client;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ConfigurationProperties
@PropertySource("classpath:bootstrap.properties")
public class ConfigProperties {

	private String message;
	
	public void setMessage(String message) {
		this.message = message;
	}
	
    public String getMessage() {
		return message;
	}

	


   
  
    // standard getters and setters
}