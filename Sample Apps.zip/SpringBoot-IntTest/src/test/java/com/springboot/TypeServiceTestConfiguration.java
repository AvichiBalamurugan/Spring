package com.springboot;

import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import com.springboot.type.TypeService;

@Profile("test")
@Configuration
public class TypeServiceTestConfiguration {
    @Bean
    @Primary
    public TypeService typeService() {
        return Mockito.mock(TypeService.class);
    }
}
