package com.springboot;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.springboot.type.Type;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBootBurgApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ItTest{

	@LocalServerPort
	private int port;

	final static Logger logger = Logger.getLogger(ItTest.class);
	
	TestRestTemplate restTemplate = new TestRestTemplate();

	HttpHeaders headers = new HttpHeaders();

	@Test
	public void test2GetType() throws Exception {

		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(createURLWithPort("/types/test5"), String.class);
		Type object = new Type();
		object.setId("test5");
		object.setName("tests");
		object.setDescription("Integration Testing POST");
		ObjectMapper mapper = new ObjectMapper();
		
	    String jsonval = mapper.writeValueAsString(object);
    	System.out.println(result);
		logger.info("This is info : " + result.toString());
		logger.info("This is info : " + jsonval.toString());
        JSONAssert.assertEquals(jsonval, result, false);
	
	}
	
	
	@Test
	public void test1PostType() {
		
		Type type = new Type();
		type.setId("test5");
		type.setName("tests");
        type.setDescription("Integration Testing POST");
        HttpEntity<Type> entity = new HttpEntity<Type>(type, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Type> response = restTemplate
      		  .exchange(createURLWithPort("/types"), HttpMethod.POST, entity, Type.class);
            Type object = response.getBody();
            logger.info("This is info : " + response.toString());
            assertEquals(HttpStatus.CREATED, response.getStatusCode());
            logger.info("This is info of object : " + object.toString());
            logger.info("This is info of object : " + object.getName());
           assertEquals("tests", object.getName()); 
		
	}
	
	@Test
	public void test3UpdateType() {
		
		Type type = new Type();
		type.setId("test5");
		type.setName("tests");
        type.setDescription("test");
        HttpEntity<Type> entity = new HttpEntity<Type>(type, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Type> response = restTemplate
      		  .exchange(createURLWithPort("/types/test5"), HttpMethod.PUT, entity, Type.class);
            Type object = response.getBody();
            logger.info("This is info : " + response.toString());
            assertEquals(HttpStatus.OK, response.getStatusCode());
            logger.info("This is info of object : " + object.toString());
            logger.info("This is info of object : " + object.getName());
           assertEquals("tests", object.getName()); 
		
	}
	
	@Test
	public void test4DeleteType() {
	

final String uri = "/types/{id}";

Map<String, String> params = new HashMap<String, String>();
params.put("id", "test5");
 
RestTemplate restTemplate = new RestTemplate();
restTemplate.delete(createURLWithPort(uri), params);

	}
	
	private String createURLWithPort(String uri) {
		return "http://localhost:" + port + uri;
	}
	
	
	
}
