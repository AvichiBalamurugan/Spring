package com.springboot;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.Charset;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.springboot.type.Type;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class UnitTest extends SpringBootBurgApplicationTests {
	public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	@Autowired
	private WebApplicationContext webApplicationContext;
	
	private MockMvc mockMvc;

	
	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@Test
	public void test1Hello() throws Exception {
		mockMvc.perform(get("/")).andExpect(status().isOk())
				.andExpect(content().contentType("text/plain;charset=UTF-8"))
				.andExpect(content().string("Hello"))
				.andDo(print());
		
	}
	
	@Test
	public void test2GetService() throws Exception {
		mockMvc.perform(get("/types/bank")).andExpect(status().isOk())
				.andExpect(content().contentType("application/json;charset=UTF-8"))
				.andExpect(jsonPath("$.id").value("bank")).andExpect(jsonPath("$.name").value("banks"))
				.andExpect(jsonPath("$.description").value("Nationalized, Public and Private Banks"))
				.andDo(print());

	}	
	
	@Test
	public void test3GetServiceError() throws Exception {
		
		mockMvc.perform(get("/types/200"))
		.andExpect(status().isNotFound())
				.andDo(print());

	}	
	
	
@Test
	public void test4PostService() throws Exception {
		String url = "/types";
		Type object = new Type();
		object.setId("testID");
		object.setName("mock mvc");
		object.setDescription("Testing");
	    //... more
	    ObjectMapper mapper = new ObjectMapper();
	    mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
	    ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
	    String requestJson=ow.writeValueAsString(object);

	    mockMvc.perform(post(url).contentType(APPLICATION_JSON_UTF8)
	        .content(requestJson))
	        .andExpect(status().isCreated())
	        .andDo(print());
		
	}

@Test
public void test5PostServiceError() throws Exception {
	String url = "/types";
	Type object = new Type();
	object.setId("test2");
	object.setName("");
	object.setDescription("");
    //... more
    ObjectMapper mapper = new ObjectMapper();
    mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
    ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
    String requestJson=ow.writeValueAsString(object);

    mockMvc.perform(post(url).contentType(APPLICATION_JSON_UTF8)
        .content(requestJson))
    .andExpect(status().is4xxClientError())
        .andDo(print());
	
}

	
	@Test
	public void test6PutService() throws Exception {
		Type object = new Type();
		object.setId("testID");
		object.setName("test");
		object.setDescription("test");
		  ObjectMapper mapper = new ObjectMapper();
		    mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		    ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		    String requestJson=ow.writeValueAsString(object);
			    
	    /*ResultMatcher created = MockMvcResultMatchers.status()
                .isCreated();*/

MockHttpServletRequestBuilder builder =
MockMvcRequestBuilders.put("/types/{id}", object.getId())
		.contentType("application/json;charset=UTF-8")
		.accept(APPLICATION_JSON_UTF8)
	 .content(requestJson);
				this.mockMvc.perform(builder)
				.andExpect(status().isOk())
				.andDo(print());
	    
	}	
	
	@Test
	public void test7PutServiceError() throws Exception {
		Type object = new Type();
		object.setId("hjk");
		object.setName("temple");
		object.setDescription("Going to temple for worshipping");
		  ObjectMapper mapper = new ObjectMapper();
		    mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
		    ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
		    String requestJson=ow.writeValueAsString(object);
			    
	    /*ResultMatcher created = MockMvcResultMatchers.status()
                .isCreated();*/

MockHttpServletRequestBuilder builder =
MockMvcRequestBuilders.put("/types/{id}", object.getId())
		.contentType("application/json;charset=UTF-8")
		.accept(APPLICATION_JSON_UTF8)
	 .content(requestJson);
				this.mockMvc.perform(builder)
				.andExpect(status().isNotFound())
				.andDo(print());
	    
	}
	
	@Test
	public void test8deleteService() throws Exception{
					
		mockMvc.perform(
	            delete("/types/{id}", "testID"))
		.andExpect(status().isOk())
	    	    .andDo(print());
							
	}
	
	@Test
	public void test9deleteServiceError() throws Exception{
					
		mockMvc.perform(
	            delete("/types/{id}", "hjk"))	
		        .andExpect(status().isNotFound())
	    	    .andDo(print());
							
	}
	
	
}