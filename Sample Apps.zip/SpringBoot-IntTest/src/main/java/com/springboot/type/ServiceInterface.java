package com.springboot.type;

import java.util.List;

public interface ServiceInterface {

	List<Type> getAllTypes();

	Type getType(String id);

	void addType(Type type);

	void updateType(Type type, String id);

	void deleteType(String id);

}