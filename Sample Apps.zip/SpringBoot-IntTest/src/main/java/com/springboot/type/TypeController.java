package com.springboot.type;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;



@CrossOrigin(origins = "*")
@RestController
public class TypeController {

	@Autowired
	private ServiceInterface typeService;

	@RequestMapping("/")
	public String Topics() {
		return "Hello";
	}
	
	@RequestMapping("/types")
	public List<Type> getAllTopics() {
		return typeService.getAllTypes();
	}
		
	@RequestMapping("/types/{id}")
	public Type getTypes(@PathVariable("id") String id) {
		return typeService.getType(id);
	}
	
	@RequestMapping(value = "/types", method = RequestMethod.POST)
	public ResponseEntity<Object> addType(@RequestBody Type type) {
		typeService.addType(type);
		return new ResponseEntity<Object>(type, HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/types/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Object> updateTopic(@RequestBody Type type, @PathVariable("id") String id) {
		typeService.updateType(type, id);
		return new ResponseEntity<Object>(type, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/types/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteType(@PathVariable("id") String id) {
		typeService.deleteType(id);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
}
