package com.springboot.type;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springboot.exception.NoTypesFoundException;
import com.springboot.exception.NoValuesFoundException;

@Service
public class TypeService implements ServiceInterface {

	@Autowired
	private TypeRepository typeRepository;
	

	public TypeService() {
		super();
	}

	public TypeService(TypeRepository typeRepository) {
		super();
		this.typeRepository = typeRepository;
	}
	
	@Override
	public List<Type> getAllTypes()
	{
		List<Type> types=new ArrayList<>();
		typeRepository.findAll()
		.forEach(types::add);
		return types;
	}
	
	@Override
	public Type getType(String id) {
		Type type = typeRepository.findOne(id);
		if(type==null)
		{
			throw new NoTypesFoundException ();
		}
		return type;
	}

	@Override
	public Type addType(Type type) {
		if(type.getId().isEmpty() || type.getName().isEmpty() || type.getDescription().isEmpty() || type==null ||type.getId()==null || type.getName()==null || type.getDescription()==null)
		{
		throw new NoValuesFoundException ();
		}
		return typeRepository.save(type);
		
	}

	@Override
	public void updateType(Type type,String id) {
		Type object = typeRepository.findOne(id);
		
		if(object==null)
		{
			throw new NoTypesFoundException ();
		}
		typeRepository.save(type);
		
	}

	@Override
	public Type deleteType(String id) {
		Type type = typeRepository.findOne(id);
		if(type==null)
		{
			throw new NoTypesFoundException ();
		}
		typeRepository.delete(id);
		return type;
	}
}
