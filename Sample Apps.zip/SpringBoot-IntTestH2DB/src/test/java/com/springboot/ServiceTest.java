package com.springboot;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.springboot.exception.NoTypesFoundException;
import com.springboot.exception.NoValuesFoundException;
import com.springboot.type.Type;
import com.springboot.type.TypeRepository;
import com.springboot.type.TypeService;

public class ServiceTest {


	private TypeService service;
	@Mock
	 private TypeRepository trepo;
	@Mock
    private Type type;
	@Before
	public void setupMock() {
	    MockitoAnnotations.initMocks(this);
	    trepo = Mockito.mock(TypeRepository.class);
	    service = new TypeService(trepo);
	}
   
    @Test
    public void GetTypes() throws Exception {
       
    	Type obj = new Type("tservice","hello","hellotype");
    	trepo.save(obj);
        when(trepo.findOne("tservice")).thenReturn(type);
        // Act
        Type retrievedType = service.getType("tservice");
        // Assert
        assertThat(retrievedType, is(equalTo(type)));
        trepo.delete(obj);
    }
    
    @Test(expected = NoTypesFoundException.class)
    public void GetTypesError() throws Exception {
      
        service.getType("hjhkjk");
    }
    
    @Test
    public void PostTypes() throws Exception {
       
    	
    	Type obj = new Type();
    	obj.setId("postservice");
    	obj.setName("post");
    	obj.setDescription("post");
    	// Arrange
    	when(trepo.save(obj)).thenReturn(obj);
        // Act
        Type savedType = service.addType(obj);
        // Assert
        assertThat(savedType, is(equalTo(obj)));
    }
    
    @Test(expected = NoValuesFoundException.class)
    public void PostTypesError() throws Exception {
       
    	
    	Type obj = new Type();
    	obj.setId("postservice");
    	obj.setName("post");
    	obj.setDescription("");
    	// Arrange
    	when(trepo.save(obj)).thenReturn(obj);
        // Act
        Type savedType = service.addType(obj);
        // Assert
        assertThat(savedType, is(equalTo(obj)));
    }
    
    @Test
    public void DeleteTypes() throws Exception {
        // Arrange
    	Type obj = new Type();
    	obj.setId("postservice");
    	obj.setName("post");
    	obj.setDescription("post");
    	trepo.save(obj);
              
        when(trepo.findOne("postservice")).thenReturn(obj);
        
        Type returned = service.deleteType("postservice");
        
            
        assertEquals(obj, returned);
        
        
    }
    
    @Test(expected = NoTypesFoundException.class)
    public void DeleteTypesError() throws Exception {
       
    	
    	service.deleteType("postservice");
    }
    

}