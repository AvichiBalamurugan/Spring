package com.springboot;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.springboot.type.Type;
import com.springboot.type.TypeRepository;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringBootBurgApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class IntegrationTest{

	@LocalServerPort
	private int port;

	final static Logger logger = Logger.getLogger(ItTest.class);
	
	HttpHeaders headers = new HttpHeaders();
	
	public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
	
	  @Autowired
	  private TypeRepository trepo;
	
	  private TestRestTemplate restTemplate = new TestRestTemplate();
	  
	@Test
	public void test1CreateType() throws JsonProcessingException{
    
	  
	  headers.setContentType(MediaType.APPLICATION_JSON);
	  HttpEntity<Type> request = new HttpEntity<>(new Type("hello","hello","hd"), headers);
	   //Invoking the API
	  Type responseObject = restTemplate.postForObject(createURLWithPort("/types"), request, Type.class);
	  logger.info("This is info of object : " + responseObject.toString());
	  assertNotNull(responseObject);

	  //Asserting the response of the API.
	  String message = responseObject.getName().toString();
	  assertEquals("hello", message);
	  String typeId = responseObject.getId().toString();

	  assertNotNull(typeId);

	  //Fetching the Book details directly from the DB to verify the API succeeded
	  Type typeFromDb = trepo.findOne(typeId);
	  logger.info("This is info of object from DB : " + typeFromDb.getId().toString());
	  assertEquals("hello", typeFromDb.getId());
	  assertEquals("hello", typeFromDb.getName());
	  assertEquals("hd", typeFromDb.getDescription());

	  //Delete the data added for testing
	  trepo.delete(typeId);

	}
	
	
	@Test
	public void test2GetType(){
	  //Create a new book using the BookRepository API
	  Type type = new Type("test", "test8", "Author1");
	  trepo.save(type);

	  String typeId = type.getId();
       
	  String uri = createURLWithPort("/types/")+ typeId;
	  //Now make a call to the API to get details of the book
	  Type responseObject = restTemplate.getForObject(uri, Type.class);
	  logger.info("This is info of Id from DB : " + responseObject.getId().toString());
	  logger.info("This is info of Name from DB : " + responseObject.getName().toString());
	  logger.info("This is info of Description from DB : " + responseObject.getDescription().toString());
	  //Verify that the data from the API and data saved in the DB are same
	  assertNotNull(responseObject);
	  assertEquals("test", responseObject.getId());
	  //Delete the Test data created
	  trepo.delete(typeId);
	}
	
	@Test
	public void test3UpdateType() throws JsonProcessingException{
		Type object = new Type("test8", "test8", "Author1");
		  trepo.save(object);
		Type type = new Type();
		type.setId("test8");
		type.setName("testing");
        type.setDescription("tested");
        String typeId = object.getId();
        String uri = createURLWithPort("/types/")+typeId;
        logger.info("This is info of updated object URL : " + uri);
        HttpEntity<Type> entity = new HttpEntity<Type>(type, headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Type> response = restTemplate
      		  .exchange(uri, HttpMethod.PUT, entity, Type.class);
            Type responseObject = response.getBody();
            logger.info("This is info : " + responseObject.toString());
            assertEquals(HttpStatus.OK, response.getStatusCode());
            logger.info("This is info of object : " + responseObject.toString());
            logger.info("This is info of object : " + responseObject.getName());
           assertEquals("testing", responseObject.getName()); 
           Type typeFromDb = trepo.findOne(typeId);
     	  logger.info("This is info of object from DB : " + typeFromDb.getDescription());
     	  assertEquals("testing", typeFromDb.getName());
     	  //Delete the data added for testing
     	  trepo.delete(typeId);
	  	

	}
	
	@Test
	public void test4DeleteType() throws JsonProcessingException{
		Type object = new Type("test8", "test8", "Author1");
		  trepo.save(object);

     	  String typeId = object.getId();
          
     	 final String uri = "/types/{id}";
     	Map<String, String> params = new HashMap<String, String>();
     	params.put("id", typeId);

     	restTemplate.delete(createURLWithPort(uri), params);

     	Type typeFromDb = trepo.findOne(typeId);
     	  //and assert that there is no data found
     	  assertNull(typeFromDb);
	}
	
	@Test
	public void testGetAllTypes(){

		  String uri = createURLWithPort("/types");
	
		
		  ResponseEntity<Object[]> responseEntity = restTemplate.getForEntity(uri, Object[].class);
		  Object[] objects = responseEntity.getBody();
	//	  MediaType contentType = responseEntity.getHeaders().getContentType();
	//	  HttpStatus statusCode = responseEntity.getStatusCode();
		  System.out.print(objects);
		  logger.info("This is info of object from DB : " + objects.length);
		  assertTrue(objects.length == 0);
			Type object = new Type("test8", "test8", "Author1");
			trepo.save(object);

		    Type object2 = new Type("test9", "test8", "Author1");
			trepo.save(object2);
			ResponseEntity<Object[]> responseEntity1 = restTemplate.getForEntity(uri, Object[].class);
			  Object[] objects2 = responseEntity1.getBody();
			  logger.info("This is info of object from DB : " + objects2.length);
			  assertTrue(objects2.length == 2);
			  trepo.delete(object.getId());
			  trepo.delete(object2.getId());
			  List<Type> obj = (List<Type>) trepo.findAll();
			  logger.info("This is info of object list : " + obj.toString());
	}
	
	private String createURLWithPort(String uri) {
		return "http://localhost:" + port + uri;
	}
	
	
}
