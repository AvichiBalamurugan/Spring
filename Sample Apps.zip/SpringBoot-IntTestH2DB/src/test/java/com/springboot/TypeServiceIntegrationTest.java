package com.springboot;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.springboot.type.Type;
import com.springboot.type.TypeRepository;
import com.springboot.type.TypeService;

@ActiveProfiles("test")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = SpringBootBurgApplication.class)
public class TypeServiceIntegrationTest {
 
    @Autowired
    private TypeService service;
  
    @Autowired
    private TypeRepository trepo;
        
    final static Logger logger = Logger.getLogger(ItTest.class);
    
    @Test
    public void whenTypeIdIsProvided_thenRetrievedTypeIsCorrect() {
    	Type expected = new Type("test1", "mock mvc", "Testing");
    	trepo.save(expected);
        Mockito.when(service.getType("test1")).thenReturn(expected);
        Type testId = service.getType("test1");
        Assert.assertEquals(expected, testId);
    }
    
    @Test
    public void whenTypeIdIsInCorrect_thenNotRetrieved() {
    	Mockito.when(service.getType("testdsds")).thenReturn(null);
        Type testId = service.getType("testdsds");
        Assert.assertEquals(null, testId);
    }
    
    @Test
    public void whenTypeIdIsCorrect_thenCheckRetrieved() {
    	Type expected = new Type("test1", "mock mvc", "Testing");
    	Mockito.when(service.getType("test1")).thenReturn(expected);
        Type testId = service.getType("test1");
        logger.info("This is info : " + testId.toString());
        Assert.assertNotEquals(null, testId);
    }
    
 }