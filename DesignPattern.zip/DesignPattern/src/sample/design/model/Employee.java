package sample.design.model;

import java.util.Comparator;

public class Employee extends Person {

  private double wage;
  
  public Employee(String firstName, String lastName, int age, double wage) {
    super.setAge(age);
    super.setFirstName(firstName);
    super.setLastName(lastName);
    setWage(wage);
  }

  @Override
  public double getWage() {
    return wage;
  }

  public void setWage(double wage) {
    this.wage = wage;
  }

  @Override
  public String toString() {
    return "Employee " + super.getFirstName() + " " + super.getLastName() + ", age " + super.getAge()
        + ", Wage $" + wage;
  }
  
  public static Comparator<Person> compareByWage = Comparator.comparing( Person::getWage );

}