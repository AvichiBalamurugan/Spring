package sample.design.model;

import java.util.Comparator;

public abstract class Person {

  private String firstName;
  private String lastName;
  private int age;

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  public double getGpa() {
    return 0.0;
  }

  public double getWage() {
    return 0.0;
  }
  
  public static Comparator<Person> compareBylastName = Comparator.comparing( Person::getLastName );
  
  public static Comparator<Person> compareByAge = Comparator.comparing( Person::getAge );

}
