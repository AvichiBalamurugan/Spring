package sample.design.model;

import java.util.Comparator;

public class Student extends Person {

  private double gpa;

  public Student(String firstName, String lastName, int age, double gpa) {
    super.setAge(age);
    super.setFirstName(firstName);
    super.setLastName(lastName);
    setGpa(gpa);
  }

  @Override
  public double getGpa() {
    return gpa;
  }

  public void setGpa(double gpa) {
    this.gpa = gpa;
  }

  @Override
  public String toString() {
    return "Student " + super.getFirstName() + " " + super.getLastName() + ", age " + super.getAge()
        + ", GPA " + gpa;
  }

  public static Comparator<Person> compareByGpa = Comparator.comparing( Person::getGpa );
  
}
