package sample.design.abstractfactory;

import sample.design.model.Person;
import sample.design.model.Student;

public class StudentFactory implements PersonAbstractFactory{

  private String firstName;
  private String lastName;
  private int age;
  private double gpa;
  
  public StudentFactory(String firstName, String lastName, int age, double gpa) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.gpa = gpa;
  }
  
  @Override
  public Person createPerson() {
    return new Student(firstName,lastName,age,gpa);
  }
  
}
