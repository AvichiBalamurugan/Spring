package sample.design.abstractfactory;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import sample.design.factory.PersonFactory;
import sample.design.model.Employee;
import sample.design.model.Person;
import sample.design.model.Student;

public class AbstractFactoryPattern {

  List<Person> employeeList = new ArrayList<Person>();
  List<Person> studentList = new ArrayList<Person>();

  public static void demo() {
    AbstractFactoryPattern obj = new AbstractFactoryPattern();

    obj.sampleData();
    
    obj.loadEmployeeData();
    obj.sortEmployee();

    obj.loadStudentData();
    obj.sortStudent();
  }

  public void sampleData() {
    Person employee = PersonFactory.getPerson(new EmployeeFactory("Bala", "Murugan", 40, 100000.0));
    Person student = PersonFactory.getPerson(new StudentFactory("Avichi", "Bala", 25, 10));
    System.out.println("AbstractFactory Person Details::" + employee);
    System.out.println("AbstractFactory Person Details::" + student);

  }

  public void loadEmployeeData() {
    Person employee_1 = PersonFactory.getPerson(new EmployeeFactory("Bala", "A", 40, 5000.0));
    Person employee_2 = PersonFactory.getPerson(new EmployeeFactory("Bala", "D", 40, 1000.0));
    Person employee_3 = PersonFactory.getPerson(new EmployeeFactory("Bala", "B", 40, 20000.0));

    employeeList.add(employee_1);
    employeeList.add(employee_2);
    employeeList.add(employee_3);

  }

  public void loadStudentData() {
    Person student_1 = PersonFactory.getPerson(new StudentFactory("Avichi", "A", 20, 7.5));
    Person student_2 = PersonFactory.getPerson(new StudentFactory("Avichi", "D", 10, 7));
    Person student_3 = PersonFactory.getPerson(new StudentFactory("Avichi", "B", 15, 8));

    studentList.add(student_1);
    studentList.add(student_2);
    studentList.add(student_3);

  }

  public void sortEmployee() {
    System.out.println("\nEmployees Before Sorting");
    displayAllEmployeeDetails();

    System.out.println("\nSorting Employees By Name");
    Collections.sort(employeeList, Person.compareBylastName);

    System.out.println("\nEmployees After Sorting By Name");
    displayAllEmployeeDetails();

    System.out.println("\nSorting Employees By Wage");
    Collections.sort(employeeList, Employee.compareByWage);

    System.out.println("\nEmployees After Sorting By Wage");
    displayAllEmployeeDetails();
  }

  public void sortStudent() {
    System.out.println("\nStudents Before Sorting");
    displayAllStudentDetails();

    System.out.println("\nSorting Students By Name");
    Collections.sort(studentList, Person.compareBylastName);

    System.out.println("\nStudents After Sorting By Name");
    displayAllStudentDetails();

    System.out.println("\nSorting Students By Age");
    Collections.sort(studentList, Person.compareByAge);

    System.out.println("\nStudents After Sorting By Age");
    displayAllStudentDetails();

    System.out.println("\nSorting Students By GPA");
    Collections.sort(studentList, Student.compareByGpa);

    System.out.println("\nStudents After Sorting By GPA");
    displayAllStudentDetails();
  }

  public void displayAllEmployeeDetails() {
    for (Person e : employeeList) {
      System.out.println(e);
    }
  }

  public void displayAllStudentDetails() {
    for (Person e : studentList) {
      System.out.println(e);
    }
  }

}
