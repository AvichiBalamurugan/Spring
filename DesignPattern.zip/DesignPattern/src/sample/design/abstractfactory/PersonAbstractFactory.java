package sample.design.abstractfactory;

import sample.design.model.Person;

public interface  PersonAbstractFactory {

  public Person createPerson();
  
}
