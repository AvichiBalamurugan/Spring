package sample.design.abstractfactory;

import sample.design.model.Employee;
import sample.design.model.Person;

public class EmployeeFactory implements PersonAbstractFactory {

  private String firstName;
  private String lastName;
  private int age;
  private double wage;

  public EmployeeFactory(String firstName, String lastName, int age, double wage) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
    this.wage = wage;
  }

  @Override
  public Person createPerson() {
    return new Employee(firstName, lastName, age, wage);
  }

}
