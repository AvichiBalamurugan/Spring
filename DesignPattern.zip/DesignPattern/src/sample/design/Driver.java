package sample.design;

import sample.design.abstractfactory.AbstractFactoryPattern;
import sample.design.factory.SimpleFactoryPattern;

public class Driver {

  public static void main(String[] args) {

    SimpleFactoryPattern.demo();
    AbstractFactoryPattern.demo();
    
  }
}
