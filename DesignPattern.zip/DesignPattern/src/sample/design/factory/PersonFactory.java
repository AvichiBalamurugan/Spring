package sample.design.factory;

import sample.design.abstractfactory.PersonAbstractFactory;
import sample.design.model.Employee;
import sample.design.model.Person;
import sample.design.model.Student;

public class PersonFactory {

  public static Person getPerson(String type, String firstName, String lastName, int age,
      double value) {
    if ("student".equalsIgnoreCase(type))
      return new Student(firstName, lastName, age, value);
    else if ("employee".equalsIgnoreCase(type))
      return new Employee(firstName, lastName, age, value);
    return null;
  }

  public static Person getPerson(PersonAbstractFactory factory) {
    return factory.createPerson();
  }

}
