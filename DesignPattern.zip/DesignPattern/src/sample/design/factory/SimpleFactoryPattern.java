package sample.design.factory;

import sample.design.model.Person;

public class SimpleFactoryPattern {

  public static void demo() {
    SimpleFactoryPattern obj = new SimpleFactoryPattern();

    obj.sampleData();
  }

  public void sampleData() {
    Person employee = PersonFactory.getPerson("employee", "Bala", "Murugan", 20, 100.0);
    Person student = PersonFactory.getPerson("student", "Avichi", "Bala", 20, 8.5);
    System.out.println("SimpleFactory Person Details::" + employee);
    System.out.println("SimpleFactory Person Details::" + student);
  }

}
