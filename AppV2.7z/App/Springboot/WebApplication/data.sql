insert into population values(2010,1192,613,579);
insert into population values(2011,1211,623,588);
insert into population values(2012,1233,634,599);
insert into population values(2013,1250,643,607);
insert into population values(2014,1266,650,616);
insert into population values(2015,1282,658,624);
insert into population values(2017,1316,676,640);
insert into population values(2018,1334,686,648);