package com.webapplication.service;

import java.util.List;

import com.webapplication.model.Population;

public interface PopulationServiceInterface {

	List<Population> getAllPopulation();
}
