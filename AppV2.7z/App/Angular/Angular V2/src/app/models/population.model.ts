export class Population {

    year: number;
    total: number;
    male: number;
    female: number;
  }
  